<?php
/**
 * Blackstone Online Gateway
 *
 * @package Blackstone_Online_Gateway
 * @Plugin Name: Blackstone Online Gateway
 * @Plugin URI: http://www.blackstonemerchant.com/
 * @Description: Blackstone Merchant custom payment gateway integration with Woocommerce.
 * @Author: Blackstone
 * @Author URI: https://blackstoneonline.com/
 * @Version: 4.7.5
 * @License: GPLv2 or later
 * @License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * @Text Domain: blackstone-online-gateway
 * @Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BMSPAY_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

require_once BMSPAY_PLUGIN_PATH . 'classes/class-bmspay-logger.php';
require_once BMSPAY_PLUGIN_PATH . 'classes/class-bmspay-constants.php';
require_once BMSPAY_PLUGIN_PATH . 'classes/class-bmspay-credential-manager.php';
require_once BMSPAY_PLUGIN_PATH . 'classes/class-bmspay-response-parser.php';
require_once BMSPAY_PLUGIN_PATH . 'classes/class-bmspay-request-builder.php';
require_once BMSPAY_PLUGIN_PATH . 'classes/class-bmspay-api-client.php';
require_once BMSPAY_PLUGIN_PATH . 'classes/class-bmspay-card-validator.php';
require_once BMSPAY_PLUGIN_PATH . 'classes/class-bmspay-payment-form-renderer.php';

include_once BMSPAY_PLUGIN_PATH . 'includes/bmspay_api_refund_integration.php';

add_action( 'plugins_loaded', 'bmspay_blackstone_init', 0 );

/**
 * Initialize the Blackstone payment gateway.
 *
 * 
 * @return void
 */
function bmspay_blackstone_init() {
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
		return;
	}

	include_once __DIR__ . '/bmspay-blackstone-payment.php';

	add_filter( 'woocommerce_payment_gateways', 'bmspay_add_blackstone_gateway' );
}

/**
 * Add Blackstone gateway to WooCommerce payment gateways.
 *
 * 
 * @param array $methods Payment gateways.
 * @return array
 */
function bmspay_add_blackstone_gateway( $methods ) {
	$methods[] = 'BMSPay_Blackstone_Payment';
	return $methods;
}

/**
 * Initialize refund integration.
 *
 * 
 * @return void
 */
function bmspay_refund_plugin_init() {
	new BMSPAY_API_Refund_Integration();
}

add_action( 'plugins_loaded', 'bmspay_refund_plugin_init' );

/**
 * Add plugin action links.
 *
 * 
 * @param array $links Plugin links.
 * @return array
 */
function bmspay_blackstone_action_links( $links ) {
	$plugin_links = array(
		'<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) . '">' . esc_html__( 'Settings', 'blackstone-online-gateway' ) . '</a>',
	);
	return array_merge( $plugin_links, $links );
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'bmspay_blackstone_action_links' );

/**
 * AJAX handler for clearing plugin logs.
 *
 * 
 * @return void
 */
add_action( 'wp_ajax_bmspay_clear_logs', 'bmspay_ajax_clear_logs' );
function bmspay_ajax_clear_logs() {
	check_ajax_referer( 'bmspay_clear_logs_nonce', 'nonce' );

	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_send_json_error( array( 'message' => 'Unauthorized' ), 403 );
	}

	$upload_dir = wp_upload_dir();
	$logs_dir   = $upload_dir['basedir'] . '/wc-logs';

	$deleted = 0;
	if ( is_dir( $logs_dir ) ) {
		// Delete all bmspay-*.log and place-order-debug-*.log files
		$patterns = array( 'bmspay-*.log', 'place-order-debug-*.log' );
		
		foreach ( $patterns as $pattern ) {
			$files = glob( $logs_dir . '/' . $pattern );
			if ( is_array( $files ) ) {
				foreach ( $files as $file ) {
					if ( is_file( $file ) && unlink( $file ) ) {
						$deleted++;
					}
				}
			}
		}
	}

	wp_send_json_success( array( 'message' => sprintf( __( '%d log files deleted.', 'blackstone-online-gateway' ), $deleted ) ) );
}
