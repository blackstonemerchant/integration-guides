<?php
class bmspay_Blackstone_Payment extends WC_Payment_Gateway_CC
{
  public $environment;
  public $environment_3ds;
  public $app_key;
  public $api_username;
  public $api_password;
  public $api_mid;
  public $api_cid;
  public $app_type;
  public $label_surcharge;
  public $label_card_difference;

  function __construct()
  {
    $this->id = "bmspay_blackstone_payment";
    $this->method_title = __("Blackstone", 'bmspay-blackstone-payment');
    $this->method_description = __("Blackstone Payment Gateway Plug-in for WooCommerce", 'bmspay-blackstone-payment');
    $this->title = __("Blackstone", 'bmspay-blackstone-payment');
    $this->icon = null;
    $this->has_fields = true;
    $this->supports = array('default_credit_card_form');
    $this->init_form_fields();
    $this->init_settings();

    foreach ($this->settings as $setting_key => $value) {
      $this->$setting_key = $value;
    }

    add_action('admin_notices', array($this,  'do_ssl_check'));
    remove_action('woocommerce_review_order_after_submit', 'woocommerce_order_submit_button', 10);

    if (is_admin()) {
      add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }
  }

  public function init_form_fields()
  {
    $this->form_fields = array(
      'enabled'      => array(
        'title'        => __('Enable / Disable', 'bmspay-blackstone-payment'),
        'label'        => __('Enable this payment gateway', 'bmspay-blackstone-payment'),
        'type'         => 'checkbox',
        'default'      => 'no',
      ),
      'title'        => array(
        'title'        => __('Title', 'bmspay-blackstone-payment'),
        'type'         => 'text',
        'desc_tip'     => __('Payment title of checkout process.', 'bmspay-blackstone-payment'),
        'default'      => __('Credit card', 'bmspay-blackstone-payment'),
      ),
      'description'  => array(
        'title'        => __('Description', 'bmspay-blackstone-payment'),
        'type'         => 'textarea',
        'desc_tip'     => __('Payment title of checkout process.', 'bmspay-blackstone-payment'),
        'default'      => __('Successfully payment through credit card.', 'bmspay-blackstone-payment'),
        'css'          => 'max-width:450px;'
      ),
      'api_username' => array(
        'title'        => __('Username', 'bmspay-blackstone-payment'),
        'type'         => 'text',
        'desc_tip'     => __('This is the username provided by Blackstone when you signed up for an account.', 'bmspay-blackstone-payment'),
      ),
      'api_password' => array(
        'title'        => __('Password', 'bmspay-blackstone-payment'),
        'type'         => 'password',
        'desc_tip'     => __('This is the password provided by Blackstone when you signed up for an account.', 'bmspay-blackstone-payment'),
      ),
      'api_mid'      => array(
        'title'        => __('MID', 'bmspay-blackstone-payment'),
        'type'         => 'text',
        'desc_tip'     => __('This is the MID code provided by Blackstone when you signed up for an account.', 'bmspay-blackstone-payment'),
      ),
      'api_cid'      => array(
        'title'        => __('CID', 'bmspay-blackstone-payment'),
        'type'         => 'text',
        'desc_tip'     => __('This is the CID code provided by Blackstone when you signed up for an account.', 'bmspay-blackstone-payment'),
      ),
      'app_type'     => array(
        'title'        => __('App Type', 'bmspay-blackstone-payment'),
        'type'         => 'text',
        'desc_tip'     => __('This is the App Type provided by Blackstone when you signed up for an account.', 'bmspay-blackstone-payment'),
      ),
      'app_key'      => array(
        'title'        => __('App Key', 'bmspay-blackstone-payment'),
        'type'         => 'password',
        'desc_tip'     => __('This is the App Key provided by Blackstone when you signed up for an account.', 'bmspay-blackstone-payment'),
      ),
      'environment'  => array(
        'title'        => __('Test Mode', 'bmspay-blackstone-payment'),
        'label'        => __('Enable Test Mode', 'bmspay-blackstone-payment'),
        'type'         => 'checkbox',
        'desc_tip'     => __('This is the sandbox of the gateway.', 'bmspay-blackstone-payment'),
        'default'      => 'no',
      ),
      'environment_3ds'  => array(
        'title'        => __('3D Secure Test Mode', 'bmspay-blackstone-payment'),
        'label'        => __('Enable 3D Secure Test Mode', 'bmspay-blackstone-payment'),
        'type'         => 'checkbox',
        'desc_tip'  => __('This is the sandbox of 3D Secure.', 'bmspay-blackstone-payment'),
        'default'      => 'no',
      ),
      'label_surcharge' => array(
        'title'        => __('Surcharge Label', 'bmspay-blackstone-payment'),
        'type'         => 'text',
        'desc_tip'     => __('This is the name that will be shown to your customers wherever a surcharge is applied (for example, in the order summary or invoice).', 'bmspay-blackstone-payment'),
        'default'      => 'Surcharge',
      ),
      'label_card_difference' => array(
        'title'        => __('Dual Pricing Label', 'bmspay-blackstone-payment'),
        'type'         => 'text',
        'desc_tip'     => __('This is the name that will be shown to your customers wherever the card difference (dual pricing) is applied. For example, in the order summary or invoice.', 'bmspay-blackstone-payment'),
        'default'      => 'Dual pricing',
      ),
    );
  }

  public function payment_fields()
  {
    $user_id = get_current_user_id();
    $saved_methods = WC_Payment_Tokens::get_customer_tokens($user_id);

    echo '<div id="saved-payment-methods" class="payment-methods-container">';

    if ($saved_methods) {
      $label_text = (get_locale() === 'es_ES') ? 'Seleccionar una tarjeta guardada:' : 'Select a saved card:';
      echo '<p class="payment-methods-title">' . __($label_text, 'your-text-domain') . '</p>';
      echo '<ul class="wc-saved-payment-methods">';

      foreach ($saved_methods as $token) {
        $last4 = $token->get_last4();
        $token_id = $token->get_id();

        echo '<li class="payment-option">';
        echo '<input type="radio" id="token-' . esc_attr($token_id) . '" name="wc-saved-payment-token" value="' . esc_attr($token_id) . '" />';
        echo '<label for="token-' . esc_attr($token_id) . '" class="payment-label">';
        echo '<span class="card-icon">💳</span> ';
        $label_text = (get_locale() === 'es_ES') ? 'Tarjeta que termina en:' : 'Card ending in:';
        echo esc_html__($label_text, 'your-text-domain') . ' ' . esc_html($last4);
        echo '</label>';
        echo '</li>';
      }

      echo '</ul>';
    } else {
      $label_text = (get_locale() === 'es_ES') ? 'No tienes métodos de pago guardados' : 'You do not have saved payment methods';
      echo '<p class="no-saved-methods">' . __($label_text, 'your-text-domain') . '</p>';
    }

    echo '<ul class="wc-saved-payment-methods">';
    echo '<li class="payment-option">';
    echo '<input type="radio" id="token-new" name="wc-saved-payment-token" value="new" checked />';
    echo '<label for="token-new" class="payment-label">';
    $label_text = (get_locale() === 'es_ES') ? 'Utilice un nuevo método de pago' : 'Use a new payment method';
    echo '<span class="card-icon"></span> ' . __($label_text, 'your-text-domain');
    echo '</label>';
    echo '</li>';
    echo '</ul>';

    echo '</div>';

    // Sección para ingresar una nueva tarjeta
    echo '<div id="new-payment-method" class="new-payment-method-section">';
    $label_text = (get_locale() === 'es_ES') ? 'Introduzca los datos de su tarjeta:' : 'Enter your card details:';
    echo '<p class="new-payment-title">' . __($label_text, 'your-text-domain') . '</p>';
    $this->form();
    echo '</div>';
?>
    <script type="text/javascript">
      jQuery(document).ready(function($) {
        $('input[name="wc-saved-payment-token"]').change(function() {
          if ($(this).val() === 'new') {
            $('#new-payment-method').slideDown();
          } else {
            $('#new-payment-method').slideUp();
          }
        });

        if ($('input[name="wc-saved-payment-token"]:checked').val() !== 'new') {
          $('#new-payment-method').hide();
        }
      });
    </script>

    <style>
      .payment-methods-container {
        background: #f8f8f8;
        padding: 15px;
        border-radius: 10px;
      }

      .payment-methods-title,
      .new-payment-title {
        font-weight: bold;
        margin-bottom: 10px;
      }

      .wc-saved-payment-methods {
        list-style: none;
        padding: 0;
      }

      .payment-option {
        display: flex;
        align-items: center;
        padding: 10px;
        border: 1px solid #ddd;
        background: white;
        border-radius: 8px;
        margin-bottom: 8px;
        transition: background 0.3s ease;
      }

      .payment-option:hover {
        background: #e8f0fe;
      }

      .payment-label {
        display: flex;
        align-items: center;
        width: 100%;
        cursor: pointer;
      }

      .card-icon {
        font-size: 20px;
        margin-right: 10px;
      }

      .new-payment-method-section {
        margin-top: 20px;
        padding: 15px;
        background: rgb(248, 249, 250);
        border-radius: 10px;
      }
    </style>
    <?php
  }

  public function otherAmount($total)
  {
    $surcharge_data = $this->get_cached_surcharge_data();
    $surcharge_merchant = $surcharge_data['response_SurchargePercent'];
    $surcharge_enabled = $surcharge_data['response_SurchargeEnabled'];
    $card_difference_percent = $surcharge_data['response_CardDifferencePercent'];
    $card_difference_enabled = $surcharge_data['response_CardDifferenceEnabled'];

    global $wp;
    $is_pay_for_order = isset($wp->query_vars['order-pay']);

    if ($is_pay_for_order) {
      $order_id = absint($wp->query_vars['order-pay']);
      $order = wc_get_order($order_id);

      $cart_total = $order->get_subtotal();
      $shipping_total = $order->get_shipping_total();
      $discount_total = $order->get_discount_total();

      $order_total = $cart_total + $shipping_total - $discount_total;
    } else {
      $cart_total = WC()->cart->get_subtotal();
      $shipping_total = WC()->cart->get_shipping_total();
      $discount_total = WC()->cart->get_discount_total();

      $order_total = $cart_total + $shipping_total - $discount_total;
    }

    $total_surcharge = 0;
    $total_card_difference = 0;

    if ($surcharge_enabled) {
      $total_surcharge = number_format(($order_total * $surcharge_merchant / 100), 2);
    }
    if ($card_difference_enabled) {
      $total_card_difference = number_format(($order_total * $card_difference_percent / 100), 2);
    }
    if ($this->enabled == 'yes') {
      return (object)[
        'total_surcharge' => $total_surcharge,
        'total_card_difference' => $total_card_difference,
        'total' => number_format($order_total, 2),
      ];
    }

    return (object)[
      'total_surcharge' => 0,
      'total_card_difference' => 0,
      'total' => number_format($total, 2),
    ];
  }

  public function get_cached_surcharge_data()
  {
    $surcharge_cache_key = 'bmspay_surcharge_data_' . get_current_user_id();
    $surcharge_data = get_transient($surcharge_cache_key);
    delete_transient($surcharge_cache_key);

    if ($surcharge_data === false) {
      $surcharge_data = $this->get_merchant_setting();
      delete_transient($surcharge_cache_key);
      set_transient($surcharge_cache_key, $surcharge_data, MINUTE_IN_SECONDS);
    }
    return $surcharge_data;
  }
  public function get_merchant_setting()
  {
    $data = $this->prepare_credential_data(false);

    $environment_url = $this->get_basic_url('BusinessSettings', true);

    $response = wp_remote_post($environment_url, array(
      'method' => 'POST',
      'body' => http_build_query($data),
      'timeout' => 45,
      'headers' => array(),
    ));

    $surcharge_percent = 0;
    $surcharge_enabled = 0;
    $card_difference_percent = 0;
    $card_difference_enabled = 0;
    $threed_secure_enabled = 0;

    if (is_wp_error($response)) {
      wc_add_notice(__('Payment error:', 'bmspay-blackstone-payment') . ' ' . $response->get_error_message(), 'error');
    } else {
      $response_body = wp_remote_retrieve_body($response);
      $response_data = json_decode($response_body, true);


      if (isset($response_data['SurchargeEnabled']) && $response_data['SurchargeEnabled'] === true) {
        $surcharge_percent = $response_data['SurchargePercent'];
        $surcharge_enabled = true;
      }
      if (isset($response_data['CardDifferenceEnabled']) && $response_data['CardDifferenceEnabled'] === true) {
        $card_difference_percent = $response_data['CardDifferencePercent'];
        $card_difference_enabled = true;
      }
      if (isset($response_data['ThreeDSecureEnabled']) && $response_data['ThreeDSecureEnabled'] === true) {
        $threed_secure_enabled = true;
      }
    }
    $array = array(
      'response_SurchargeEnabled' => $surcharge_enabled,
      'response_SurchargePercent' => $surcharge_percent,
      'response_CardDifferenceEnabled' => $card_difference_enabled,
      'response_CardDifferencePercent' => $card_difference_percent,
      'response_ThreeDSecureEnabled' => $threed_secure_enabled
    );
    return $array;
  }
  public function get_merchant_tokenthreeds()
  {
    $data = $this->prepare_credential_data(true);
    $environment_url = $this->get_basic_url('Auth/TokenThreeDS', false);

    $response = wp_remote_post($environment_url, array(
      'method' => 'POST',
      'body' => http_build_query($data),
      'timeout' => 45,
      'headers' => array(),
    ));

    return $this->process_threeds_response($response);
  }

  private function prepare_credential_data($threeds = false)
  {
    if ($threeds && $this->environment_3ds == 'yes') {
      return array(
        "mid" => "98208",
        "UserName" =>  "617D46A6-3A1A-4A67-850A-89F7E4F48049",
        "Password" =>  "CYC-4, LLC",
        "AppType" =>  "11200",
        "AppKey" =>  "563C17A4-A4E3-4A6F-BBF6-FC8B8B8E7F9F",
        "cid" =>  "6310",
        "IpAddress" => $_SERVER['REMOTE_ADDR'],
        "Source" => "ApiClient",
        "UserTest" => "True"
      );
    }
    return array(
      "mid" => $this->environment == 'yes' ? "76074" : $this->api_mid,
      "UserName" => $this->environment == 'yes' ? "nicolas" : $this->api_username,
      "Password" => $this->environment == 'yes' ? "password1" : $this->api_password,
      "AppType" => $this->environment == 'yes' ? "1" : $this->app_type,
      "AppKey" => $this->environment == 'yes' ? "12345" : $this->app_key,
      "cid" => $this->environment == 'yes' ? "260" : $this->api_cid,
      "IpAddress" => $_SERVER['REMOTE_ADDR'],
      "Source" => "ApiClient",
      "UserTest" => $this->environment == 'yes' ? "True" : "False"
    );
  }

  private function get_basic_url($endpoint, $is_test = false)
  {
    $base_url = 'https://services.bmspay.com/';
    $path = $is_test ? 'testing/api/' : 'api/';
    return ($this->environment == 'yes') ? $base_url . $path . $endpoint : $base_url . 'api/' . $endpoint;
  }

  private function process_threeds_response($response)
  {
    if (is_wp_error($response)) {
      wc_add_notice(__('Payment error:', 'bmspay-blackstone-payment') . ' ' . $response->get_error_message(), 'error');
      return array('response_ApiKey' => '', 'response_Token' => '');
    }

    $response_body = wp_remote_retrieve_body($response);
    $response_data = json_decode($response_body, true);
    WC()->session->__unset('threed_secure_apikey');
    WC()->session->__unset('threed_secure_token');
    WC()->session->set('threed_secure_apikey', isset($response_data['ApiKey']) ? $response_data['ApiKey'] : '');
    WC()->session->set('threed_secure_token', isset($response_data['Token']) ? $response_data['Token'] : '');

    return array(
      'response_ApiKey' => isset($response_data['ApiKey']) ? $response_data['ApiKey'] : '',
      'response_Token' => isset($response_data['Token']) ? $response_data['Token'] : '',
    );
  }
  function evaluarResultado3DS($data)
  {
    $status = $data['status'] ?? null;

    switch ($status) {
      case 'Y':
        return [
          'success' => true,
          'message' => 'Autenticación 3D Secure exitosa (Status: Y)',
        ];
      case 'A':
        return [
          'success' => true,
          'message' => 'Autenticación 3DS fue realizada por el emisor pero no fue friccional (Status: A)',
        ];
      case 'N':
        $reason = $data['transStatusReasonDetail'] ?? 'Transacción no autenticada';
        return [
          'success' => false,
          'message' => "Autenticación fallida (Status: N). Motivo: {$reason}",
        ];
      case 'C':
        $reason = $data['transStatusReasonDetail'] ?? 'Desafío requerido; Se necesita autenticación adicional';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: C). Motivo: {$reason}",
        ];
      case 'R':
        $reason = $data['transStatusReasonDetail'] ?? 'Autenticación / Verificación de cuenta rechazada; El emisor está rechazando la autenticación/verificación y solicita que no se intente la autorización.';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: R). Motivo: {$reason}",
        ];
      case 'U':
        $reason = $data['transStatusReasonDetail'] ?? 'Fallo técnico o no disponible';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: U). Motivo: {$reason}",
        ];
      default:
        $message = (get_locale() === 'es_ES') ? 'No se pudo completar la verificación de su método de pago. Intente nuevamente o use otro método' : 'The verification of your payment method could not be completed. Please try again or use a different method.';
        if (WC()->session->get('threed_secure_enabled')) {
          return [
            'success' => false,
            'message' => $message,
          ];
        } else {
          return [
            'success' => false,
            'message' => $message,
          ];
        }
    }
  }

  public function process_payment($order_id)
  {

    $SecureData = '';
    $SecureTransactionId = '';
    // if (isset($_POST['threeds_response']) && WC()->session->get('threed_secure_enabled')) {
    if (isset($_POST['threeds_response'])) {
      try {
        $threedsData = json_decode(stripslashes($_POST['threeds_response']), true);

        $resultado = $this->evaluarResultado3DS($threedsData);
      } catch (Exception $e) {
        error_log('Error procesando 3DS: ' . $e->getMessage());
        $label_text = (get_locale() === 'es_ES') ? 'No se pudo completar la autenticación: ' . $e->getMessage() : 'Authentication could not be completed: ' . $e->getMessage();
        wc_add_notice(__($label_text, 'bmspay-blackstone-payment'), 'error');
        return;
      }
      if ($resultado['success']) {
        $SecureData = $threedsData['authenticationValue'] ?? '';
        $SecureTransactionId = $threedsData['threeDsTransactionId'] ?? '';
      } else {
        wc_add_notice($resultado['message'], 'error');
        return;
      }
    }

    global $woocommerce;
    $Source = "BPaydPlugin";
    $credentials = $this->prepare_credential_data(false);
    $is_test = $credentials['UserTest'];
    $customer_order = new WC_Order($order_id);

    if (isset($_POST['wc-saved-payment-token']) && $_POST['wc-saved-payment-token'] !== 'new') {

      $token_id = sanitize_text_field($_POST['wc-saved-payment-token']);
      $token = WC_Payment_Tokens::get($token_id);

      if ($token && $token->get_user_id() === get_current_user_id()) {

        $gateway_id = $token->get_gateway_id();
        $last4 = $token->get_last4();
        $expiry_month = $token->get_expiry_month();
        $expiry_year = $token->get_expiry_year();
        $token_string = $token->get_token();

        $environment_url = $this->get_basic_url('Transactions/SaleWithToken', false);

        $full_name = ($customer_order->get_billing_first_name() . ' ' . $customer_order->get_billing_last_name());

        $otherAmount = $this->otherAmount($customer_order->get_total());

        $userTransactionNumber = (md5(uniqid($customer_order->get_order_number(), true)));

        $payload = array(
          "Token"                 => $token_string,
          "UserName"              => $credentials['UserName'],
          "Password"              => $credentials['Password'],
          "mid"                   => $credentials['mid'],
          "cid"                   => $credentials['cid'],
          "AppKey"                => $credentials['AppKey'],
          "AppType"               => $credentials['AppType'],
          "Amount"                => $otherAmount->total,
          "TaxAmount"             => 0,
          "TipAmount"             => 0,
          "SurchargeAmount"       => $otherAmount->total_surcharge,
          "CardDifferenceAmount"  => $otherAmount->total_card_difference,
          "TransactionType"       => 2,
          "Track2"                => "",
          "ZipCode"               => $customer_order->get_billing_postcode(),
          "ExpDate"               => ($expiry_month . substr($expiry_year, 2, 2)),
          "NameOnCard"            => $full_name,
          "UserTransactionNumber" => $userTransactionNumber,
          "Source"                => $Source,
          "SecureData"           => $SecureData,
          "PosCode"              => "Moto",
          "SecureTransactionId"  => $SecureTransactionId,

          "x_first_name"          => $customer_order->get_billing_first_name(),
          "x_last_name"           => $customer_order->get_billing_last_name(),
          "x_address"             => $customer_order->get_billing_address_1(),
          "x_city"                => $customer_order->get_billing_city(),
          "x_state"               => $customer_order->get_billing_state(),
          "x_zip"                 => $customer_order->get_billing_postcode(),
          "x_country"             => $customer_order->get_billing_country(),
          "x_phone"               => $customer_order->get_billing_phone(),
          "x_email"               => $customer_order->get_billing_email(),

          // Customer fields
          "SaveCustomer"           => 'True',
          "IsTest"                 => $is_test,
          "CustomerId"             => $order_id,
          "CustomerPhone"          => $customer_order->get_billing_phone(),
          "CustomerEmail"          => $customer_order->get_billing_email(),
          "CustomerCountry"        => $customer_order->get_billing_country(),
          "CustomerState"          => $customer_order->get_billing_state(),
          "CustomerCity"           => $customer_order->get_billing_city(),
          "CustomerAddress"        => $customer_order->get_billing_address_1(),
          "OrderReference"         => $order_id,

          "x_ship_to_first_name"   => $customer_order->get_shipping_first_name(),
          "x_ship_to_last_name"    => $customer_order->get_shipping_last_name(),
          "x_ship_to_company"      => $customer_order->get_shipping_company(),
          "x_ship_to_address"      => $customer_order->get_shipping_address_1(),
          "x_ship_to_city"         => $customer_order->get_shipping_city(),
          "x_ship_to_country"      => $customer_order->get_shipping_country(),
          "x_ship_to_state"        => $customer_order->get_shipping_state(),
          "x_ship_to_zip"          => $customer_order->get_shipping_postcode(),
          "x_cust_id"              => $customer_order->get_user_id(),
          "x_customer_ip"          => $_SERVER['REMOTE_ADDR'],
        );

        $response = wp_remote_post($environment_url, array(
          'method' => 'POST',
          'body' => http_build_query($payload),
          'timeout' => 45,
          'headers' => array(),
        ));

        if (is_wp_error($response)) {
          wc_add_notice(__('Payment error:', 'bmspay-blackstone-payment') . ' ' . $response->get_error_message(), 'error');
          return;
        }

        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        error_log(print_r($environment_url, true));
        error_log(print_r($payload, true));
        error_log(print_r($response_data, true));

        if (isset($response_data['ResponseCode']) && $response_data['ResponseCode'] == "200") {

          $customer_order->add_order_note(__('Blackstone complete payment.', 'bmspay-blackstone-payment'));

          if (isset($response_data['ServiceReferenceNumber'])) {
            $ServiceReferenceNumber = $response_data['ServiceReferenceNumber'];
            $customer_order->update_meta_data('_bmspay_service_reference_number', $ServiceReferenceNumber);
            $customer_order->add_order_note(__('Transaction ID: ', 'bmspay-blackstone-payment') . $ServiceReferenceNumber);
          }
          if (isset($payload['UserTransactionNumber'])) {
            $UserTransactionNumber = $payload['UserTransactionNumber'];
            $customer_order->update_meta_data('_bmspay_transaction_number', $UserTransactionNumber);
            $customer_order->add_order_note(__('User Transaction Number: ', 'bmspay-blackstone-payment') . $UserTransactionNumber);
          }
          $customer_order->payment_complete();
          $woocommerce->cart->empty_cart();

          $customer_order->save();

          return array(
            'result'   => 'success',
            'redirect' => $this->get_return_url($customer_order),
          );
        } else {
          $msg = $this->get_message_error($response_data);
          wc_add_notice($msg, 'error');
          $msg = $this->get_message_error_full($response_data, $userTransactionNumber);
          $customer_order->add_order_note('Error: ' . $msg);
        }
      } else {
        wc_add_notice(__('Invalid payment method selected.', 'your-text-domain'), 'error');
        return;
      }
    } else {
      $environment_url = $this->get_basic_url('Transactions/Sale', false);

      $full_name = ($customer_order->get_billing_first_name() . ' ' . $customer_order->get_billing_last_name());

      $otherAmount = $this->otherAmount($customer_order->get_total());

      $userTransactionNumber = (md5(uniqid($customer_order->get_order_number(), true)));

      $payload = array(
        "UserName"              => $credentials['UserName'],
        "Password"              => $credentials['Password'],
        "mid"                   => $credentials['mid'],
        "cid"                   => $credentials['cid'],
        "AppKey"                => $credentials['AppKey'],
        "AppType"               => $credentials['AppType'],
        "Amount"                => $otherAmount->total,
        "TaxAmount"             => 0,
        "TipAmount"             => 0,
        "SurchargeAmount"       => $otherAmount->total_surcharge,
        "CardDifferenceAmount"  => $otherAmount->total_card_difference,
        "TransactionType"       => 1,
        "Track2"                => "",
        "ZipCode"               => $this->environment == 'yes' ? "12345" : $customer_order->get_billing_postcode(),
        "ExpDate"               => str_replace(array('/', ' '), '', $_POST['bmspay_blackstone_payment-card-expiry']),
        "CardNumber"            => str_replace(array(' ', '-'), '', $_POST['bmspay_blackstone_payment-card-number']),
        "CVN"                   => ((isset($_POST['bmspay_blackstone_payment-card-cvc'])) ? $_POST['bmspay_blackstone_payment-card-cvc'] : ''),
        "NameOnCard"            => $full_name,

        "UserTransactionNumber" => $userTransactionNumber,
        "Source"                => $Source,
        "SecureData"            => $SecureData,
        "PosCode"               => "Moto",
        "SecureTransactionId"   => $SecureTransactionId,
        "SaveToken"             => "True",

        "x_first_name"          => $customer_order->get_billing_first_name(),
        "x_last_name"           => $customer_order->get_billing_last_name(),
        "x_address"             => $customer_order->get_billing_address_1(),
        "x_city"                => $customer_order->get_billing_city(),
        "x_state"               => $customer_order->get_billing_state(),
        "x_zip"                 => $customer_order->get_billing_postcode(),
        "x_country"             => $customer_order->get_billing_country(),
        "x_phone"               => $customer_order->get_billing_phone(),
        "x_email"               => $customer_order->get_billing_email(),

        // Customer fields
        "SaveCustomer"           => 'True',
        "IsTest"                 => $is_test,
        "CustomerId"             => $order_id,
        "CustomerPhone"          => $customer_order->get_billing_phone(),
        "CustomerEmail"          => $customer_order->get_billing_email(),
        "CustomerCountry"        => $customer_order->get_billing_country(),
        "CustomerState"          => $customer_order->get_billing_state(),
        "CustomerCity"           => $customer_order->get_billing_city(),
        "CustomerAddress"        => $customer_order->get_billing_address_1(),
        "OrderReference"         => $order_id,

        "x_ship_to_first_name"  => $customer_order->get_shipping_first_name(),
        "x_ship_to_last_name"   => $customer_order->get_shipping_last_name(),
        "x_ship_to_company"     => $customer_order->get_shipping_company(),
        "x_ship_to_address"     => $customer_order->get_shipping_address_1(),
        "x_ship_to_city"        => $customer_order->get_shipping_city(),
        "x_ship_to_country"     => $customer_order->get_shipping_country(),
        "x_ship_to_state"       => $customer_order->get_shipping_state(),
        "x_ship_to_zip"         => $customer_order->get_shipping_postcode(),
        "x_cust_id"             => $customer_order->get_user_id(),
        "x_customer_ip"         => $_SERVER['REMOTE_ADDR'],
      );

      $response = wp_remote_post($environment_url, array(
        'method'               => 'POST',
        'headers'              => array('Content-Type' => 'application/x-www-form-urlencoded'),
        'body'                 => http_build_query($payload),
        'timeout'              => 90,
        'sslverify'            => false,
      ));

      if (is_wp_error($response))
        throw new Exception(__('There is issue for connectin payment gateway. Sorry for the inconvenience.', 'bmspay-blackstone-payment'));
      if (empty($response['body']))
        throw new Exception(__('Blackstone\'s Response was not get any data.', 'bmspay-blackstone-payment'));

      $response_body = wp_remote_retrieve_body($response);
      $resp = json_decode($response_body, true);

      error_log(print_r($environment_url, true));
      error_log(print_r($payload, true));
      error_log(print_r($resp, true));

      if (isset($resp['ResponseCode']) && $resp['ResponseCode'] == "200") {

        $customer_order->add_order_note(__('Blackstone complete payment.', 'bmspay-blackstone-payment'));

        if (isset($resp['ServiceReferenceNumber'])) {
          $ServiceReferenceNumber = $resp['ServiceReferenceNumber'];
          $customer_order->update_meta_data('_bmspay_service_reference_number', $ServiceReferenceNumber);
          $customer_order->add_order_note(__('Transaction ID: ', 'bmspay-blackstone-payment') . $ServiceReferenceNumber);
        }
        if (isset($payload['UserTransactionNumber'])) {
          $UserTransactionNumber = $payload['UserTransactionNumber'];
          $customer_order->update_meta_data('_bmspay_transaction_number',  $UserTransactionNumber);
          $customer_order->add_order_note(__('User Transaction Number: ', 'bmspay-blackstone-payment') . $UserTransactionNumber);
        }
        $customer_order->payment_complete();
        $woocommerce->cart->empty_cart();

        $customer_order->save();


        if (isset($resp['Token'])) {

          $user_id = $customer_order->get_user_id();

          $last4 = sanitize_text_field($resp['LastFour']);
          $card_type = sanitize_text_field($resp['CardType']);
          $expiry_month = substr(sanitize_text_field($payload['ExpDate']), 0, 2);
          $expiry_year = "20" . substr(sanitize_text_field($payload['ExpDate']), 2, 2);

          $existing_tokens = WC_Payment_Tokens::get_tokens(['user_id' => $user_id, 'type' => 'CC']);

          $card_exists = false;

          foreach ($existing_tokens as $existing_token) {
            if (
              $existing_token->get_last4() === $last4 &&
              $existing_token->get_expiry_month() === $expiry_month &&
              $existing_token->get_expiry_year() === $expiry_year &&
              $existing_token->get_card_type() === $card_type
            ) {
              $card_exists = true;
              break;
            }
          }
          if (isset($_POST['save_card']) && $_POST['save_card'] == '1') {
            if (!$card_exists) {
              $token = new WC_Payment_Token_CC();
              $token->set_token($resp['Token']);
              $token->set_gateway_id($this->id);
              $token->set_user_id($user_id);
              $token->set_last4($last4);
              $token->set_card_type($card_type);
              $token->set_expiry_month($expiry_month);
              $token->set_expiry_year($expiry_year);

              $token->save();
            }
          }
        }

        return array(
          'result'   => 'success',
          'redirect' => $this->get_return_url($customer_order),
        );
      } else {
        $msg = $this->get_message_error($resp);
        wc_add_notice($msg, 'error');
        $msg = $this->get_message_error_full($resp, $userTransactionNumber);
        $customer_order->add_order_note('Error: ' . $msg);
      }
    }
  }

  public function get_message_error($response_data)
  {
    $msg = $response_data['Msg'][0] ?? __('No message provided', 'bmspay-blackstone-payment');
    $verbiage = $response_data['verbiage'] ?? __('No verbiage provided', 'bmspay-blackstone-payment');
    $avs = $response_data['avs'] ?? __('No AVS response', 'bmspay-blackstone-payment');
    $cv = $response_data['cv'] ?? __('No CV response', 'bmspay-blackstone-payment');
    error_log("$msg . More details: $verbiage. Extra validation: Zip ($avs), CVV ($cv)");
    return "$msg . More details: $verbiage.";
  }
  public function get_message_error_full($response_data, $userTransactionNumber)
  {
    $msg = $response_data['Msg'][0] ?? __('No message provided', 'bmspay-blackstone-payment');
    $verbiage = $response_data['verbiage'] ?? __('No verbiage provided', 'bmspay-blackstone-payment');
    $avs = $response_data['avs'] ?? __('No AVS response', 'bmspay-blackstone-payment');
    $cv = $response_data['cv'] ?? __('No CV response', 'bmspay-blackstone-payment');
    return "$msg . More details: $verbiage. Extra validation: Zip ($avs), CVV ($cv), UserTransactionNumber: $userTransactionNumber";
  }

  public function validate_fields()
  {
    return true;
  }
  public function do_ssl_check()
  {
    if ($this->enabled == "yes") {
      if (get_option('woocommerce_force_ssl_checkout') == "no") {
        // echo "<div class=\"error\"><p>" . sprintf(__("<strong>%s</strong> is enabled and WooCommerce is not forcing the SSL certificate on your checkout page. Please ensure that you have a valid SSL certificate and that you are <a href=\"%s\">forcing the checkout pages to be secured.</a>"), $this->method_title, admin_url('admin.php?page=wc-settings&tab=checkout')) . "</p></div>";
      }
    }
  }
  public function getEnvironment()
  {
    return $this->environment;
  }
  public function getEnvironment3DS()
  {
    return $this->environment_3ds;
  }
  public function isPluginActive()
  {
    return $this->enabled;
  }
  public function getLabelSurcharge()
  {
    return $this->label_surcharge;
  }
  public function getLabelCardDifference()
  {
    return $this->label_card_difference;
  }
}

function bmspay_blackstone_add_payment_gateway($gateways)
{
  $gateways[] = 'bmspay_Blackstone_Payment';
  return $gateways;
}

add_filter('woocommerce_payment_gateways', 'bmspay_blackstone_add_payment_gateway');

add_action('woocommerce_review_order_before_order_total', function () {
  $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();
  $cart_total = 0;
  if (WC()->cart->get_cart_contents_count() > 0) {
    $cart_total = WC()->cart->get_subtotal() + WC()->cart->get_shipping_total() - WC()->cart->get_discount_total();
  } else {
    $cart_total = WC()->session->get('blackstone_cart_subtotal');
    error_log('Subtotal recuperado de la sesión: ' . $cart_total);
    if ($cart_total === null || $cart_total === false) {
      $cart_total = 0;
    }
  }
  $should_apply_fees = getStatePlugin();
  $surcharge_data = $bmspay_Blackstone_Payment->get_cached_surcharge_data();
  $surcharge_merchant = $surcharge_data['response_SurchargePercent'];
  $surcharge_enabled = $surcharge_data['response_SurchargeEnabled'];
  $card_difference_percent = $surcharge_data['response_CardDifferencePercent'];
  $card_difference_enabled = $surcharge_data['response_CardDifferenceEnabled'];
  $threed_secure_enabled = $surcharge_data['response_ThreeDSecureEnabled'];

  WC()->session->__unset('surcharge_amount');
  WC()->session->__unset('card_difference_amount');
  WC()->session->__unset('threed_secure_enabled');
  WC()->session->__unset('threed_secure_apikey');
  WC()->session->__unset('threed_secure_token');

  WC()->session->set('threed_secure_enabled', $threed_secure_enabled);
  if (isset($_POST['payment_method'])) {
    $payment_method = sanitize_text_field($_POST['payment_method']);
    if ($payment_method === 'bmspay_blackstone_payment') {
      if ($surcharge_enabled && $should_apply_fees) {
        $surcharge = number_format(($cart_total * $surcharge_merchant / 100), 2);
        WC()->session->set('surcharge_amount', $surcharge);
        WC()->session->set('surcharge_percent', $surcharge_merchant);
        $label_text = $bmspay_Blackstone_Payment->getLabelSurcharge();
        echo '<tr class="order-total">
          <th>' . __($label_text . ' (' . number_format($surcharge_merchant, 2) . '%)', 'your-text-domain') . '</th>
          <td>' . wc_price($surcharge) . '</td>
        </tr>';
      }
      if ($card_difference_enabled && $should_apply_fees) {
        $card_difference =  number_format(($cart_total * $card_difference_percent / 100), 2);
        WC()->session->set('card_difference_amount', $card_difference);
        WC()->session->set('card_difference_percent', $card_difference_percent);
        $label_text = $bmspay_Blackstone_Payment->getLabelCardDifference();;
        echo '<tr class="order-total">
          <th>' . __($label_text . ' (' . number_format($card_difference_percent, 2) . '%)', 'your-text-domain') . '</th>
          <td>' . wc_price($card_difference) . '</td>
        </tr>';
      }
    }
  }
});
add_action('template_redirect', function () {
  if (is_wc_endpoint_url('order-pay') && isset($_GET['key'])) {
    $order_id = wc_get_order_id_by_order_key(sanitize_text_field($_GET['key']));
    $order = wc_get_order($order_id);

    if ($order) {
      $subtotal = $order->get_subtotal() + $order->get_shipping_total() - $order->get_discount_total();
      WC()->session->set('blackstone_cart_subtotal', $subtotal);
      error_log('Subtotal guardado en sesión: ' . $subtotal);
    }
  }
});
add_filter('woocommerce_calculated_total', function ($total) {
  $surcharge = WC()->session->get('surcharge_amount');
  $card_difference = WC()->session->get('card_difference_amount');
  if (isset($_POST['payment_method'])) {
    $payment_method = sanitize_text_field($_POST['payment_method']);
    if ($payment_method === 'bmspay_blackstone_payment') {
      if ($surcharge) {
        $total += $surcharge;
      }
      if ($card_difference) {
        $total += $card_difference;
      }
    }
  }
  return $total;
});
function getStatePlugin()
{
  $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();
  $payment_gateways = WC()->payment_gateways->get_available_payment_gateways();
  $gateway_id = 'bmspay_blackstone_payment';
  $should_apply_fees = ($bmspay_Blackstone_Payment->isPluginActive() == "yes")
    && isset($payment_gateways[$gateway_id])
    && ($payment_gateways[$gateway_id]->enabled === 'yes');
  return $should_apply_fees;
}
add_filter('woocommerce_get_order_item_totals', function ($totals, $order, $tax_display) {
  if (WC()->session) {
    $surcharge = WC()->session->get('surcharge_amount');
    $card_difference = WC()->session->get('card_difference_amount');
    $surcharge_percent = WC()->session->get('surcharge_percent');
    $card_difference_percent = WC()->session->get('card_difference_percent');

    if (($surcharge || $card_difference) && getStatePlugin()) {
      $new_totals = [];
      $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();

      foreach ($totals as $key => $total) {
        if ($key === 'order_total') {
          if ($surcharge) {
            $label_surcharge = $bmspay_Blackstone_Payment->getLabelSurcharge();
            $new_totals['surcharge'] = [
              'label' => __($label_surcharge . ' (' . number_format($surcharge_percent, 2) . '%)', 'your-text-domain'),
              'value' => wc_price($surcharge),
            ];
          }
          if ($card_difference) {
            $label_card_difference = $bmspay_Blackstone_Payment->getLabelCardDifference();
            $new_totals['card_difference'] = [
              'label' => __($label_card_difference . ' (' . number_format($card_difference_percent, 2) . '%)', 'your-text-domain'),
              'value' => wc_price($card_difference),
            ];
          }
        }
        $new_totals[$key] = $total;
      }

      return $new_totals;
    }
  }

  return $totals;
}, 10, 3);

add_action('woocommerce_checkout_update_order_meta', function ($order_id) {
  if (WC()->session && getStatePlugin()) {
    $surcharge = WC()->session->get('surcharge_amount');
    $card_difference = WC()->session->get('card_difference_amount');
    $surcharge_percent = WC()->session->get('surcharge_percent');
    $card_difference_percent = WC()->session->get('card_difference_percent');

    if ($surcharge) {
      update_post_meta($order_id, '_surcharge_amount', $surcharge);
      update_post_meta($order_id, '_surcharge_percent', $surcharge_percent);
    }
    if ($card_difference) {
      update_post_meta($order_id, '_card_difference_amount', $card_difference);
      update_post_meta($order_id, '_card_difference_percent', $card_difference_percent);
    }
  }
});

function recalculate_order_total_with_fees($order_id)
{
  $order = wc_get_order($order_id);

  // Obtener porcentajes guardados
  $surcharge_percent = floatval(get_post_meta($order_id, '_surcharge_percent', true));
  $card_difference_percent = floatval(get_post_meta($order_id, '_card_difference_percent', true));

  // Calcular subtotal base (productos + envío - descuentos)
  $subtotal = $order->get_subtotal() + $order->get_shipping_total() - $order->get_discount_total();

  // Calcular cargos
  $surcharge_amount = ($surcharge_percent > 0) ? ($subtotal * $surcharge_percent / 100) : 0;
  $card_difference_amount = ($card_difference_percent > 0) ? ($subtotal * $card_difference_percent / 100) : 0;

  // Calcular nuevo total
  $new_total = $subtotal + $surcharge_amount + $card_difference_amount;

  // Actualizar el total directamente
  $order->set_total($new_total);

  // Guardar los montos actualizados en metadatos
  update_post_meta($order_id, '_surcharge_amount', $surcharge_amount);
  update_post_meta($order_id, '_card_difference_amount', $card_difference_amount);

  $order->save();
}
add_action('woocommerce_order_status_processing_to_pending', 'handle_order_status_change_to_pending', 10, 1);

function handle_order_status_change_to_pending($order_id)
{
  // Verificar que es nuestro método de pago
  $order = wc_get_order($order_id);
  if ($order->get_payment_method() === 'bmspay_blackstone_payment') {
    recalculate_order_total_with_fees($order_id);
  }
}
add_action('woocommerce_order_after_calculate_totals', 'custom_adjust_order_totals_with_meta', 10, 2);

function custom_adjust_order_totals_with_meta($and_taxes, $order)
{
  // Solo aplicarlo si es nuestro método de pago
  // Primero verifica si NO es un pedido válido o SI es un reembolso
  if (!($order instanceof WC_Order) || $order instanceof WC_Order_Refund) {
    return;
  }
  // Luego verifica el método de pago (sabemos que $order es WC_Order)
  if ($order->get_payment_method() !== 'bmspay_blackstone_payment') {
    return;
  }

  // Obtener porcentajes guardados
  $order_id = $order->get_id();
  $surcharge_percent = floatval(get_post_meta($order_id, '_surcharge_percent', true));
  $card_difference_percent = floatval(get_post_meta($order_id, '_card_difference_percent', true));

  // Calcular subtotal base (productos + envío - descuentos)
  $subtotal = $order->get_subtotal() + $order->get_shipping_total() - $order->get_discount_total();

  // Calcular cargos
  $surcharge_amount = ($surcharge_percent > 0) ? ($subtotal * $surcharge_percent / 100) : 0;
  $card_difference_amount = ($card_difference_percent > 0) ? ($subtotal * $card_difference_percent / 100) : 0;

  // Calcular nuevo total
  $new_total = $subtotal + $surcharge_amount + $card_difference_amount;

  // Actualizar el total del pedido
  $order->set_total($new_total);

  // Guardar montos en metadatos
  update_post_meta($order_id, '_surcharge_amount', $surcharge_amount);
  update_post_meta($order_id, '_card_difference_amount', $card_difference_amount);
}


add_action('woocommerce_admin_order_totals_after_tax', function ($order_id) {
  $order = wc_get_order($order_id);
  $payment_method = $order->get_payment_method();
  $surcharge = get_post_meta($order_id, '_surcharge_amount', true);
  $surcharge_percent = floatval(get_post_meta($order_id, '_surcharge_percent', true)) ?? 0;

  $card_difference = get_post_meta($order_id, '_card_difference_amount', true);
  $card_difference_percent = floatval(get_post_meta($order_id, '_card_difference_percent', true)) ?? 0;

  if (($surcharge || $card_difference) && getStatePlugin() && $payment_method === 'bmspay_blackstone_payment') {
    $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();
    if ($surcharge && floatval($surcharge) > 0) {
      $label_surcharge = $bmspay_Blackstone_Payment->getLabelSurcharge(); 
    ?>
      <tr>
        <td class="label"><?php _e($surcharge_percent > 0 ? ($label_surcharge . ' (' . number_format($surcharge_percent ?? 0, 2) . '%)') : $label_surcharge, 'your-text-domain'); ?>:</td>
        <td width="1%"></td>
        <td class="total"><?php echo wc_price($surcharge); ?></td>
      </tr>
    <?php
    }
    if ($card_difference  && floatval($card_difference) > 0) { 
      $label_card_difference = $bmspay_Blackstone_Payment->getLabelCardDifference();
      ?>
      <tr>
        <td class="label"><?php _e($card_difference_percent > 0 ? ($label_card_difference . ' (' . number_format($card_difference_percent, 2) . '%)') : $label_card_difference, 'your-text-domain'); ?>:</td>
        <td width="1%"></td>
        <td class="total"><?php echo wc_price($card_difference); ?></td>
      </tr>
      <?php }
  }
});
add_filter('woocommerce_account_menu_items', 'add_payment_methods_to_my_account');

function add_payment_methods_to_my_account($items)
{
  if (isset($items['payment-methods'])) {
    unset($items['payment-methods']);
  }
  $label_text = (get_locale() === 'es_ES') ? 'Métodos de pago' : 'Payment methods';
  $logout = $items['customer-logout'];
  unset($items['customer-logout']);
  $items['payment-methods'] = __($label_text, 'woocommerce');
  $items['customer-logout'] = $logout;

  return $items;
}

add_action('woocommerce_review_order_before_submit', 'add_save_card_option');
add_action('woocommerce_pay_order_before_submit', 'add_save_card_option');

function add_save_card_option()
{
  // Verificar si es página de pago de pedido
  global $wp;
  $is_pay_for_order = isset($wp->query_vars['order-pay']);

  // Obtener el método de pago según el contexto
  $payment_method = '';

  if ($is_pay_for_order) {
    // Para página de pago de pedido
    if (isset($_POST['payment_method'])) {
      $payment_method = sanitize_text_field($_POST['payment_method']);
    } else {
      $order_id = absint($wp->query_vars['order-pay']);
      $order = wc_get_order($order_id);
      $payment_method = $order->get_payment_method();
    }
  } else {
    // Para checkout normal
    $payment_method = isset($_POST['payment_method']) ? sanitize_text_field($_POST['payment_method']) : '';
  }

  // Mostrar opción solo si el método de pago es el nuestro y el usuario está logueado
  if ($payment_method === 'bmspay_blackstone_payment' && is_user_logged_in()) {
    $label_text = (get_locale() === 'es_ES') ? 'Guardar tarjeta para futuras compras' : 'Save card for future purchases';
    echo '<p class="form-row woocommerce-SavedPaymentMethods-saveNew">';
    woocommerce_form_field('save_card', [
      'type'  => 'checkbox',
      'class' => ['form-row-wide'],
      'label' => __($label_text, 'bmspay-blackstone-payment'),
    ]);
    echo '</p>';
  }
}

function enqueue_threeds_script()
{
  if (is_checkout() || is_order_pay_page()) {
    wp_enqueue_script(
      'threeds-script',
      'https://cdn.3dsintegrator.com/threeds.2.2.20231219.min.js',
      array(),
      '2.2.20231219',
      true
    );
  }
}
add_action('wp_enqueue_scripts', 'enqueue_threeds_script');

add_action('wp_enqueue_scripts', 'change_sweetalert2');
add_action('admin_enqueue_scripts', 'change_sweetalert2');
function change_sweetalert2()
{
  wp_enqueue_script(
    'sweetalert2',
    'https://cdn.jsdelivr.net/npm/sweetalert2@11',
    array(),
    '11.0.0',
    true
  );
}

add_action('wp_footer', function () {
  if (is_checkout() || is_order_pay_page()) {
    $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();
    $surcharge_data = $bmspay_Blackstone_Payment->get_cached_surcharge_data();
    $threeds_enabled = $surcharge_data['response_ThreeDSecureEnabled'];
    // $threeds_enabled = WC()->session->get('threed_secure_enabled');

    if ($threeds_enabled && $bmspay_Blackstone_Payment->isPluginActive() == "yes") {
      $threed_secure_data = $bmspay_Blackstone_Payment->get_merchant_tokenthreeds();
      WC()->session->set('threed_secure_apikey', $threed_secure_data['response_ApiKey']);
      WC()->session->set('threed_secure_token', $threed_secure_data['response_Token']);
      $apiKey = $threed_secure_data['response_ApiKey'];
      $token = $threed_secure_data['response_Token'];

      if (empty($apiKey) || empty($token)) {
        $label_text = (get_locale() === 'es_ES') ? 'Su comercio tiene 3D Secure habilitado, pero no tiene una configuración válida. Contacte a su proveedor de pagos.' : 'Your merchant has 3D Secure enabled, but does not have a valid configuration. Contact your payment provider.';
        wc_add_notice(__($label_text, 'bmspay-blackstone-payment'), 'error');
        return;
      }

      if (!empty($apiKey) && !empty($token)) {
        $total = getTotalAmount();
        error_log('3DS Secure enabled with API Key: ' . $apiKey . ' and Token: ' . $token);
        $environment = $bmspay_Blackstone_Payment->getEnvironment3DS();
        $endpoint = $environment == 'yes'
          ? 'https://api-sandbox.3dsintegrator.com/v2.2'
          : 'https://api.3dsintegrator.com/v2.2';
      ?>
        <script type="text/javascript">
          jQuery(function($) {
            var canSubmitForm = false;

            // Determinar si es página de pago de pedido
            var isPayForOrder = window.location.href.indexOf('order-pay') !== -1;

            // Seleccionar el formulario correcto
            var $form = isPayForOrder ? $('#order_review') : $('form.checkout');

            function getSubmitButton() {
              if (isPayForOrder) {
                return $('#place_order');
              }

              var $btn = $('#place_order');
              if ($btn.length === 0) {
                $btn = $('button[name="woocommerce_checkout_place_order"]');
              }
              if ($btn.length === 0) {
                $btn = $('form.checkout').find('button[type="submit"]');
              }
              return $btn;
            }

            $form.on('submit', function(e) {
              if ($('input[name="payment_method"]:checked').val() === 'bmspay_blackstone_payment') {
                if (!canSubmitForm) {
                  e.preventDefault();
                  e.stopImmediatePropagation();
                  process3DSPayment();
                  return false;
                }
                canSubmitForm = false;
                return true;
              }
            });

            function showError(message) {
              var $submitBtn = getSubmitButton();
              if ($submitBtn.length) {
                $submitBtn.prop('disabled', false);
              }

              $('.woocommerce-ajax-loader').hide();

              Swal.fire({
                title: '<?php echo esc_html__('Payment Error', 'your-text-domain'); ?>',
                text: message,
                icon: 'error',
                confirmButtonText: '<?php echo esc_html__('Close', 'your-text-domain'); ?>',
                confirmButtonColor: '#d63638'
              });
            }

            function process3DSPayment() {
              var $submitBtn = getSubmitButton();

              if (!<?php echo json_encode(!empty($apiKey) && !empty($token)); ?>) {
                showError('Your merchant has 3D Secure enabled, but does not have a valid configuration. Contact your payment provider.');
                return false;
              }

              if ($submitBtn.length) {
                $submitBtn.prop('disabled', true);
              }
              $('.woocommerce-ajax-loader').show();

              const cardNumber = $('#bmspay_blackstone_payment-card-number').val().replace(/\s+/g, '');
              const expiry = $('#bmspay_blackstone_payment-card-expiry').val().replace(/\s+/g, '');
              const month = expiry.substring(0, 2);
              const year = expiry.substring(3, 5);
              const cvv = $('#bmspay_blackstone_payment-card-cvc').val();

              if (!cardNumber || cardNumber.length < 15) {
                showError('Por favor ingrese un número de tarjeta válido');
                return false;
              }

              if (!expiry || expiry.length !== 5 || !expiry.includes('/')) {
                showError('Por favor ingrese una fecha de vencimiento válida (MM/YY)');
                return false;
              }

              if (!cvv || cvv.length < 3) {
                showError('Por favor ingrese un código CVV válido');
                return false;
              }

              const $form = $('<form id="billing-form" style="display:none;"></form>').appendTo('body');
              $form.append('<input type="text" id="billing-card-amount" name="billing-card-amount" value="<?php echo esc_attr($total); ?>" data-threeds="amount" />');
              $form.append('<input type="text" id="billing-card-pan" name="billing-card-pan" value="' + cardNumber + '" data-threeds="pan" />');
              $form.append('<input type="text" id="billing-card-month" name="billing-card-month" value="' + month + '" data-threeds="month"/>');
              $form.append('<input type="text" id="billing-card-year" name="billing-card-year" value="' + year + '" data-threeds="year"/>');
              $form.append('<input type="text" id="billing-card-cvv" name="billing-card-cvv" value="' + cvv + '" data-threeds="cvv"/>');

              function initialize3DS() {
                if (typeof ThreeDS === 'undefined') {
                  showError('3DS Secure library is not loaded. Please try again or contact support.');
                  return false;
                }

                window.tds = new ThreeDS(
                  'billing-form',
                  '<?php echo esc_js($apiKey); ?>',
                  '<?php echo esc_js($token); ?>', {
                    endpoint: '<?php echo esc_js($endpoint); ?>',
                    autoSubmit: false,
                    showChallenge: true,
                    popup: false,
                    forcedTimeOut: '10',
                    clientTransactionId: 'transaction-' + Date.now(),
                    resolve: response => {},
                    reject: error => {},
                    verbose: true
                  }
                );
                return true;
              }

              if (typeof window.tds === 'undefined') {
                if (!initialize3DS()) {
                  $form.remove();
                  return false;
                }
              }

              // Ejecutar verificación 3DS
              window.tds.verify(
                function(response) {
                  console.log('✅ 3DS verificado correctamente', response);

                  const threeDsTransactionId = window.tds.threeDsTransactionId;

                  if (threeDsTransactionId) {
                    response.threeDsTransactionId = threeDsTransactionId;
                  }

                  $form.remove();
                  canSubmitForm = true;

                  var $targetForm = isPayForOrder ? $('#order_review') : $('form.checkout');

                  if (!$targetForm.find('input[name=threeds_response]').length) {
                    $('<input>').attr({
                      type: 'hidden',
                      name: 'threeds_response',
                      value: JSON.stringify(response)
                    }).appendTo($targetForm);
                  } else {
                    $targetForm.find('input[name=threeds_response]').val(JSON.stringify(response));
                  }

                  $targetForm.submit();
                },
                function(error) {
                  $form.remove();
                  let errorObj = error;
                  if (typeof error === 'string') {
                    try {
                      errorObj = JSON.parse(error);
                    } catch (e) {
                      console.warn('El error no es un JSON válido', error);
                    }
                  }
                  let errorMessage = errorObj.error || errorObj.message || 'An error occurred during payment verification. Please try again.';
                  if (errorMessage !== 'No result found for transaction as yet. Please subscribe again') {
                    showError(errorMessage);
                  }
                  return false;
                }, {
                  amount: <?php echo json_encode((float)$total); ?>,
                  currency: '840'
                }
              );

              return true;
            }
          });
        </script>
<?php
      } else {
        error_log('3DS Secure disabled with API Key or Token is empty');
      }
    } else {
      error_log('3DS Secure disabled because the plugin is not active or the session variable is not set.');
    }
  }
});
add_action('woocommerce_after_order_notes', 'add_threeds_hidden_field');

function add_threeds_hidden_field($checkout)
{
  echo '<input type="hidden" name="threeds_response" id="threeds_response" value="">';
}
function getTotalAmount()
{
  global $wp;

  if (isset($wp->query_vars['order-pay'])) {
    $order_id = absint($wp->query_vars['order-pay']);
    $order = wc_get_order($order_id);
    return $order->get_total();
  }
  $cart = WC()->cart;

  $subtotal = $cart->get_subtotal();
  $discount_total = $cart->get_discount_total();
  $shipping_total = $cart->get_shipping_total();

  $total_tax = $cart->get_total_tax();
  $discount_tax   = $cart->get_discount_tax();

  $total_fees = 0;
  foreach ($cart->get_fees() as $fee) {
    $total_fees += $fee->amount;
  }

  $calculated_total = ($subtotal - $discount_total)
    + $shipping_total
    + ($total_tax - $discount_tax)
    + $total_fees;

  $calculated_total = wc_format_decimal($calculated_total, 2);

  return $calculated_total;
}
add_action('wp_ajax_update_fees_based_on_payment_method', 'update_fees_based_on_payment_method');
add_action('wp_ajax_nopriv_update_fees_based_on_payment_method', 'update_fees_based_on_payment_method');

function update_fees_based_on_payment_method()
{
  if (!isset($_POST['payment_method'])) {
    wp_send_json_error('Método de pago no recibido');
  }
  $cart = WC()->cart;

  $cart->fees_api()->remove_all_fees();

  $cart->calculate_totals();

  ob_start();
  woocommerce_order_review();
  $order_review = ob_get_clean();

  wp_send_json([
    'success' => true,
    'fragments' => apply_filters('woocommerce_update_order_review_fragments', [
      '.woocommerce-checkout-review-order-table' => $order_review
    ])
  ]);
}

add_action('wp_enqueue_scripts', 'enqueue_payment_method_script');
function enqueue_payment_method_script()
{
  if (!is_checkout()) {
    return;
  }

  wp_enqueue_script('wc-checkout');

  $script = "
    jQuery(document).ready(function($) {
        function handlePaymentMethodChange() {
            var paymentMethod = $('input[name=\"payment_method\"]:checked').val();
            var reviewSection = $('.woocommerce-checkout-review-order-table').closest('.woocommerce-checkout-review-order');
            
            reviewSection.block({
                message: null,
                overlayCSS: {
                    background: '#fff',
                    opacity: 0.6
                }
            });

            $.ajax({
                type: 'POST',
                url: wc_checkout_params.ajax_url,
                data: {
                    action: 'update_fees_based_on_payment_method',
                    payment_method: paymentMethod,
                    security: wc_checkout_params.update_order_review_nonce
                },
                success: function(response) {
                    if (response.success) {
                        if (response.fragments) {
                            $.each(response.fragments, function(key, value) {
                                $(key).replaceWith(value);
                            });
                        }
                        
                        if (response.reload !== false) {
                            $(document.body).trigger('update_checkout');
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error en AJAX:', error);
                    reviewSection.prepend('<div class=\"woocommerce-error\">Error al actualizar los cargos. Por favor recarga la página.</div>');
                },
                complete: function() {
                    reviewSection.unblock();
                }
            });
        }
        
        handlePaymentMethodChange();
        
        $(document.body).on('payment_method_selected', handlePaymentMethodChange);
    });
    ";

  wp_add_inline_script('wc-checkout', $script);
}
function is_order_pay_page()
{
  global $wp;
  return isset($wp->query_vars['order-pay']);
}
