<?php
/**
 * Blackstone Credential Manager
 *
 * Handles credential retrieval and management for Blackstone API.
 *
 * @package Blackstone_Online_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bmspay_Credential_Manager class.
 *
 * 
 */
class Bmspay_Credential_Manager {

	/**
	 * Gateway instance.
	 *
	 * @var BMSPay_Blackstone_Payment
	 */
	private BMSPay_Blackstone_Payment $gateway;

	/**
	 * Test mode flag.
	 *
	 * @var bool
	 */
	private bool $is_test_mode = false;

	/**
	 * 3DS mode flag.
	 *
	 * @var bool
	 */
	private bool $is_3ds_mode = false;

	/**
	 * Constructor.
	 *
	 * 
	 * @param BMSPay_Blackstone_Payment $gateway Gateway instance.
	 */
	public function __construct( BMSPay_Blackstone_Payment $gateway ) {
		$this->gateway      = $gateway;
		$this->is_test_mode = $gateway->get_environment() === 'yes';
		$this->is_3ds_mode  = $gateway->get_environment_3ds() === 'yes';
	}

	/**
	 * Get API credentials for sale transactions.
	 *
	 * 
	 * @return array
	 */
	public function get_credentials(): array {
		$remote_ip = $this->get_remote_ip();

		$creds = array(
			'mid'      => $this->gateway->get_api_mid(),
			'UserName' => $this->gateway->get_api_username(),
			'Password' => $this->gateway->get_api_password(),
			'AppType'  => $this->gateway->get_app_type(),
			'AppKey'   => $this->gateway->get_app_key(),
			'cid'      => $this->gateway->get_api_cid(),
		);

		$creds['IpAddress'] = $remote_ip;
		$creds['Source']    = Bmspay_Constants::SOURCE;
		$creds['UserTest']  = $this->is_test_mode ? 'True' : 'False';

		return $creds;
	}

	/**
	 * Get API credentials for 3D Secure transactions.
	 *
	 * 
	 * @return array
	 */
	public function get_3ds_credentials(): array {
		$remote_ip = $this->get_remote_ip();

		$creds = array(
			'mid'      => $this->gateway->get_api_mid(),
			'UserName' => $this->gateway->get_api_username(),
			'Password' => $this->gateway->get_api_password(),
			'AppType'  => $this->gateway->get_app_type(),
			'AppKey'   => $this->gateway->get_app_key(),
			'cid'      => $this->gateway->get_api_cid(),
		);

		$creds['IpAddress'] = $remote_ip;
		$creds['Source']    = Bmspay_Constants::SOURCE;
		$creds['UserTest']  = $this->is_test_mode ? 'True' : 'False';

		return $creds;
	}

	/**
	 * Get remote IP address.
	 *
	 * 
	 * @return string
	 */
	public function get_remote_ip(): string {
		$remote_addr = isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '';

		if ( ! empty( $remote_addr ) && filter_var( $remote_addr, FILTER_VALIDATE_IP ) ) {
			return $remote_addr;
		}

		return '0.0.0.0';
	}

	/**
	 * Check if running in test mode.
	 *
	 * 
	 * @return bool
	 */
	public function is_test_mode(): bool {
		return $this->is_test_mode;
	}
}
