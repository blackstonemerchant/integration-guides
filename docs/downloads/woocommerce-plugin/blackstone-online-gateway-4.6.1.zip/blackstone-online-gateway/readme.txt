=== Blackstone Online Gateway ===
Contributors: carlosraul7
Donate link: https://blackstoneonline.com/
Tags: woocommerce, payment, gateway, blackstone, credit card
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 4.6.1
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Custom payment gateway integration for WooCommerce using Blackstone Merchant. Secure, fast and reliable payments for your online store.

== Description ==

**Blackstone Online Gateway** is a custom payment integration for WooCommerce that allows merchants to process credit card payments through the Blackstone Merchant platform. It provides a seamless checkout experience, secure communication with the API, and supports refund handling directly via WooCommerce.

### Main Features

* Full integration with WooCommerce checkout and order management.
* Secure API connection to Blackstone Merchant Services.
* Supports payment authorization, capture and refund.
* 3D Secure (3DS) authentication for fraud prevention.
* Saved payment tokens — customers can securely save and reuse credit cards.
* Surcharge and dual pricing (card difference) support with configurable labels.
* Full and partial refund processing via API with stock management.
* Test/sandbox mode for development and staging environments.
* Admin settings page for easy configuration of merchant credentials.
* Localization support with Spanish (es_ES) translation included.
* Compatible with the latest versions of WooCommerce and WordPress.

### How It Works

1. The customer selects Blackstone Merchant as the payment method at checkout.
2. They can enter a new credit card or choose a previously saved card.
3. If 3DS is enabled, the transaction is authenticated via 3D Secure.
4. The payment is processed securely through the Blackstone API.
5. The card can optionally be saved as a token for future purchases.

This plugin requires an active merchant account with [Blackstone Merchant](https://www.blackstonemerchant.com/).

== External Services ==

This plugin connects to external services to process payments and perform security verifications.

**BMS Pay API**
This service is used to process payments and refunds securely.
*   **Source**: `https://services.bmspay.com/`
*   **Data Sent**: Transaction details, card information (processed securely), and order amounts.
*   **Provider**: Blackstone Merchant Services.
*   **Terms & Privacy**: Please refer to [Blackstone Merchant](https://www.blackstonemerchant.com/) and [Documentation](https://documentation.bmspay.com/).

**3DS Integrator**
This service is used for 3D Secure (3DS) authentication to prevent fraud.
*   **Source**: `https://cdn.3dsintegrator.com/` (Script), `https://api.3dsintegrator.com/` (API).
*   **Data Sent**: Card identifiers and transaction context for risk analysis.
*   **Provider**: 3DS Integrator (via Blackstone).
*   **Terms & Privacy**: Usage is covered under your agreement with [Blackstone Merchant](https://www.blackstonemerchant.com/).

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install it directly from the WordPress Plugin Directory.
2. Activate the plugin through the *Plugins* menu in WordPress.
3. Go to **WooCommerce → Settings → Payments → Blackstone Merchant**.
4. Enable the gateway and enter your merchant credentials (Username, Password, MID, CID, AppKey, AppType).
5. Optionally enable 3D Secure and configure the 3DS API key and token.
6. Save changes and test the payment process using test mode.

== Frequently Asked Questions ==

= Do I need a Blackstone Merchant account? =
Yes. You must have an approved merchant account from [Blackstone Merchant](https://www.blackstonemerchant.com/) to process transactions.

= Does this plugin support refunds? =
Yes. Full and partial refunds can be processed directly from the WooCommerce order screen. The plugin sends refund requests securely to the Blackstone API and can optionally restock items.

= What is 3D Secure (3DS)? =
3D Secure is an additional authentication layer that helps prevent fraudulent transactions. When enabled, the cardholder may be asked to verify their identity during checkout. This plugin integrates with the 3DS Integrator service to handle this process.

= Can customers save their credit cards? =
Yes. Customers can choose to save their credit card as a payment token during checkout. Saved cards can be reused for future purchases without re-entering card details. No sensitive card data is stored on your server.

= Does it support test/sandbox mode? =
Yes. The plugin includes a test mode toggle in the settings page. This allows you to test transactions in a sandbox environment before going live. There is also a separate test mode toggle for 3DS authentication.

= Is it compatible with WooCommerce Subscriptions or Bookings? =
Currently, it supports standard one-time payments. Future versions may include support for recurring billing.

= Does it store credit card information? =
No. The plugin does **not** store or log any sensitive card data. All transactions are handled securely through the Blackstone Merchant gateway. Saved payment tokens are managed by WooCommerce's built-in token system.

= What is the surcharge/dual pricing feature? =
The plugin supports adding a surcharge or card difference amount to orders. This can be configured with custom labels in the admin settings and is displayed as a separate line item in the order.

== Screenshots ==

1. Payment gateway settings — General configuration screen under WooCommerce → Settings → Payments → Blackstone Merchant.
2. Payment gateway credentials — API credentials and 3DS configuration options.
3. Checkout page — The Blackstone Merchant payment option displayed to customers.

== Changelog ==

= 4.6.1 =
* Added automated ZIP packaging, artifact publishing, and GitHub release publication for the plugin.
* Added automated integration-guides updates for the latest ZIP alias and WooCommerce plugin versions table.

= 4.6.0 =
* Released a new minor version to re-align WordPress.org deployment history.
* Preserved the checkout script conflict fixes and token update safeguards from the previous release.

= 4.5.49 =
* Fixed JavaScript conflict on checkout page (undefined 'defaults' error) by restricting script loading.
* Improved script loading logic to prevent conflicts with other plugins.
* Fixed token update to only apply when it belongs to the same gateway.

= 4.5.43 =
* Added compatibility with WooCommerce 9.x.
* Improved refund API handling and error responses.
* Minor performance and security updates.
* Improved text translation.
* Added data to refund notes for better traceability.
* Standardized file and folder names.

= 4.5.0 =
* Initial public release.
* Added support for payment authorization and capture.
* Introduced refund integration via API.

== Upgrade Notice ==

= 4.6.1 =
* Adds automated release distribution and integration-guides publication for plugin updates.

== License ==

This plugin is licensed under the GPLv2 or later license.
You are free to modify and redistribute it under the same license.
See https://www.gnu.org/licenses/gpl-2.0.html for details.

== Credits ==

Developed and maintained by **Blackstone**
Website: [https://blackstoneonline.com/](https://blackstoneonline.com/)
Blackstone Merchant official site: [https://www.blackstonemerchant.com/](https://www.blackstonemerchant.com/)
