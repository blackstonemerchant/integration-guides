<?php
/**
 * Blackstone API Client
 *
 * Handles all HTTP communication with the Blackstone API.
 *
 * @package Blackstone_Online_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bmspay_Api_Client class.
 *
 * 
 */
class Bmspay_Api_Client {

	/**
	 * Base log source identifier.
	 *
	 * @var string
	 */
	const LOG_SOURCE = 'bmspay';

	/**
	 * Gateway instance.
	 *
	 * @var BMSPay_Blackstone_Payment
	 */
	private BMSPay_Blackstone_Payment $gateway;

	/**
	 * Credential manager instance.
	 *
	 * @var Bmspay_Credential_Manager
	 */
	private Bmspay_Credential_Manager $credential_manager;

	/**
	 * Debug mode flag.
	 *
	 * @var bool
	 */
	private bool $debug_mode;

	/**
	 * Log source suffix for current context.
	 *
	 * @var string
	 */
	private string $log_source_suffix = '';

	/**
	 * Constructor.
	 *
	 * 
	 * @param BMSPay_Blackstone_Payment $gateway Gateway instance.
	 */
	public function __construct( BMSPay_Blackstone_Payment $gateway ) {
		$this->gateway           = $gateway;
		$this->credential_manager = new Bmspay_Credential_Manager( $gateway );
		$this->debug_mode        = $gateway->is_debug_enabled();
	}

	/**
	 * Set log context for current request.
	 *
	 * Creates a unique log file per transaction/order.
	 *
	 * 
	 * @param int    $order_id Order ID.
	 * @param string $suffix Optional suffix like 'sale', 'refund', 'token'.
	 * @return void
	 */
	public function set_log_context( int $order_id, string $suffix = '' ): void {
		$this->log_source_suffix = (string) absint( $order_id );
		if ( ! empty( $suffix ) ) {
			$this->log_source_suffix .= '-' . sanitize_file_name( $suffix );
		}
	}

	/**
	 * Clear log context.
	 *
	 * 
	 * @return void
	 */
	public function clear_log_context(): void {
		$this->log_source_suffix = '';
	}

	/**
	 * Get current log source.
	 *
	 * 
	 * @return string
	 */
	private function get_log_source(): string {
		if ( ! empty( $this->log_source_suffix ) ) {
			return self::LOG_SOURCE . '-' . $this->log_source_suffix;
		}
		return self::LOG_SOURCE;
	}

	/**
	 * Get the base API URL.
	 *
	 * 
	 * @return string
	 */
	public function get_base_url() {
		$is_sandbox = $this->gateway->get_environment() === 'yes';
		return $is_sandbox
			? Bmspay_Constants::ENV_SANDBOX_URL
			: Bmspay_Constants::ENV_PRODUCTION_URL;
	}

	/**
	 * Build full URL for an endpoint.
	 *
	 * 
	 * @param string $endpoint API endpoint.
	 * @return string
	 */
	public function build_url( string $endpoint ): string {
		return $this->get_base_url() . ltrim( $endpoint, '/' );
	}

	/**
	 * Send POST request with form-encoded data.
	 *
	 * 
	 * @param string $endpoint API endpoint.
	 * @param array  $payload Request payload.
	 * @return array|WP_Error
	 */
	public function post_form( string $endpoint, array $payload = array() ) {
		$url = $this->build_url( $endpoint );

		$args = array(
			'method'  => 'POST',
			'body'    => http_build_query( $payload ),
			'timeout' => Bmspay_Constants::API_TIMEOUT,
			'headers' => array(
				'Content-Type' => Bmspay_Constants::API_CONTENT_TYPES['form_urlencoded'],
			),
		);

		$this->log_request( $endpoint, $payload );

		return $this->execute_with_retry( $url, $args, $endpoint );
	}

	/**
	 * Send POST request with JSON data.
	 *
	 * 
	 * @param string $endpoint API endpoint.
	 * @param array  $payload Request payload.
	 * @return array|WP_Error
	 */
	public function post_json( string $endpoint, array $payload = array() ) {
		$url = $this->build_url( $endpoint );

		$args = array(
			'method'  => 'POST',
			'body'    => wp_json_encode( $payload ),
			'timeout' => Bmspay_Constants::API_TIMEOUT,
			'headers' => array(
				'Content-Type' => Bmspay_Constants::API_CONTENT_TYPES['json'],
			),
		);

		$this->log_request( $endpoint, $payload );

		return $this->execute_with_retry( $url, $args, $endpoint );
	}

	/**
	 * Get merchant settings from API.
	 *
	 * 
	 * @return array|WP_Error
	 */
	public function get_merchant_settings(): array|WP_Error {
		$payload = $this->credential_manager->get_credentials();
		return $this->post_json(
			Bmspay_Constants::API_ENDPOINTS['BusinessSettings'],
			$payload
		);
	}

	/**
	 * Get 3D Secure token from API.
	 *
	 * 
	 * @return array|WP_Error
	 */
	public function get_threeds_token(): array|WP_Error {
		$payload = $this->credential_manager->get_3ds_credentials();
		return $this->post_json(
			Bmspay_Constants::API_ENDPOINTS['Auth/TokenThreeDS'],
			$payload
		);
	}

	/**
	 * Process a sale transaction.
	 *
	 * 
	 * @param array $payload Sale payload.
	 * @return array|WP_Error
	 */
	public function process_sale( array $payload ): array|WP_Error {
		return $this->post_json(
			Bmspay_Constants::API_ENDPOINTS['Sale'],
			$payload
		);
	}

	/**
	 * Process a token sale transaction.
	 *
	 * 
	 * @param array $payload Token sale payload.
	 * @return array|WP_Error
	 */
	public function process_sale_with_token( array $payload ): array|WP_Error {
		return $this->post_json(
			Bmspay_Constants::API_ENDPOINTS['SaleToken'],
			$payload
		);
	}

	/**
	 * Process a refund transaction.
	 *
	 * 
	 * @param array $payload Refund payload.
	 * @return array|WP_Error
	 */
	public function process_refund( array $payload ): array|WP_Error {
		return $this->post_json(
			Bmspay_Constants::API_ENDPOINTS['DoRefund'],
			$payload
		);
	}

	/**
	 * Get 3D Secure API endpoint.
	 *
	 * 
	 * @return string
	 */
	public function get_3ds_endpoint(): string {
		$is_sandbox = $this->gateway->get_environment_3ds() === 'yes';
		return $is_sandbox
			? Bmspay_Constants::THREE_DS_ENDPOINTS['sandbox']
			: Bmspay_Constants::THREE_DS_ENDPOINTS['production'];
	}

	/**
	 * Execute HTTP request with retry logic.
	 *
	 * Handles transient errors like 500 Internal Server Error with exponential backoff.
	 *
	 * 
	 * @param string $url     Request URL.
	 * @param array  $args    Request arguments.
	 * @param string $endpoint API endpoint for logging.
	 * @return array|WP_Error
	 */
	private function execute_with_retry( string $url, array $args, string $endpoint ): array|WP_Error {
		$max_retries = 3;
		$retry_delay = 1;

		for ( $attempt = 1; $attempt <= $max_retries; $attempt++ ) {
			$response = wp_remote_post( $url, $args );

			if ( ! is_wp_error( $response ) ) {
				$code = wp_remote_retrieve_response_code( $response );

				if ( $code < 500 ) {
					return $this->handle_response( $response, $endpoint );
				}

				if ( $attempt < $max_retries ) {
					$this->log( 'warning', sprintf(
						'Attempt %d/%d: HTTP %d for %s. Retrying in %ds...',
						$attempt,
						$max_retries,
						$code,
						$endpoint,
						$retry_delay
					) );
					sleep( $retry_delay );
					$retry_delay *= 2;
					continue;
				}
			} else {
				if ( $attempt < $max_retries ) {
					$this->log( 'warning', sprintf(
						'Attempt %d/%d: Network error %s for %s. Retrying...',
						$attempt,
						$max_retries,
						$response->get_error_message(),
						$endpoint
					) );
					sleep( $retry_delay );
					$retry_delay *= 2;
					continue;
				}
			}

			break;
		}

		return $this->handle_response( $response, $endpoint );
	}

	/**
	 * Handle API response.
	 *
	 * 
	 * @param array|WP_Error $response HTTP response.
	 * @param string         $endpoint API endpoint.
	 * @return array|WP_Error
	 */
	private function handle_response( $response, string $endpoint ): array|WP_Error {
		if ( is_wp_error( $response ) ) {
			$this->log_error( 'Network Error', array(
				'endpoint'    => $endpoint,
				'error'       => $response->get_error_message(),
				'error_code'  => $response->get_error_code(),
			) );
			return $response;
		}

		$body = wp_remote_retrieve_body( $response );
		$code = wp_remote_retrieve_response_code( $response );

		$this->log_response( $endpoint, $code, $body );

		if ( empty( $body ) ) {
			$this->log_error( 'Empty Response', array(
				'endpoint'  => $endpoint,
				'http_code' => $code,
			) );
			return new WP_Error(
				'blackstone_empty_response',
				__( 'Blackstone returned an empty response.', 'blackstone-online-gateway' )
			);
		}

		if ( $code >= 400 ) {
			$error_msg = $this->get_http_error_message( $code, $body );
			$this->log_error( 'HTTP Error', array(
				'endpoint'   => $endpoint,
				'http_code'  => $code,
				'error'      => $error_msg,
			) );
			return new WP_Error(
				'blackstone_http_error',
				$error_msg
			);
		}

		$decoded = json_decode( $body, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			$this->log_error( 'Invalid JSON Response', array(
				'endpoint'   => $endpoint,
				'http_code'  => $code,
				'json_error' => json_last_error_msg(),
			) );
			return new WP_Error(
				'blackstone_invalid_json',
				sprintf(
					__( 'Invalid JSON response from Blackstone. Error: %s', 'blackstone-online-gateway' ),
					json_last_error_msg()
				)
			);
		}

		return $decoded;
	}

	/**
	 * Get human-readable HTTP error message.
	 *
	 * 
	 * @param int    $code HTTP status code.
	 * @param string $body Response body.
	 * @return string
	 */
	private function get_http_error_message( int $code, string $body ): string {
		$error_messages = array(
			400 => __( 'Bad request. Please check your configuration.', 'blackstone-online-gateway' ),
			401 => __( 'Authentication failed. Please check your API credentials.', 'blackstone-online-gateway' ),
			403 => __( 'Access forbidden. Please check your API permissions.', 'blackstone-online-gateway' ),
			404 => __( 'API endpoint not found. The service may be temporarily unavailable.', 'blackstone-online-gateway' ),
			500 => __( 'Internal server error on payment provider. Please try again later.', 'blackstone-online-gateway' ),
			502 => __( 'Bad gateway. The payment service is temporarily unavailable.', 'blackstone-online-gateway' ),
			503 => __( 'Service unavailable. The payment gateway is under maintenance.', 'blackstone-online-gateway' ),
		);

		if ( isset( $error_messages[ $code ] ) ) {
			return $error_messages[ $code ];
		}

		return sprintf(
			__( 'Payment gateway returned HTTP error %d. Please try again or contact support.', 'blackstone-online-gateway' ),
			$code
		);
	}

	/**
	 * Log API request.
	 *
	 * 
	 * @param string $endpoint API endpoint.
	 * @param array  $payload Request payload.
	 * @return void
	 */
	private function log_request( string $endpoint, array $payload ): void {
		if ( ! $this->should_log() ) {
			return;
		}

		$masked_payload = $this->mask_sensitive_data( $payload );

		$log_message  = "Blackstone API Request\n";
		$log_message .= "==========================\n";
		$log_message .= "Endpoint: " . $endpoint . "\n";
		$log_message .= "URL: " . $this->build_url( $endpoint ) . "\n";
		$log_message .= "==========================\n";
		$log_message .= "Payload:\n" . $this->format_for_log( $masked_payload );

		$this->log( 'info', $log_message );
	}

	/**
	 * Log API response.
	 *
	 * 
	 * @param string $endpoint API endpoint.
	 * @param int    $code HTTP response code.
	 * @param string $body Response body.
	 * @return void
	 */
	private function log_response( string $endpoint, int $code, string $body ): void {
		if ( ! $this->should_log() ) {
			return;
		}

		$decoded          = json_decode( $body, true );
		$response_code    = isset( $decoded['ResponseCode'] ) ? $decoded['ResponseCode'] : 'N/A';
		$response_msg    = isset( $decoded['ResponseMessage'] )
			? $decoded['ResponseMessage']
			: ( isset( $decoded['Msg'] ) ? json_encode( $decoded['Msg'] ) : 'N/A' );

		$level = ( $code >= 200 && $code < 300 ) ? 'info' : 'warning';

		$log_message  = "Blackstone API Response\n";
		$log_message .= "==========================\n";
		$log_message .= "Endpoint: " . $endpoint . "\n";
		$log_message .= "HTTP Code: " . $code . "\n";
		$log_message .= "Response Code: " . $response_code . "\n";
		$log_message .= "Response Message: " . $response_msg . "\n";
		$log_message .= "==========================\n";
		$log_message .= "Full Response:\n" . $this->format_for_log( $decoded ?: $body );

		$this->log( $level, $log_message );
	}

	/**
	 * Format data for logging.
	 *
	 * 
	 * @param mixed $data Data to format.
	 * @return string
	 */
	private function format_for_log( $data ): string {
		if ( is_array( $data ) ) {
			$sanitized = array();
			foreach ( $data as $key => $value ) {
				$sanitized[ sanitize_text_field( (string) $key ) ] = $this->sanitize_for_log( $value );
			}
			return wp_json_encode( $sanitized, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		}

		if ( is_object( $data ) ) {
			$sanitized = array();
			foreach ( get_object_vars( $data ) as $key => $value ) {
				$sanitized[ sanitize_text_field( (string) $key ) ] = $this->sanitize_for_log( $value );
			}
			return wp_json_encode( $sanitized, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		}

		return sanitize_text_field( (string) $data );
	}

	/**
	 * Sanitize individual value for logging.
	 *
	 * 
	 * @param mixed $value Value to sanitize.
	 * @return mixed
	 */
	private function sanitize_for_log( $value ) {
		if ( is_array( $value ) || is_object( $value ) ) {
			return '[complex]';
		}
		if ( is_string( $value ) ) {
			$length = strlen( $value );
			if ( $length > 100 ) {
				return substr( sanitize_text_field( $value ), 0, 50 ) . '...[truncated ' . $length . ' chars]';
			}
			return sanitize_text_field( $value );
		}
		return $value;
	}

	/**
	 * Mask sensitive data in payload for logging.
	 *
	 * 
	 * @param array $payload Request payload.
	 * @return array
	 */
	private function mask_sensitive_data( $payload ) {
		foreach ( Bmspay_Constants::SENSITIVE_FIELDS as $field ) {
			if ( isset( $payload[ $field ] ) && ! empty( $payload[ $field ] ) ) {
				$value                  = (string) $payload[ $field ];
				$payload[ $field ]      = strlen( $value ) > 8
					? '****' . substr( $value, -4 )
					: '****';
			}
		}

		if ( isset( $payload['CardNumber'] ) && strlen( $payload['CardNumber'] ) >= 4 ) {
			$payload['CardNumber'] = '****' . substr( $payload['CardNumber'], -4 );
		}

		if ( isset( $payload['CVN'] ) ) {
			$payload['CVN'] = '****';
		}

		return $payload;
	}

	/**
	 * Check if logging should be enabled.
	 *
	 * 
	 * @return bool
	 */
	private function should_log(): bool {
		return $this->debug_mode || ( defined( 'WP_DEBUG' ) && WP_DEBUG );
	}

	/**
	 * Write to log.
	 *
	 * 
	 * @param string $level   Log level.
	 * @param string $message Log message.
	 * @return void
	 */
	private function log( string $level, string $message ): void {
		if ( ! function_exists( 'wc_get_logger' ) ) {
			return;
		}

		$context = array( 'source' => $this->get_log_source() );
		$logger  = wc_get_logger();
		$logger->log( $level, $message, $context );
	}

	/**
	 * Log error with context.
	 *
	 * 
	 * @param string $message Error message.
	 * @param array  $context Error context.
	 * @return void
	 */
	private function log_error( string $message, array $context = array() ): void {
		$context['source'] = self::LOG_SOURCE;
		$context['type']  = 'error';

		$log_message  = 'Blackstone Error: ' . $message . "\n";
		$log_message .= 'Endpoint: ' . ( isset( $context['endpoint'] ) ? $context['endpoint'] : 'N/A' ) . "\n";
		$log_message .= 'Error: ' . ( isset( $context['error'] ) ? $context['error'] : 'N/A' ) . "\n";

		if ( isset( $context['error_code'] ) ) {
			$log_message .= 'Error Code: ' . $context['error_code'] . "\n";
		}

		if ( isset( $context['http_code'] ) ) {
			$log_message .= 'HTTP Code: ' . $context['http_code'] . "\n";
		}

		if ( function_exists( 'wc_get_logger' ) ) {
			$logger = wc_get_logger();
			$logger->log( 'error', $log_message, $context );
		}
	}

	/**
	 * Check if debug is enabled.
	 *
	 * 
	 * @return bool
	 */
	public function is_debug_enabled(): bool {
		return $this->debug_mode;
	}
}
