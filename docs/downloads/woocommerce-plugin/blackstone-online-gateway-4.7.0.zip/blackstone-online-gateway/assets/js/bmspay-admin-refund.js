(function($) {
    // Alert helper - uses SweetAlert2 with native alert fallback
    var BmspayAlert = {
        show: function(message, type) {
            type = type || 'info';
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: type === 'error' ? 'Error' : (type === 'success' ? 'Éxito' : 'Información'),
                    text: message,
                    icon: type,
                    confirmButtonText: 'OK'
                });
            } else {
                alert((type === 'error' ? 'Error: ' : '') + message);
            }
        },
        showError: function(message) {
            this.show(message, 'error');
        },
        showSuccess: function(message) {
            this.show(message, 'success');
        },
        close: function() {
            if (typeof Swal !== 'undefined' && Swal.getPopup()) {
                Swal.close();
            }
        },
        showLoading: function(title, html) {
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: title || 'Cargando',
                    html: html || 'Por favor espere...',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
            }
        }
    };

    const parseMoney = (value) => parseFloat(value) || 0;

    const getTaxKey = ($input, index) => {
        const dataTaxId = $input.data('tax_id');

        if (typeof dataTaxId !== 'undefined' && dataTaxId !== '') {
            return String(dataTaxId);
        }

        const inputName = $input.attr('name') || '';
        const matches = inputName.match(/\[(\d+)\](?!.*\[\d+\])/);

        if (matches && matches[1]) {
            return matches[1];
        }

        return String(index);
    };

    const collectRefundLineItems = () => {
        const lineItems = {};

        $('.woocommerce_order_items')
            .find('tr[data-order_item_id]')
            .each(function() {
                const $row = $(this);
                const itemId = parseInt($row.data('order_item_id'), 10);

                if (!itemId) {
                    return;
                }

                const qtyInput = $row.find('input.refund_order_item_qty').first();
                const totalInput = $row.find('input.refund_line_total').first();
                const taxInputs = $row.find('input.refund_line_tax');

                const itemData = {
                    id: itemId
                };

                const qty = qtyInput.length ? parseFloat(qtyInput.val()) || 0 : 0;
                const total = totalInput.length ? parseMoney(totalInput.val()) : 0;
                const tax = {};
                let hasTaxAmount = false;

                taxInputs.each(function(index) {
                    const $taxInput = $(this);
                    const taxAmount = parseMoney($taxInput.val());

                    if (taxAmount <= 0) {
                        return;
                    }

                    tax[getTaxKey($taxInput, index)] = taxAmount;
                    hasTaxAmount = true;
                });

                if (qty > 0) {
                    itemData.qty = qty;
                }

                if (total > 0) {
                    itemData.total = total;
                }

                if (hasTaxAmount) {
                    itemData.tax = tax;
                }

                if (qty > 0 || total > 0 || hasTaxAmount) {
                    lineItems[itemId] = itemData;
                }
            });

        return lineItems;
    };

    const showConfirmDialog = (refundAmount) => {
        const confirmMessage = '¿Desea procesar este reembolso por $' + refundAmount.toFixed(2) + '?';

        if (typeof Swal !== 'undefined') {
            Swal.fire({
                title: '¿Está seguro?',
                text: confirmMessage,
                icon: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Cancelar',
                confirmButtonText: 'Sí, reembolsar',
                showLoaderOnConfirm: true,
                preConfirm: async () => {
                    try {
                        const orderId = parseInt(bmspay_refund_params.order_id, 10);
                        const reason = $('#refund_reason').val() || '';
                        const lineItems = collectRefundLineItems();

                        const response = await $.ajax({
                            url: bmspay_refund_params.ajaxurl,
                            method: 'POST',
                            dataType: 'json',
                            data: {
                                action: bmspay_refund_params.action,
                                security: bmspay_refund_params.security,
                                order_id: orderId,
                                refund_amount: refundAmount,
                                refund_reason: reason,
                                restock_items: $('#restock_refunded_items').is(':checked') ? 1 : 0,
                                line_items: JSON.stringify(lineItems)
                            }
                        });

                        if (response && response.success) {
                            return response.data.message;
                        }

                        throw new Error(
                            response && response.data && response.data.message
                                ? response.data.message
                                : 'Ocurrió un error al procesar el reembolso.'
                        );
                    } catch (error) {
                        const responseJSON = error && error.responseJSON ? error.responseJSON : null;
                        const message =
                            (responseJSON && responseJSON.data && responseJSON.data.message) ||
                            (error && error.message) ||
                            'No fue posible procesar el reembolso.';

                        Swal.showValidationMessage(message);
                        return false;
                    }
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire('¡Completado!', result.value, 'success').then(() => {
                        location.reload();
                    });
                }
            }).catch((error) => {
                Swal.fire('Error', error, 'error');
            });
        } else {
            // Fallback to native confirm
            if (confirm(confirmMessage)) {
                const orderId = parseInt(bmspay_refund_params.order_id, 10);
                const reason = $('#refund_reason').val() || '';
                const lineItems = collectRefundLineItems();

                $.ajax({
                    url: bmspay_refund_params.ajaxurl,
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        action: bmspay_refund_params.action,
                        security: bmspay_refund_params.security,
                        order_id: orderId,
                        refund_amount: refundAmount,
                        refund_reason: reason,
                        restock_items: $('#restock_refunded_items').is(':checked') ? 1 : 0,
                        line_items: JSON.stringify(lineItems)
                    },
                    success: function(response) {
                        if (response && response.success) {
                            alert('Reembolso procesado correctamente');
                            location.reload();
                        } else {
                            var msg = response && response.data && response.data.message ? response.data.message : 'Ocurrió un error';
                            alert('Error: ' + msg);
                        }
                    },
                    error: function() {
                        alert('No fue posible procesar el reembolso');
                    }
                });
            }
        }
    };

    const waitForRefundSection = setInterval(() => {
        const $refundSection = $('.refund-actions');
        const $confirmBtn = $('.do-manual-refund');

        if ($refundSection.length && $confirmBtn.length && !$('.wc-api-confirm-btn').length) {
            clearInterval(waitForRefundSection);

            const buttonText = bmspay_refund_params.buttonText;
            const $apiBtn = $('<button type="button" class="button button-primary wc-api-confirm-btn">' + buttonText + '</button>');

            $apiBtn.css({
                marginLeft: '10px'
            });

            $confirmBtn.after($apiBtn);

            $apiBtn.on('click', function() {
                const refundAmount = parseMoney($('#refund_amount').val());
                const orderId = parseInt(bmspay_refund_params.order_id, 10);
                const lineItems = collectRefundLineItems();

                if (refundAmount <= 0) {
                    BmspayAlert.showError('El monto del reembolso debe ser mayor a 0.');
                    return;
                }

                if (!Object.keys(lineItems).length) {
                    BmspayAlert.showError('Seleccione al menos una línea válida del pedido para reembolsar.');
                    return;
                }

                showConfirmDialog(refundAmount);
            });
        }
    }, 300);
})(jQuery);