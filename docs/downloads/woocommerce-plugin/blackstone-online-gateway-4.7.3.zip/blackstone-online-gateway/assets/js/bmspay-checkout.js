jQuery(document).ready(function($) {
    var canSubmitForm = false;

    // Alert helper - uses SweetAlert2 with native alert fallback
    var BmspayAlert = {
        show: function(message, type) {
            type = type || 'info';
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: type === 'error' ? 'Error' : (type === 'success' ? 'Éxito' : 'Información'),
                    text: message,
                    icon: type,
                    confirmButtonText: 'OK'
                });
            } else {
                alert((type === 'error' ? 'Error: ' : '') + message);
            }
        },
        showError: function(message) {
            this.show(message, 'error');
        },
        showSuccess: function(message) {
            this.show(message, 'success');
        },
        close: function() {
            if (typeof Swal !== 'undefined' && Swal.getPopup()) {
                Swal.close();
            }
        },
        showLoading: function(title, html) {
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: title || 'Cargando',
                    html: html || 'Por favor espere...',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
            }
        }
    };

    // Send a log entry to the server via AJAX.
    function serverLog(level, message) {
        var params = bmspay_checkout_params || {};
        if (!params.logAjaxUrl || !params.logNonce) {
            return;
        }
        $.post(params.logAjaxUrl, {
            action: 'bmspay_3ds_client_log',
            nonce: params.logNonce,
            level: level,
            message: message
        });
    }

    // Card validation functions (matching PHP validation)
    var BmspayValidator = {
        // Luhn algorithm for card number validation
        luhnCheck: function(cardNumber) {
            var digits = cardNumber.replace(/\D/g, '').split('').reverse();
            var total = 0;
            var odd = false;

            for (var i = 0; i < digits.length; i++) {
                var digit = parseInt(digits[i], 10);
                if (odd) {
                    digit *= 2;
                    if (digit > 9) {
                        digit -= 9;
                    }
                }
                total += digit;
                odd = !odd;
            }

            return total % 10 === 0;
        },

        isValidNumber: function(cardNumber) {
            var clean = cardNumber.replace(/\D/g, '');
            if (clean.length < 13 || clean.length > 19) {
                return false;
            }
            return this.luhnCheck(clean);
        },

        isValidExpiry: function(expiry) {
            var match = expiry.match(/^(0[1-9]|1[0-2])\s*\/\s*([0-9]{2}|[0-9]{4})$/);
            if (!match) {
                return false;
            }

            var month = parseInt(match[1], 10);
            var year = parseInt(match[2], 10);

            if (year < 100) {
                year += 2000;
            }

            var now = new Date();
            var currentYear = now.getFullYear();
            var currentMonth = now.getMonth() + 1;

            // Check if expired
            if (year < currentYear) {
                return false;
            }
            if (year === currentYear && month < currentMonth) {
                return false;
            }

            return true;
        },

        isValidCvc: function(cvc) {
            var clean = cvc.replace(/\D/g, '');
            return clean.length === 3 || clean.length === 4;
        }
    };

    // Determinar si es página de pago de pedido
    var isPayForOrder = window.location.href.indexOf('order-pay') !== -1;

    // Seleccionar el formulario correcto
    var $form = isPayForOrder ? $('#order_review') : $('form.checkout');

    function getSubmitButton() {
        if (isPayForOrder) {
            return $('#place_order');
        }

        var $btn = $('#place_order');
        if ($btn.length === 0) {
            $btn = $('button[name="woocommerce_checkout_place_order"]');
        }
        if ($btn.length === 0) {
            $btn = $('form.checkout').find('button[type="submit"]');
        }
        return $btn;
    }

    function enableSubmitButton() {
        var $submitBtn = getSubmitButton();
        if ($submitBtn.length) {
            $submitBtn.prop('disabled', false);
        }
        $('.woocommerce-ajax-loader').hide();
    }

    function disableSubmitButton() {
        var $submitBtn = getSubmitButton();
        if ($submitBtn.length) {
            $submitBtn.prop('disabled', true);
        }
        $('.woocommerce-ajax-loader').show();
    }

    function cleanup3DS() {
        $('iframe[id^="container-challenge-3ds"]').remove();
        $('#billing-form').remove();
        BmspayAlert.close();
        window.tds = undefined;
        serverLog('debug', '3DS: cleanup done');
    }

    function getChargeAmount() {
        var amount = parseFloat($('#bmspay-charge-amount').val());

        if (Number.isNaN(amount)) {
            amount = parseFloat(bmspay_checkout_params.total);
        }

        return Number.isNaN(amount) ? 0 : amount;
    }

    function initialize3DS(chargeAmount, lastFour) {
        const uniqueId = Date.now();
        const iframeId = 'container-challenge-3ds-' + uniqueId;
        const wrapperId = 'challenge-wrapper-' + uniqueId;
        const loaderId = 'challenge-loader-' + uniqueId;

        serverLog('debug', '3DS: verify started — card=****' + lastFour + ' amount=' + chargeAmount);

        var html_3ds = `
            <div class="threeds-modal-content">
                <div style="width: 100%; height: 430px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9; position: relative; margin: 0 auto;">
                    <div id="${wrapperId}" class="threeds-loading" style="width: 100%; height: 100%; position: relative;"></div>
                    <div id="${loaderId}" class="threeds-loading" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
                        <div class="spinner"></div>
                        <p style="margin-top: 8px; color: #555;">Procesando verificación de seguridad...</p>
                    </div>
                </div>
                <p style="margin-top: 15px; font-size: 12px; color: #666; text-align: center;">Por favor no cierre esta ventana.</p>
            </div>
        `;

        BmspayAlert.showLoading('Verificación 3D Secure', html_3ds);

        setTimeout(function() {
            const wrapper = document.getElementById(wrapperId);
            if (!wrapper) {
                serverLog('error', '3DS: wrapper element not found after showLoading');
                BmspayAlert.showError('Error al inicializar 3D Secure');
                enableSubmitButton();
                return;
            }

            const iframe = document.createElement('iframe');
            iframe.id = iframeId;
            iframe.name = iframeId;
            iframe.style.cssText = `
                width: 420px !important;
                height: 420px !important;
                min-width: 420px !important;
                min-height: 420px !important;
                max-width: 420px !important;
                max-height: 420px !important;
                border: none !important;
                opacity: 0 !important;
                display: block !important;
                position: relative !important;
                transition: opacity 0.3s ease !important;
            `;

            wrapper.appendChild(iframe);

            var apiKey = bmspay_checkout_params.apiKey;
            var token = bmspay_checkout_params.token;

            window.tds = new ThreeDS(
                "billing-form",
                apiKey,
                token,
                {
                    endpoint: bmspay_checkout_params.endpoint,
                    autoSubmit: false,
                    showChallenge: true,
                    popup: false,
                    iframeId: iframeId,
                    forcedTimeOut: '10'
                }
            );

            iframe.onload = function() {
                var loader = document.getElementById(loaderId);
                if (loader) loader.style.display = 'none';
                iframe.style.opacity = '1';
            };

window.tds.verify(
                function(response) {
                    var $tempForm = $('#billing-form');

                    if (!response || (response.status !== 'Y' && response.status !== 'A')) {
                        var status = response && response.status ? response.status : 'unknown';
                        var errorMessage = '3D Secure Verification Failed';
                        if (response && response.transStatusReasonDetail) {
                            errorMessage += ': ' + $('<div>').text(response.transStatusReasonDetail).html();
                        } else if (response && response.status) {
                            errorMessage += ' (Status: ' + $('<div>').text(response.status).html() + ')';
                        }

                        serverLog('warning', '3DS: verify callback — status=' + status + ' card=****' + lastFour);
                        $tempForm.remove();
                        // Also clean up any leftover iframes from this attempt.
                        $('iframe[id^="container-challenge-3ds"]').remove();
                        window.tds = undefined;
                        BmspayAlert.close();
                        BmspayAlert.showError(errorMessage);
                        enableSubmitButton();
                        canSubmitForm = false;
                        return false;
                    }

                    serverLog('debug', '3DS: verify callback — status=' + response.status + ' card=****' + lastFour);

                    var threeDsTransactionId = window.tds.threeDsTransactionId;
                    if (threeDsTransactionId) {
                        response.threeDsTransactionId = threeDsTransactionId;
                    }

                    $tempForm.remove();
                    canSubmitForm = true;
                    BmspayAlert.close();

                    var $targetForm = isPayForOrder ? $('#order_review') : $('form.checkout');

                    if (!$targetForm.find('input[name=threeds_response]').length) {
                        $('<input>').attr({
                            type: 'hidden',
                            name: 'threeds_response',
                            value: JSON.stringify(response)
                        }).appendTo($targetForm);
                    } else {
                        $targetForm.find('input[name=threeds_response]').val(JSON.stringify(response));
                    }

                    cleanup3DS();
                    $targetForm.submit();
                },
                function(error) {
                    var errorObj = error;
                    var errorMessage = '';

                    if (typeof error === 'string') {
                        if (error.trim() === '') {
                            errorMessage = 'Error de conexión desconocido';
                        } else {
                            try {
                                errorObj = JSON.parse(error);
                            } catch (e) {
                                errorMessage = error;
                            }
                        }
                    }

                    if (!errorMessage && errorObj && typeof errorObj === 'object') {
                        errorMessage = errorObj.error || errorObj.message || 'Error de conexión desconocido';
                    }

                    if (errorMessage === 'No result found for transaction as yet. Please subscribe again' ||
                        errorMessage === 'No result found for transaction as yet') {
                        // Per Blackstone docs: this message is emitted by the library's internal
                        // polling loop and is NOT a terminal error. Do not clean up — let the
                        // library continue polling until it gets a final result.
                        serverLog('debug', '3DS: polling — no result yet for card=****' + lastFour);
                        return;
                    }

                    if (!errorMessage) {
                        cleanup3DS();
                        enableSubmitButton();
                        canSubmitForm = false;
                        return;
                    }

                    serverLog('error', '3DS: error callback — ' + errorMessage.substring(0, 200) + ' card=****' + lastFour);
                    // Ensure #billing-form and iframes are removed so a retry starts clean.
                    cleanup3DS();
                    BmspayAlert.close();
                    BmspayAlert.showError(errorMessage);
                    enableSubmitButton();
                    canSubmitForm = false;
                    return false;
                },
                {
                    amount: chargeAmount,
                    currency: bmspay_checkout_params.currency || '840'
                }
            );
        }, 100);
    }

    $form.on('submit', function(e) {
        if ($('input[name="payment_method"]:checked').val() === 'bmspay_blackstone_payment') {
            if (!canSubmitForm) {
                e.preventDefault();
                e.stopImmediatePropagation();

                disableSubmitButton();

                var selectedToken = $('input[name="wc-saved-payment-token"]:checked').val();
                if (selectedToken && selectedToken !== 'new') {
                    canSubmitForm = true;
                    $form.trigger('submit');
                    return;
                }

                var cardNumber = $('#bmspay_blackstone_payment-card-number').val().replace(/\s+/g, '');
                var expiry = $('#bmspay_blackstone_payment-card-expiry').val().replace(/\s+/g, '');
                var cvv = $('#bmspay_blackstone_payment-card-cvc').val();
                var billingPostCode = $('#billing_postcode').val();
                var cardHolderName = $('#billing_first_name').val() + ' ' + $('#billing_last_name').val();
                var chargeAmount = getChargeAmount();
                var lastFour = cardNumber.slice(-4);

                // Card validation (matching PHP Bmspay_Card_Validator)
                if (!BmspayValidator.isValidNumber(cardNumber)) {
                    BmspayAlert.showError('Por favor ingrese un número de tarjeta válido');
                    enableSubmitButton();
                    return;
                }

                var expiryMatch = expiry.match(/^(0[1-9]|1[0-2])\s*\/\s*([0-9]{2}|[0-9]{4})$/);
                if (!expiryMatch || !BmspayValidator.isValidExpiry(expiry)) {
                    BmspayAlert.showError('Por favor ingrese una fecha de expiración válida (MM/YY) y que no esté vencida');
                    enableSubmitButton();
                    return;
                }

                var month = expiryMatch[1];
                var year = expiryMatch[2];

                if (!BmspayValidator.isValidCvc(cvv)) {
                    BmspayAlert.showError('Por favor ingrese un código de seguridad (CVV) válido (3 o 4 dígitos)');
                    enableSubmitButton();
                    return;
                }

                // Remove any leftover #billing-form from a previous failed attempt
                // before creating a fresh one with the current card data.
                $('#billing-form').remove();

                var $tempForm = $('<form id="billing-form" style="display:none;"></form>').appendTo('body');
                $tempForm.append($('<input type="hidden" name="billing-card-amount" />').val(chargeAmount).attr('data-threeds', 'amount'));
                $tempForm.append($('<input type="hidden" name="billing-card-pan" />').val(cardNumber).attr('data-threeds', 'pan'));
                $tempForm.append($('<input type="hidden" name="billing-card-month" />').val(month).attr('data-threeds', 'month'));
                $tempForm.append($('<input type="hidden" name="billing-card-year" />').val(year).attr('data-threeds', 'year'));
                $tempForm.append($('<input type="hidden" name="billing-card-cvv" />').val(cvv).attr('data-threeds', 'cvv'));
                $tempForm.append($('<input type="hidden" name="billing-card-billing-post-code" />').val(billingPostCode).attr('data-threeds', 'billingPostCode'));
                $tempForm.append($('<input type="hidden" name="billing-card-holder-name" />').val(cardHolderName).attr('data-threeds', 'cardHolderName'));

                initialize3DS(chargeAmount, lastFour);
            }
        }
    });
});
