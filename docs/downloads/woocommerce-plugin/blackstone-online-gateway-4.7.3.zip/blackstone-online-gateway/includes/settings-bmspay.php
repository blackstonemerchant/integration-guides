<?php
/**
 * Blackstone Payment Gateway Settings
 *
 * @package Blackstone_Online_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return apply_filters(
	'bmspay_form_fields',
	array(
		// ============================================
		// SECTION: BASIC SETTINGS
		// ============================================
		'enabled' => array(
			'title'   => __( 'Enable / Disable', 'blackstone-online-gateway' ),
			'type'    => 'checkbox',
			'label'   => __( 'Enable Blackstone payment gateway', 'blackstone-online-gateway' ),
			'default' => 'no',
		),
		'title' => array(
			'title'       => __( 'Title', 'blackstone-online-gateway' ),
			'type'        => 'text',
			'description' => __( 'Payment method title shown to customers at checkout.', 'blackstone-online-gateway' ),
			'default'     => __( 'Credit Card', 'blackstone-online-gateway' ),
			'desc_tip'    => true,
		),
		'description' => array(
			'title'       => __( 'Description', 'blackstone-online-gateway' ),
			'type'        => 'textarea',
			'description' => __( 'Instructions displayed to customers during checkout.', 'blackstone-online-gateway' ),
			'default'     => __( 'Pay securely with your credit or debit card.', 'blackstone-online-gateway' ),
			'desc_tip'    => true,
			'css'         => 'max-width:450px;',
		),

		// ============================================
		// SECTION: API CREDENTIALS
		// ============================================
		'api_credentials' => array(
			'title'       => __( 'API Credentials', 'blackstone-online-gateway' ),
			'type'        => 'title',
			'description' => __( 'Enter the API credentials provided by Blackstone when you opened your merchant account.', 'blackstone-online-gateway' ),
		),
		'api_username' => array(
			'title'       => __( 'API Username', 'blackstone-online-gateway' ),
			'type'        => 'text',
			'description' => __( 'Your Blackstone API username. Find it in your merchant dashboard under Settings > API Access.', 'blackstone-online-gateway' ),
			'desc_tip'    => true,
			'placeholder' => __( 'e.g., your_username', 'blackstone-online-gateway' ),
		),
		'api_password' => array(
			'title'       => __( 'API Password', 'blackstone-online-gateway' ),
			'type'        => 'password',
			'description' => __( 'Your Blackstone API password. Keep this confidential.', 'blackstone-online-gateway' ),
			'desc_tip'    => true,
		),
		'api_mid' => array(
			'title'       => __( 'Merchant ID (MID)', 'blackstone-online-gateway' ),
			'type'        => 'text',
			'description' => __( 'Your unique Merchant ID assigned by Blackstone. Required for processing transactions.', 'blackstone-online-gateway' ),
			'desc_tip'    => true,
			'placeholder' => __( 'e.g., 76074', 'blackstone-online-gateway' ),
		),
		'api_cid' => array(
			'title'       => __( 'Client ID (CID)', 'blackstone-online-gateway' ),
			'type'        => 'text',
			'description' => __( 'Your Client ID for API authentication.', 'blackstone-online-gateway' ),
			'desc_tip'    => true,
			'placeholder' => __( 'e.g., 260', 'blackstone-online-gateway' ),
		),
		'app_type' => array(
			'title'       => __( 'App Type', 'blackstone-online-gateway' ),
			'type'        => 'text',
			'description' => __( 'Application type identifier provided by Blackstone.', 'blackstone-online-gateway' ),
			'desc_tip'    => true,
			'placeholder' => __( 'e.g., 1', 'blackstone-online-gateway' ),
		),
		'app_key' => array(
			'title'       => __( 'App Key', 'blackstone-online-gateway' ),
			'type'        => 'password',
			'description' => __( 'Your application key for secure API communication. Find it in your Blackstone merchant dashboard.', 'blackstone-online-gateway' ),
			'desc_tip'    => true,
		),

		// ============================================
		// SECTION: ENVIRONMENT
		// ============================================
		'environment_settings' => array(
			'title'       => __( 'Environment', 'blackstone-online-gateway' ),
			'type'        => 'title',
			'description' => __( 'Select whether to process real transactions or use the sandbox for testing.', 'blackstone-online-gateway' ),
		),
		'environment' => array(
			'title'       => __( 'Gateway Environment', 'blackstone-online-gateway' ),
			'type'        => 'select',
			'description' => __( 'Production processes real payments. Sandbox is for testing only - no real charges will be made.', 'blackstone-online-gateway' ),
			'default'     => 'no',
			'desc_tip'    => true,
			'options'     => array(
				'no'  => __( 'Production (Live Transactions)', 'blackstone-online-gateway' ),
				'yes' => __( 'Sandbox (Test Transactions)', 'blackstone-online-gateway' ),
			),
		),

		// ============================================
		// SECTION: 3D SECURE
		// ============================================
		'threed_secure_settings' => array(
			'title'       => __( '3D Secure', 'blackstone-online-gateway' ),
			'type'        => 'title',
			'description' => __( '3D Secure adds an extra verification step during payment for enhanced security and fraud prevention.', 'blackstone-online-gateway' ),
		),
		'environment_3ds' => array(
			'title'   => __( 'Enable 3D Secure', 'blackstone-online-gateway' ),
			'type'    => 'checkbox',
			'label'   => __( 'Require 3D Secure authentication', 'blackstone-online-gateway' ),
			'description' => __( '3D Secure requires TWO steps to be fully active:', 'blackstone-online-gateway' ) . '<br/>' .
				'1. ' . __( 'This plugin setting must be enabled', 'blackstone-online-gateway' ) . '<br/>' .
				'2. ' . __( '3D Secure must be activated in your Blackstone merchant dashboard (contact Blackstone support)', 'blackstone-online-gateway' ) . '<br/><br/>' .
				__( 'If 3D Secure is not enabled in Blackstone, transactions may fail even with this option turned on.', 'blackstone-online-gateway' ),
			'default' => 'no',
			'desc_tip' => true,
		),

		// ============================================
		// SECTION: PRICING LABELS
		// ============================================
		'pricing_labels' => array(
			'title'       => __( 'Fee Labels', 'blackstone-online-gateway' ),
			'type'        => 'title',
			'description' => __( 'Customize how additional payment fees appear to customers at checkout.', 'blackstone-online-gateway' ),
		),
		'label_surcharge' => array(
			'title'       => __( 'Surcharge Label', 'blackstone-online-gateway' ),
			'type'        => 'text',
			'description' => __( 'Label for the extra fee added when customers pay with credit card (e.g., "Card Processing Fee").', 'blackstone-online-gateway' ),
			'default'     => __( 'Card Processing Fee', 'blackstone-online-gateway' ),
			'desc_tip'    => true,
		),
		'label_card_difference' => array(
			'title'       => __( 'Cash Discount Label', 'blackstone-online-gateway' ),
			'type'        => 'text',
			'description' => __( 'Label for the price difference when paying by card (higher) vs cash (lower).', 'blackstone-online-gateway' ),
			'default'     => __( 'Card Price Difference', 'blackstone-online-gateway' ),
			'desc_tip'    => true,
		),

		// ============================================
		// SECTION: DEBUGGING
		// ============================================
		'debug_settings' => array(
			'title'       => __( 'Debugging', 'blackstone-online-gateway' ),
			'type'        => 'title',
			'description' => __( 'Debug logging records detailed information about API requests and responses. Enable this when troubleshooting payment issues.', 'blackstone-online-gateway' ),
		),
		'debug' => array(
			'title'   => __( 'Debug Log', 'blackstone-online-gateway' ),
			'type'    => 'checkbox',
			'label'   => __( 'Enable debug logging', 'blackstone-online-gateway' ),
			'description' => __( 'Log API requests/responses and gateway events. View in WooCommerce > Status > Logs:', 'blackstone-online-gateway' ) . '<br/>' .
				'• <code>bmspay-*.log</code> - ' . __( 'General API requests and responses', 'blackstone-online-gateway' ) . '<br/>' .
				'• <code>bmspay-gateway-*.log</code> - ' . __( 'Gateway operations (3DS, checkout flow)', 'blackstone-online-gateway' ) . '<br/>' .
				'• <code>bmspay-XX-sale-*.log</code> - ' . __( 'Per-order logs (XX = order ID)', 'blackstone-online-gateway' ),
			'default' => 'no',
		),
	)
);
