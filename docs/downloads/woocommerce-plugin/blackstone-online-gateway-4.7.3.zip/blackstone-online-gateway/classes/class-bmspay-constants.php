<?php
/**
 * Blackstone Constants
 *
 * Defines constants and static configuration for Blackstone API integration.
 *
 * @package Blackstone_Online_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bmspay_Constants class.
 *
 * 
 */
class Bmspay_Constants {

	/**
	 * Plugin version.
	 *
	 * @var string
	 */
	const PLUGIN_VERSION = '1.0.0';

	/**
	 * API source identifier.
	 *
	 * @var string
	 */
	const SOURCE = 'BPaydPlugin';

	/**
	 * Sandbox API URL.
	 *
	 * @var string
	 */
	const ENV_SANDBOX_URL = 'https://services.bmspay.com/testing/api/';

	/**
	 * Production API URL.
	 *
	 * @var string
	 */
	const ENV_PRODUCTION_URL = 'https://services.bmspay.com/api/';

	/**
	 * API endpoint mapping.
	 *
	 * @var array
	 */
	const API_ENDPOINTS = array(
		'BusinessSettings'    => 'BusinessSettings',
		'Auth/TokenThreeDS'  => 'Auth/TokenThreeDS',
		'Sale'               => 'Transactions/Sale',
		'SaleToken'         => 'Transactions/SaleWithToken',
		'DoRefund'          => 'Transactions/DoRefund',
	);

	/**
	 * API content types.
	 *
	 * @var array
	 */
	const API_CONTENT_TYPES = array(
		'json' => 'application/json',
	);

	/**
	 * Response code human-readable messages.
	 *
	 * @var array
	 */
	const RESPONSE_CODES = array(
		'100' => 'Card declined. Please try a different payment method.',
		'101' => 'Insufficient funds. Please check your account balance.',
		'102' => 'Card expired. Please use a valid card.',
		'103' => 'Invalid card number. Please check and try again.',
		'104' => 'Invalid security code (CVV). Please check and try again.',
		'105' => 'Card reported as stolen. Please use a different card.',
		'200' => 'Authentication failed. Please verify your identity with your bank.',
		'300' => 'Invalid request parameters.',
		'500' => 'Gateway temporarily unavailable. Please try again in a few minutes.',
	);

	/**
	 * Response codes that indicate success.
	 *
	 * @var array
	 */
	const RESPONSE_CODES_SUCCESS = array(
		'200',
		'SUCCESS',
	);

	/**
	 * Transaction type mapping.
	 *
	 * @var array
	 */
	const TRANSACTION_TYPES = array(
		'sale'            => 1,
		'sale_with_token' => 2,
	);

	/**
	 * Point of sale code.
	 *
	 * @var string
	 */
	const POS_CODE = 'Moto';

	/**
	 * 3DS API endpoints.
	 *
	 * @var array
	 */
	const THREE_DS_ENDPOINTS = array(
		'sandbox'    => 'https://api-sandbox.3dsintegrator.com/v2.2',
		'production' => 'https://api.3dsintegrator.com/v2.2',
	);

	/**
	 * 3DS status messages.
	 *
	 * @var array
	 */
	const THREE_DS_STATUS_MESSAGES = array(
		'Y' => 'Authentication successful',
		'A' => 'Authentication attempted but not frictionless',
		'N' => 'Authentication failed',
		'C' => 'Challenge required; additional authentication needed',
		'R' => 'Authentication / Account verification rejected',
		'U' => 'Technical or system error',
		'I' => 'Technical or system error',
	);

	/**
	 * 3DS statuses that indicate success.
	 *
	 * @var array
	 */
	const THREE_DS_STATUS_SUCCESS = array( 'Y', 'A' );

	/**
	 * 3DS statuses that indicate failure.
	 *
	 * @var array
	 */
	const THREE_DS_STATUS_FAILURE = array( 'N', 'C', 'R', 'U', 'I' );

	/**
	 * Default test mode setting.
	 *
	 * @var string
	 */
	const DEFAULT_TEST_MODE = 'no';

	/**
	 * Default 3DS test mode setting.
	 *
	 * @var string
	 */
	const DEFAULT_3DS_TEST_MODE = 'no';

	/**
	 * Default surcharge label.
	 *
	 * @var string
	 */
	const DEFAULT_SURCHARGE_LABEL = 'Surcharge';

	/**
	 * Default card difference label.
	 *
	 * @var string
	 */
	const DEFAULT_CARD_DIFFERENCE_LABEL = 'Dual pricing';

	/**
	 * API timeout in seconds.
	 *
	 * @var int
	 */
	const API_TIMEOUT = 90;

	/**
	 * Short API timeout in seconds.
	 *
	 * @var int
	 */
	const API_TIMEOUT_SHORT = 45;

	/**
	 * Sensitive fields that should be masked in logs.
	 *
	 * @var array
	 */
	const SENSITIVE_FIELDS = array(
		'CardNumber',
		'CVN',
		'Password',
		'AppKey',
		'Token',
	);

	/**
	 * Check if response code indicates success.
	 *
	 * 
	 * @param string $code Response code.
	 * @return bool
	 */
	public static function is_success_code( $code ) {
		return in_array( $code, self::RESPONSE_CODES_SUCCESS, true );
	}

	/**
	 * Check if 3DS status indicates success.
	 *
	 * 
	 * @param string $status 3DS status.
	 * @return bool
	 */
	public static function is_3ds_success( $status ) {
		return in_array( $status, self::THREE_DS_STATUS_SUCCESS, true );
	}

	/**
	 * Check if 3DS status indicates failure.
	 *
	 * 
	 * @param string $status 3DS status.
	 * @return bool
	 */
	public static function is_3ds_failure( $status ) {
		return in_array( $status, self::THREE_DS_STATUS_FAILURE, true );
	}
}
