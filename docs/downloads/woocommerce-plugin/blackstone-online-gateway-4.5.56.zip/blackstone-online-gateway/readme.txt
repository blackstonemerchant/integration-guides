=== Blackstone Online Gateway ===
Contributors: carlosraul7
Donate link: https://blackstoneonline.com/
Tags: woocommerce, payment, gateway, blackstone, credit card
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 4.5.56
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Custom payment gateway integration for WooCommerce using Blackstone Merchant. Secure, fast and reliable payments for your online store.

== Description ==

**Blackstone Online Gateway** is a custom payment integration for WooCommerce that allows merchants to process payments through the Blackstone Merchant platform.  
It provides a seamless Payments experience, secure communication with the API, and supports refund handling directly via WooCommerce.

### Main Features

* Full integration with WooCommerce.
* Secure API connection to Blackstone Merchant.
* Supports payment authorization, capture and refund.
* Refund processing via API with stock management.
* Admin settings page for easy configuration.
* Compatible with the latest versions of WooCommerce and WordPress.

This plugin requires an active merchant account with [Blackstone Merchant](https://www.blackstonemerchant.com/).

== External Services ==

This plugin relies on third-party services to process payments and perform security verifications. Below is the list of external services used:

= BMS Pay API =
*   **Service Purpose**: Used to process payments (authorization/capture) and refunds securely.
*   **Endpoints Used**:
    *   `BusinessSettings`: Retrieves merchant-specific configuration (surcharges, 3DS status, and display labels).
    *   `Transactions/Sale`: Processes new payments when card data is entered manually.
    *   `Transactions/SaleWithToken`: Processes payments using secure tokens for customers with saved cards.
    *   `Transactions/DoRefund`: Handles full or partial refunds directly from the WooCommerce admin.
    *   `Auth/TokenThreeDS`: Generates secure authentication tokens specifically for 3D Secure verification.
*   **Data Sent**: Transaction details (amount, currency, order ID), and customer credit card information (encrypted and processed securely via API). Data is sent only when an order is being processed or a refund is initiated by the administrator.
*   **Provier**: Blackstone Merchant Services (BMS).
*   **Links**:
    *   [Terms of Service](https://www.blackstoneonline.com/es/legal/terms-of-service)
    *   [Privacy Policy](https://www.blackstoneonline.com/es/legal/privacy-policy)
    *   [API Documentation](https://documentation.bmspay.com/index.html)

= 3DS Integrator =
*   **Service Purpose**: Used for 3D Secure (3DS) authentication to prevent fraud and ensure secure transactions.
*   **Scripts Used**:
    *   `ThreeDS.js`: Handles the core logic for 3D Secure 2.0 authentication and bank-side interaction.
    *   `threeds.2.2.20231219.min.js`: Performs silent "Device Fingerprinting" to identify the device and assess transaction risk.
*   **Data Sent**: Card identifiers, merchant ID, and transaction amount for risk analysis. This involves loading external JavaScript from their CDN for browser-side verification.
*   **Provider**: 3DS Integrator (via Blackstone).
*   **Links**:
    *   [Terms of Service](https://www.blackstoneonline.com/es/legal/terms-of-service)
    *   [Privacy Policy](https://www.blackstoneonline.com/es/legal/privacy-policy)

== Bundled Libraries ==

This plugin includes the following third-party libraries:

*   **SweetAlert2**: A beautiful, responsive, and customizable replacement for JavaScript's popup boxes. It is used to provide enhanced user notifications and modal alerts during the checkout and payment process.
*   **Inputmask**: A jQuery plugin used to create input masks. It ensures that sensitive data, such as credit card numbers and expiration dates, are entered in the correct format by the user.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install it directly from the WordPress Plugin Directory.
2. Activate the plugin through the *Plugins* menu in WordPress.
3. Go to **WooCommerce → Settings → Payments → Blackstone Merchant**.
4. Enable the gateway and enter your merchant credentials (API keys, merchant ID, etc.).
5. Save changes and test the Payments process.

== Frequently Asked Questions ==

= Do I need a Blackstone Merchant account? =  
Yes. You must have an approved merchant account from [Blackstone Merchant](https://www.blackstonemerchant.com/) to process transactions.

= Does this plugin support refunds? =  
Yes. Refunds can be processed directly from the WooCommerce order screen. The plugin sends refund requests securely to the Blackstone API.

= Is it compatible with WooCommerce Subscriptions or Bookings? =  
Currently, it supports standard one-time payments. Future versions may include support for recurring billing.

= Does it store credit card information? =  
No. The plugin does **not** store or log any sensitive card data. All transactions are handled securely through the Blackstone Merchant gateway.

== Screenshots ==

1. Payment gateway settings 1 — Configuration screen under WooCommerce → Settings → Payments → Blackstone Merchant.
2. Payment gateway settings 1 — Configuration screen under WooCommerce → Settings → Payments → Blackstone Merchant.
3. Checkout page — The Blackstone Merchant option displayed at Payments for customers.

== Changelog ==

= 4.5.56 =
* **Fix**: Bypassed traditional card field validation on the frontend when using a saved card (token).
* **3D Secure**: Fixed backend validation to prevent "Invalid 3DS response data" errors during tokenized transactions.

= 4.5.55 =
* **Feature**: Added a 3-minute countdown timer to the 3DS verification modal for better user feedback.
* **3D Secure**: Optimized session timeout parameters (`forcedTimeout`) and improved handling of verification responses.
* **UI/UX**: Enhanced error messaging when 3DS verification fails or times out. Reorganized 3DS modal layout for better readability.

= 4.5.54 =
* **Security**: Implemented mandatory nonce verification for checkout, refund, and admin AJAX actions. Added role-based capability checks (`edit_shop_orders`) for sensitive operations.
* **Compliance**: Refactored all AJAX actions and script handles with unique prefixes (`bmspay_` and `bmspay-`) to ensure compatibility and prevent conflicts.
* **Libraries**: Upgraded SweetAlert2 to version `11.26.18`. Renamed script handles for Inputmask and SweetAlert2.
* **Sanitization**: Improved data sanitization and validation (wp_unslash, sanitize_text_field, absint) across the refund processing flow.
* **Documentation**: Updated `readme.txt` with required external service disclosures and bundled library information.

= 4.5.43 =
* Added compatibility with WooCommerce 9.x.
* Improved refund API handling and error responses.
* Minor performance and security updates.
* Improved text translation.
* Added data to refund notes for better traceability.
* Standardized file and folder names.

= 4.5.0 =
* Initial public release.
* Added support for payment authorization and capture.
* Introduced refund integration via API.

== Upgrade Notice ==

= 4.5.48 =
* Fixed: JavaScript conflict on checkout page (undefined 'defaults' error) by restricting script loading.
* Improved: Script loading logic to prevent conflicts with other plugins.

= 4.5.49 =
* Fixed: JavaScript conflict on checkout page (undefined 'defaults' error) by restricting script loading.
* Improved: Script loading logic to prevent conflicts with other plugins.

= 4.5.50 =
* Fixed: JavaScript conflict on checkout page (undefined 'defaults' error) by restricting script loading.
* Improved: Script loading logic to prevent conflicts with other plugins.

= 4.5.51 =
* Fixed unescaped output for `wc_price`.
* Implemented nonce verification in AJAX/forms.

= 4.5.52 =
* Removed debug logs (`error_log`/`print_r`).
* Prefixed global functions with `bmspay_`.

= 4.5.53 =
* Fixed: 3DSecure not working on checkout page.

= 4.5.54 =
* **Security & Compliance Update**: This version introduces unique prefixing for all scripts, actions, and metadata to comply with security standards and prevent conflicts. It also upgrades SweetAlert2 to `11.26.18` and adds mandatory nonce and capability checks.

= 4.5.55 =
* **3D Secure Enhancement**: Added a visual countdown timer to the 3DS modal and optimized verification timeout handling to improve the payment experience.

= 4.5.56 =
* **Token Payments Fix**: This version resolves validation issues and 3DS response errors occurring when processing payments with saved cards (tokens).

== License ==

This plugin is licensed under the GPLv2 or later license.  
You are free to modify and redistribute it under the same license.  
See https://www.gnu.org/licenses/gpl-2.0.html for details.

== Credits ==

Developed and maintained by **Blackstone**  
Website: [https://blackstoneonline.com/](https://blackstoneonline.com/)  
Blackstone Merchant official site: [https://www.blackstonemerchant.com/](https://www.blackstonemerchant.com/)
