(function($) {
    const waitForRefundSection = setInterval(() => {
        const $refundSection = $('.refund-actions');
        const $confirmBtn = $('.do-manual-refund');

        if ($refundSection.length && $confirmBtn.length && !$('.wc-api-confirm-btn').length) {
            clearInterval(waitForRefundSection);

            // Use params passed from PHP
            const buttonText = bmspay_refund_params.buttonText;
            const $apiBtn = $('<button type="button" class="button button-primary wc-api-confirm-btn">' + buttonText + '</button>');
            $apiBtn.css({
                'margin-left': '10px'
            });
            $confirmBtn.after($apiBtn);

            $apiBtn.on('click', function() {
                const refundAmount = parseFloat($('#refund_amount').val()) || 0;
                const reason = $('#refund_reason').val() || '';
                const order_id = parseInt(bmspay_refund_params.order_id);

                const lineItems = {};

                $('tr.item', '.woocommerce_order_items').each(function() {
                    const itemId = $(this).data('order_item_id');
                    const qtyInput = $(this).find('input.refund_order_item_qty');
                    const totalInput = $(this).find('input.refund_line_total');
                    const productName = $(this).find('.wc-order-item-name').text().trim();

                    if (qtyInput.length) {
                        const qty = parseFloat(qtyInput.val()) || 0;
                        if (qty > 0) {
                            lineItems[itemId] = {
                                id: itemId,
                                name: productName,
                                qty: qty,
                                total: parseFloat(totalInput.val()) || 0
                            };
                        }
                    }
                });

                if (refundAmount <= 0) {
                    Swal.fire('Error', 'El monto del reembolso debe ser mayor a 0.', 'error');
                    return;
                }

                Swal.fire({
                    title: '¿Está seguro?',
                    text: '¿Desea procesar este reembolso por $' + refundAmount.toFixed(2) + '?',
                    icon: 'warning',
                    showCancelButton: true,
                    cancelButtonText: 'Cancelar',
                    confirmButtonText: 'Sí, reembolsar',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        return new Promise((resolve, reject) => {
                            $.post(bmspay_refund_params.ajaxurl, {
                                action: 'bmspay_process_api_refund',
                                security: bmspay_refund_params.security,
                                order_id: order_id,
                                refund_amount: refundAmount,
                                refund_reason: reason,
                                restock_items: $('#restock_refunded_items').is(':checked') ? 1 : 0,
                                line_items: JSON.stringify(lineItems)
                            }, function(response) {
                                if (response.success) {
                                    resolve(response.data.message);
                                } else {
                                    console.log('Error: Reembolso no procesado ' + response.data.message);
                                    reject(response.data.message || 'Ocurrió un error al procesar el reembolso.');
                                }
                            });
                        });
                    },
                    allowOutsideClick: () => !Swal.isLoading()
                }).then((result) => {
                    if (result.isConfirmed) {
                        Swal.fire('¡Completado!', result.value, 'success').then(() => {
                            location.reload();
                        });
                    }
                }).catch((error) => {
                    console.log('Error: Reembolso no procesado ' + error);
                    Swal.fire('Error', error, 'error');
                });
            });
        }
    }, 300);
})(jQuery);
