jQuery(document).ready(function($) {
    $('input[name="wc-saved-payment-token"]').change(function() {
        if ($(this).val() === 'new') {
            $('#new-payment-method').slideDown();
        } else {
            $('#new-payment-method').slideUp();
        }
    });

    if ($('input[name="wc-saved-payment-token"]:checked').val() !== 'new') {
        $('#new-payment-method').hide();
    }
});
