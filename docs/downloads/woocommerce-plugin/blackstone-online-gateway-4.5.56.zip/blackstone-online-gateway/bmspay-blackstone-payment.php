<?php
if (!defined('ABSPATH')) exit;
class bmspay_Blackstone_Payment extends WC_Payment_Gateway_CC
{
  public $environment;
  public $environment_3ds;
  public $app_key;
  public $api_username;
  public $api_password;
  public $api_mid;
  public $api_cid;
  public $app_type;
  public $label_surcharge;
  public $label_card_difference;

  function __construct()
  {
    $this->id = "bmspay_blackstone_payment";
    $this->method_title = __("Blackstone", 'blackstone-online-gateway');
    $this->method_description = __("Blackstone Online Gateway Plug-in for WooCommerce", 'blackstone-online-gateway');
    $this->title = __("Blackstone", 'blackstone-online-gateway');
    $this->icon = null;
    $this->has_fields = true;
    $this->supports = array('default_credit_card_form');
    $this->init_form_fields();
    $this->init_settings();

    foreach ($this->settings as $setting_key => $value) {
      $this->$setting_key = $value;
    }

    add_action('admin_notices', array($this,  'do_ssl_check'));
    remove_action('woocommerce_review_order_after_submit', 'woocommerce_order_submit_button', 10);

    add_action('wp_enqueue_scripts', array($this, 'enqueue_checkout_assets'));

    if (is_admin()) {
      add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }
  }

  public static function bmspay_3ds_log()
  {
    wp_send_json_success();
  }

  public function enqueue_checkout_assets()
  {
    if (is_checkout() || bmspay_is_order_pay_page()) {
      if ($this->enabled !== 'yes') return;

      // Enqueue Styles
      wp_enqueue_style(
        'bmspay-payment-form',
        plugins_url('assets/css/bmspay-payment-form.css', __FILE__),
        array(),
        '1.0.0'
      );

      // Enqueue Scripts
      wp_enqueue_script(
        'bmspay-payment-form',
        plugins_url('assets/js/bmspay-payment-form.js', __FILE__),
        array('jquery'),
        '1.0.0',
        true
      );

      // Enqueue SweetAlert2 if not already enqueued
      wp_enqueue_script(
        'bmspay-sweetalert2',
        plugins_url('assets/js/sweetalert2_11.js', __FILE__),
        array('jquery'),
        '11.26.18',
        true
      );

      // 3D Secure Logic
      $surcharge_data = $this->get_cached_surcharge_data();
      $threeds_enabled = $surcharge_data['response_ThreeDSecureEnabled'];

      if ($threeds_enabled) {
        $threed_secure_data = $this->get_merchant_tokenthreeds();
        $apiKey = $threed_secure_data['response_ApiKey'];
        $token = $threed_secure_data['response_Token'];

        if (!empty($apiKey) && !empty($token)) {
          WC()->session->set('bmspay_threed_secure_apikey', $apiKey);
          WC()->session->set('bmspay_threed_secure_token', $token);

          $environment = $this->getEnvironment3DS();
          $endpoint = $environment == 'yes'
            ? 'https://api-sandbox.3dsintegrator.com/v2.2'
            : 'https://api.3dsintegrator.com/v2.2';

          // Enqueue 3DS Library
          // Use CDN as per documentation to avoid 401 on API endpoint
          wp_enqueue_script(
            'bmspay-3ds',
            'https://cdn.3dsintegrator.com/v2.2/js/ThreeDS.js',
            array(),
            '4.5.51',
            true
          );

          wp_enqueue_script(
            'bmspay-checkout',
            plugins_url('assets/js/bmspay-checkout.js', __FILE__),
            array('jquery', 'bmspay-sweetalert2', 'bmspay-3ds'), // Depends on 3DS lib
            time(),
            true
          );

          $base_total = bmspay_get_total_amount();
          $amounts = $this->otherAmount($base_total);

          // Ensure values are floats for calculation (remove commas if present)
          $total_val = (float)str_replace(',', '', $amounts->total);
          $surcharge_val = (float)str_replace(',', '', $amounts->total_surcharge);
          $diff_val = (float)str_replace(',', '', $amounts->total_card_difference);

          $grand_total = $total_val + $surcharge_val + $diff_val;

          wp_localize_script('bmspay-checkout', 'bmspay_checkout_params', array(
            'apiKey' => $apiKey,
            'token' => $token,
            'total' => number_format($grand_total, 2, '.', ''),
            'endpoint' => $endpoint,
            'ajax_url' => admin_url('admin-ajax.php')
          ));
        }
      }
    }
  }

  public function init_form_fields()
  {
    $this->form_fields = array(
      'enabled'      => array(
        'title'        => __('Enable / Disable', 'blackstone-online-gateway'),
        'label'        => __('Enable this payment gateway', 'blackstone-online-gateway'),
        'type'         => 'checkbox',
        'default'      => 'no',
      ),
      'title'        => array(
        'title'        => __('Title', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('Payment title of checkout process.', 'blackstone-online-gateway'),
        'default'      => __('Credit card', 'blackstone-online-gateway'),
      ),
      'description'  => array(
        'title'        => __('Description', 'blackstone-online-gateway'),
        'type'         => 'textarea',
        'desc_tip'     => __('Payment title of checkout process.', 'blackstone-online-gateway'),
        'default'      => __('Successfully payment through credit card.', 'blackstone-online-gateway'),
        'css'          => 'max-width:450px;'
      ),
      'api_username' => array(
        'title'        => __('Username', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the username provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'api_password' => array(
        'title'        => __('Password', 'blackstone-online-gateway'),
        'type'         => 'password',
        'desc_tip'     => __('This is the password provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'api_mid'      => array(
        'title'        => __('MID', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the MID code provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'api_cid'      => array(
        'title'        => __('CID', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the CID code provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'app_type'     => array(
        'title'        => __('App Type', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the App Type provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'app_key'      => array(
        'title'        => __('App Key', 'blackstone-online-gateway'),
        'type'         => 'password',
        'desc_tip'     => __('This is the App Key provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'environment'  => array(
        'title'        => __('Test Mode', 'blackstone-online-gateway'),
        'label'        => __('Enable Test Mode', 'blackstone-online-gateway'),
        'type'         => 'checkbox',
        'desc_tip'     => __('This is the sandbox of the gateway.', 'blackstone-online-gateway'),
        'default'      => 'no',
      ),
      'environment_3ds'  => array(
        'title'        => __('3D Secure Test Mode', 'blackstone-online-gateway'),
        'label'        => __('Enable 3D Secure Test Mode', 'blackstone-online-gateway'),
        'type'         => 'checkbox',
        'desc_tip'  => __('This is the sandbox of 3D Secure.', 'blackstone-online-gateway'),
        'default'      => 'no',
      ),
      'label_surcharge' => array(
        'title'        => __('Surcharge Label', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the name that will be shown to your customers wherever a surcharge is applied (for example, in the order summary or invoice).', 'blackstone-online-gateway'),
        'default'      => 'Surcharge',
      ),
      'label_card_difference' => array(
        'title'        => __('Dual Pricing Label', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the name that will be shown to your customers wherever the card difference (dual pricing) is applied. For example, in the order summary or invoice.', 'blackstone-online-gateway'),
        'default'      => 'Dual pricing',
      ),
    );
  }

  public function payment_fields()
  {
    if ($this->enabled !== 'yes') {
      return;
    }
    $user_id = get_current_user_id();
    $saved_methods = WC_Payment_Tokens::get_customer_tokens($user_id);

    echo '<div id="saved-payment-methods" class="payment-methods-container">';

    if ($saved_methods) {
      echo '<p class="payment-methods-title">' . esc_html(__('Select a saved card:', 'blackstone-online-gateway')) . '</p>';
      echo '<ul class="wc-saved-payment-methods">';

      foreach ($saved_methods as $token) {
        /** @var WC_Payment_Token_CC $token */
        $last4 = $token->get_last4();
        $token_id = $token->get_id();

        echo '<li class="payment-option">';
        echo '<input type="radio" id="token-' . esc_attr($token_id) . '" name="wc-saved-payment-token" value="' . esc_attr($token_id) . '" />';
        echo '<label for="token-' . esc_attr($token_id) . '" class="payment-label">';
        echo '<span class="card-icon">💳</span> ';
        echo esc_html(__('Card ending in:', 'blackstone-online-gateway')) . ' ' . esc_html($last4);
        echo '</label>';
        echo '</li>';
      }

      echo '</ul>';
    } else {
      echo '<p class="no-saved-methods">' . esc_html__('You do not have saved payment methods', 'blackstone-online-gateway') . '</p>';
    }

    echo '<ul class="wc-saved-payment-methods">';
    echo '<li class="payment-option">';
    echo '<input type="radio" id="token-new" name="wc-saved-payment-token" value="new" checked />';
    echo '<label for="token-new" class="payment-label">';
    echo '<span class="card-icon"></span> ' . esc_html__('Use a new payment method', 'blackstone-online-gateway');
    echo '</label>';
    echo '</li>';
    echo '</ul>';
    echo '</div>';
    echo '<div id="new-payment-method" class="new-payment-method-section">';
    echo '<p class="new-payment-title">' . esc_html__('Enter your card details:', 'blackstone-online-gateway') . '</p>';
    $this->form();
    echo '</div>';

?>

    <?php
  }

  public function otherAmount($total)
  {
    $surcharge_data = $this->get_cached_surcharge_data();
    $surcharge_merchant = $surcharge_data['response_SurchargePercent'];
    $surcharge_enabled = $surcharge_data['response_SurchargeEnabled'];
    $card_difference_percent = $surcharge_data['response_CardDifferencePercent'];
    $card_difference_enabled = $surcharge_data['response_CardDifferenceEnabled'];

    global $wp;
    $order_total = 0; // Initialize order_total
    $is_pay_for_order = isset($wp->query_vars['order-pay']);

    if ($is_pay_for_order) {
      $order_id = absint($wp->query_vars['order-pay']);
      $order = wc_get_order($order_id);

      $cart_total = $order->get_subtotal();
      $shipping_total = $order->get_shipping_total();
      $discount_total = $order->get_discount_total();

      $order_total = $cart_total + $shipping_total - $discount_total;
    } elseif (is_admin()) {
      $order = null;
      $order_id = 0;

      if (isset($_GET['post']) && get_post_type(absint(wp_unslash($_GET['post']))) === 'shop_order') {
        // Verify nonce for 'edit-post' action, common for editing posts/orders in admin
        if (check_admin_referer('edit-post', '_wpnonce')) {
          $order_id = absint(wp_unslash($_GET['post']));
        }
      }

      if (isset($_GET['page'], $_GET['id']) && sanitize_text_field(wp_unslash($_GET['page'])) === 'wc-orders') {
        // Verify nonce for 'woocommerce-manage-orders' action, common for new WC admin orders
        if (check_admin_referer('woocommerce-manage-orders', '_wpnonce')) {
          $order_id = absint(wp_unslash($_GET['id']));
        }
      }

      if ($order_id) {
        $order = wc_get_order($order_id);
      }

      if ($order) {
        $cart_total = $order->get_subtotal();
        $shipping_total = $order->get_shipping_total();
        $discount_total = $order->get_discount_total();
        $order_total = $cart_total + $shipping_total - $discount_total;
      } else {
        // Fallback for admin if order not found or not in order context
        $order_total = $total;
      }
    } else {
      $cart_total = WC()->cart->get_subtotal();
      $shipping_total = WC()->cart->get_shipping_total();
      $discount_total = WC()->cart->get_discount_total();

      $order_total = $cart_total + $shipping_total - $discount_total;
    }

    $total_surcharge = 0;
    $total_card_difference = 0;

    if ($surcharge_enabled) {
      $total_surcharge = number_format(($order_total * $surcharge_merchant / 100), 2);
    }
    if ($card_difference_enabled) {
      $total_card_difference = number_format(($order_total * $card_difference_percent / 100), 2);
    }
    if ($this->enabled == 'yes') {
      return (object)[
        'total_surcharge' => $total_surcharge,
        'total_card_difference' => $total_card_difference,
        'total' => number_format($order_total, 2),
      ];
    }

    return (object)[
      'total_surcharge' => 0,
      'total_card_difference' => 0,
      'total' => number_format($total, 2),
    ];
  }

  public function get_cached_surcharge_data()
  {
    if ($this->enabled !== 'yes') {
      return array(
        'response_SurchargeEnabled' => false,
        'response_SurchargePercent' => 0,
        'response_CardDifferenceEnabled' => false,
        'response_CardDifferencePercent' => 0,
        'response_ThreeDSecureEnabled' => false
      );
    }
    $surcharge_cache_key = 'bmspay_surcharge_data_' . get_current_user_id();
    $surcharge_data = get_transient($surcharge_cache_key);
    delete_transient($surcharge_cache_key);

    if ($surcharge_data === false) {
      $surcharge_data = $this->get_merchant_setting();
      delete_transient($surcharge_cache_key);
      set_transient($surcharge_cache_key, $surcharge_data, MINUTE_IN_SECONDS);
    }
    return $surcharge_data;
  }
  public function get_merchant_setting()
  {
    $data = $this->prepare_credential_data(true);

    $environment_url = $this->get_basic_url('BusinessSettings', false);

    $response = wp_remote_post($environment_url, array(
      'method' => 'POST',
      'body' => http_build_query($data),
      'timeout' => 45,
      'headers' => array(),
    ));

    $surcharge_percent = 0;
    $surcharge_enabled = 0;
    $card_difference_percent = 0;
    $card_difference_enabled = 0;
    $threed_secure_enabled = 0;
    //$threed_secure_enabled = true; // Eliminar

    if (is_wp_error($response)) {
      wc_add_notice(__('Merchant setting error:', 'blackstone-online-gateway') . ' ' . $response->get_error_message(), 'error');
      return;
    } else {
      $response_body = wp_remote_retrieve_body($response);
      $response_data = json_decode($response_body, true);


      if (isset($response_data['SurchargeEnabled']) && $response_data['SurchargeEnabled'] === true) {
        $surcharge_percent = $response_data['SurchargePercent'];
        $surcharge_enabled = true;
      }
      if (isset($response_data['CardDifferenceEnabled']) && $response_data['CardDifferenceEnabled'] === true) {
        $card_difference_percent = $response_data['CardDifferencePercent'];
        $card_difference_enabled = true;
      }
      if (isset($response_data['ThreeDSecureEnabled']) && $response_data['ThreeDSecureEnabled'] === true) {
        $threed_secure_enabled = true;
      }
    }
    $array = array(
      'response_SurchargeEnabled' => $surcharge_enabled,
      'response_SurchargePercent' => $surcharge_percent,
      'response_CardDifferenceEnabled' => $card_difference_enabled,
      'response_CardDifferencePercent' => $card_difference_percent,
      'response_ThreeDSecureEnabled' => $threed_secure_enabled
    );
    return $array;
  }
  public function get_merchant_tokenthreeds()
  {
    $data = (array)$this->prepare_credential_data(true);

    $environment_url = $this->get_basic_url('Auth/TokenThreeDS', false);

    $response = wp_remote_post($environment_url, array(
      'method' => 'POST',
      'body' => http_build_query($data),
      'timeout' => 45,
      'headers' => array(),
    ));

    return $this->process_threeds_response($response);
  }

  private function prepare_credential_data($threeds = false)
  {
    $remote_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';

    if ($threeds && $this->environment_3ds == 'yes') {
      return array(
        "mid" => "98208",
        "UserName" =>  "617D46A6-3A1A-4A67-850A-89F7E4F48049",
        "Password" =>  "CYC-4, LLC",
        "AppType" =>  "11200",
        "AppKey" =>  "563C17A4-A4E3-4A6F-BBF6-FC8B8B8E7F9F",
        "cid" =>  "6310",
        "IpAddress" => $remote_ip,
        "Source" => "ApiClient",
        "UserTest" => "True"
      );
    }
    return array(
      "mid" => $this->environment == 'yes' ? "76074" : $this->api_mid,
      "UserName" => $this->environment == 'yes' ? "nicolas" : $this->api_username,
      "Password" => $this->environment == 'yes' ? "password1" : $this->api_password,
      "AppType" => $this->environment == 'yes' ? "1" : $this->app_type,
      "AppKey" => $this->environment == 'yes' ? "12345" : $this->app_key,
      "cid" => $this->environment == 'yes' ? "260" : $this->api_cid,
      "IpAddress" => $remote_ip,
      "Source" => "ApiClient",
      "UserTest" => $this->environment == 'yes' ? "True" : "False"
    );
  }

  private function get_basic_url($endpoint, $is_test = false)
  {
    $base_url = 'https://services.bmspay.com/';
    $path = $is_test ? 'testing/api/' : 'api/';
    return ($this->environment == 'yes') ? $base_url . $path . $endpoint : $base_url . 'api/' . $endpoint;
  }

  private function process_threeds_response($response)
  {
    if (is_wp_error($response)) {
      wc_add_notice(__('Token threeDS error:', 'blackstone-online-gateway') . ' ' . $response->get_error_message(), 'error');
      return array('response_ApiKey' => '', 'response_Token' => '');
    }

    $response_body = wp_remote_retrieve_body($response);
    $response_data = json_decode($response_body, true);
    WC()->session->__unset('bmspay_threed_secure_apikey');
    WC()->session->__unset('bmspay_threed_secure_token');
    WC()->session->set('bmspay_threed_secure_apikey', isset($response_data['ApiKey']) ? $response_data['ApiKey'] : '');
    WC()->session->set('bmspay_threed_secure_token', isset($response_data['Token']) ? $response_data['Token'] : '');

    return array(
      'response_ApiKey' => isset($response_data['ApiKey']) ? $response_data['ApiKey'] : '',
      'response_Token' => isset($response_data['Token']) ? $response_data['Token'] : '',
    );
  }
  function evaluarResultado3DS($data)
  {
    $status = $data['status'] ?? null;

    switch ($status) {
      case 'Y':
        return [
          'success' => true,
          'message' => 'Autenticación 3D Secure exitosa (Status: Y)',
        ];
      case 'A':
        return [
          'success' => true,
          'message' => 'Autenticación 3DS fue realizada por el emisor pero no fue friccional (Status: A)',
        ];
      case 'N':
        $reason = $data['transStatusReasonDetail'] ?? 'Transacción no autenticada';
        return [
          'success' => false,
          'message' => "Autenticación fallida (Status: N). Motivo: {$reason}",
        ];
      case 'C':
        $reason = $data['transStatusReasonDetail'] ?? 'Desafío requerido; Se necesita autenticación adicional';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: C). Motivo: {$reason}",
        ];
      case 'R':
        $reason = $data['transStatusReasonDetail'] ?? 'Autenticación / Verificación de cuenta rechazada; El emisor está rechazando la autenticación/verificación y solicita que no se intente la autorización.';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: R). Motivo: {$reason}",
        ];
      case 'U':
        $reason = $data['transStatusReasonDetail'] ?? 'Fallo técnico o no disponible';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: U). Motivo: {$reason}",
        ];
      case 'I':
        $reason = $data['transStatusReasonDetail'] ?? 'Fallo técnico o no disponible';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: U). Motivo: {$reason}",
        ];
      default:
        $message = (get_locale() === 'es_ES') ? 'No se pudo completar la verificación de su método de pago. Intente nuevamente o use otro método' : 'The verification of your payment method could not be completed. Please try again or use a different method.';
        if (WC()->session->get('bmspay_threed_secure_enabled')) {
          return [
            'success' => false,
            'message' => $message,
          ];
        } else {
          return [
            'success' => false,
            'message' => $message,
          ];
        }
    }
  }

  public function process_payment($order_id)
  {
    if (!isset($_POST['woocommerce-process-checkout-nonce']) || !wp_verify_nonce(sanitize_key(wp_unslash($_POST['woocommerce-process-checkout-nonce'])), 'woocommerce-process_checkout')) {
      wc_add_notice(__('Invalid nonce. Please try again.', 'blackstone-online-gateway'), 'error');
      return;
    }

    $SecureData = '';
    $SecureTransactionId = '';
    $surcharge_data = $this->get_cached_surcharge_data();
    $threeds_enabled = $surcharge_data['response_ThreeDSecureEnabled'];

    $is_new_card = !isset($_POST['wc-saved-payment-token']) || sanitize_text_field(wp_unslash($_POST['wc-saved-payment-token'])) === 'new';

    if (isset($_POST['threeds_response']) && $threeds_enabled && $is_new_card) {
      try {
        $raw_threeds_response = isset($_POST['threeds_response']) ? sanitize_text_field(wp_unslash($_POST['threeds_response'])) : '';
        $sanitized_json = sanitize_textarea_field($raw_threeds_response); // mejor que sanitize_text_field para JSON
        $threedsData = json_decode($sanitized_json, true);

        if (json_last_error() !== JSON_ERROR_NONE || ! is_array($threedsData)) {
          throw new Exception(__('Invalid 3DS response data.', 'blackstone-online-gateway'));
        }

        $resultado = $this->evaluarResultado3DS($threedsData);
      } catch (Exception $e) {
        wc_add_notice(
          __('Authentication could not be completed: ', 'blackstone-online-gateway') . esc_html($e->getMessage()),
          'error'
        );
        return; // Changed wp_die() to return to allow WC to handle errors
      }

      if (! empty($resultado['success'])) {
        $SecureData = sanitize_text_field($threedsData['authenticationValue'] ?? '');
        $SecureTransactionId = sanitize_text_field($threedsData['threeDsTransactionId'] ?? '');
      } else {
        wc_add_notice(esc_html($resultado['message']), 'error');
        return;
      }
    }

    global $woocommerce;
    $Source = "BPaydPlugin";
    $remote_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';

    $credentials = $this->prepare_credential_data(true);
    $is_test = $credentials['UserTest'];
    $customer_order = new WC_Order($order_id);

    if (isset($_POST['wc-saved-payment-token']) && sanitize_text_field(wp_unslash($_POST['wc-saved-payment-token'])) !== 'new') {

      $token_id = sanitize_text_field(wp_unslash($_POST['wc-saved-payment-token']));
      $token = WC_Payment_Tokens::get($token_id);

      if ($token && $token->get_user_id() === get_current_user_id()) {

        /** @var WC_Payment_Token_CC $token */
        $last4 = $token->get_last4();
        $expiry_month = $token->get_expiry_month();
        $expiry_year = $token->get_expiry_year();
        $token_string = $token->get_token();

        $environment_url = $this->get_basic_url('Transactions/SaleWithToken', false);

        $full_name = ($customer_order->get_billing_first_name() . ' ' . $customer_order->get_billing_last_name());

        $otherAmount = $this->otherAmount($customer_order->get_total());

        $userTransactionNumber = (md5(uniqid($customer_order->get_order_number(), true)));

        $payload = array(
          "Token"                 => $token_string,
          "UserName"              => $credentials['UserName'],
          "Password"              => $credentials['Password'],
          "mid"                   => $credentials['mid'],
          "cid"                   => $credentials['cid'],
          "AppKey"                => $credentials['AppKey'],
          "AppType"               => $credentials['AppType'],
          "Amount"                => $otherAmount->total,
          "TaxAmount"             => 0,
          "TipAmount"             => 0,
          "SurchargeAmount"       => $otherAmount->total_surcharge,
          "CardDifferenceAmount"  => $otherAmount->total_card_difference,
          "TransactionType"       => 2,
          "Track2"                => "",
          "ZipCode"               => $customer_order->get_billing_postcode(),
          "ExpDate"               => ($expiry_month . substr($expiry_year, 2, 2)),
          "NameOnCard"            => $full_name,
          "UserTransactionNumber" => $userTransactionNumber,
          "Source"                => $Source,
          "SecureData"           => $SecureData,
          "PosCode"              => "Moto",
          "SecureTransactionId"  => $SecureTransactionId,

          "x_first_name"          => $customer_order->get_billing_first_name(),
          "x_last_name"           => $customer_order->get_billing_last_name(),
          "x_address"             => $customer_order->get_billing_address_1(),
          "x_city"                => $customer_order->get_billing_city(),
          "x_state"               => $customer_order->get_billing_state(),
          "x_zip"                 => $customer_order->get_billing_postcode(),
          "x_country"             => $customer_order->get_billing_country(),
          "x_phone"               => $customer_order->get_billing_phone(),
          "x_email"               => $customer_order->get_billing_email(),

          // Customer fields
          "SaveCustomer"           => 'True',
          "IsTest"                 => $is_test,
          "CustomerId"             => $order_id,
          "CustomerPhone"          => $customer_order->get_billing_phone(),
          "CustomerEmail"          => $customer_order->get_billing_email(),
          "CustomerCountry"        => $customer_order->get_billing_country(),
          "CustomerState"          => $customer_order->get_billing_state(),
          "CustomerCity"           => $customer_order->get_billing_city(),
          "CustomerAddress"        => $customer_order->get_billing_address_1(),
          "OrderReference"         => $order_id,

          "x_ship_to_first_name"   => $customer_order->get_shipping_first_name(),
          "x_ship_to_last_name"    => $customer_order->get_shipping_last_name(),
          "x_ship_to_company"      => $customer_order->get_shipping_company(),
          "x_ship_to_address"      => $customer_order->get_shipping_address_1(),
          "x_ship_to_city"         => $customer_order->get_shipping_city(),
          "x_ship_to_country"      => $customer_order->get_shipping_country(),
          "x_ship_to_state"        => $customer_order->get_shipping_state(),
          "x_ship_to_zip"          => $customer_order->get_shipping_postcode(),
          "x_cust_id"              => $customer_order->get_user_id(),
          "x_customer_ip"          => $remote_ip,
        );

        $response = wp_remote_post($environment_url, array(
          'method'               => 'POST',
          'headers'              => array('Content-Type' => 'application/x-www-form-urlencoded'),
          'body'                 => http_build_query($payload),
          'timeout'              => 90,
          'sslverify'            => false,
        ));

        if (is_wp_error($response))
          throw new Exception(esc_html__('There is issue for connectin payment gateway. Sorry for the inconvenience.', 'blackstone-online-gateway'));
        if (empty($response['body']))
          throw new Exception(esc_html__('Blackstone\'s Response was not get any data.', 'blackstone-online-gateway'));

        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        if (isset($response_data['ResponseCode']) && $response_data['ResponseCode'] == "200") {

          $customer_order->add_order_note(__('Blackstone complete payment.', 'blackstone-online-gateway'));

          if (isset($response_data['ServiceReferenceNumber'])) {
            $ServiceReferenceNumber = $response_data['ServiceReferenceNumber'];
            $customer_order->update_meta_data('_bmspay_service_reference_number', $ServiceReferenceNumber);
            $customer_order->add_order_note(__('Transaction ID: ', 'blackstone-online-gateway') . $ServiceReferenceNumber);
          }
          if (isset($payload['UserTransactionNumber'])) {
            $UserTransactionNumber = $payload['UserTransactionNumber'];
            $customer_order->update_meta_data('_bmspay_transaction_number', $UserTransactionNumber);
            $customer_order->add_order_note(__('User Transaction Number: ', 'blackstone-online-gateway') . $UserTransactionNumber);
          }
          $customer_order->payment_complete();
          $woocommerce->cart->empty_cart();

          $customer_order->save();

          return array(
            'result'   => 'success',
            'redirect' => $this->get_return_url($customer_order),
          );
        } else {
          $msg = $this->get_message_error($response_data);
          wc_add_notice($msg, 'error');
          $msg = $this->get_message_error_full($response_data, $userTransactionNumber);
          $customer_order->add_order_note('Error: ' . $msg);
        }
      } else {
        wc_add_notice(__('Invalid payment method selected.', 'blackstone-online-gateway'), 'error');
        return;
      }
    } else {
      $environment_url = $this->get_basic_url('Transactions/Sale', false);

      $full_name = ($customer_order->get_billing_first_name() . ' ' . $customer_order->get_billing_last_name());

      $otherAmount = $this->otherAmount($customer_order->get_total());

      $userTransactionNumber = (md5(uniqid($customer_order->get_order_number(), true)));

      $payload = array(
        "UserName"              => $credentials['UserName'],
        "Password"              => $credentials['Password'],
        "mid"                   => $credentials['mid'],
        "cid"                   => $credentials['cid'],
        "AppKey"                => $credentials['AppKey'],
        "AppType"               => $credentials['AppType'],
        "Amount"                => $otherAmount->total,
        "TaxAmount"             => 0,
        "TipAmount"             => 0,
        "SurchargeAmount"       => $otherAmount->total_surcharge,
        "CardDifferenceAmount"  => $otherAmount->total_card_difference,
        "TransactionType"       => 1,
        "Track2"                => "",
        "ZipCode"               => $this->environment == 'yes' ? "12345" : $customer_order->get_billing_postcode(),
        "ExpDate"               => isset($_POST['bmspay_blackstone_payment-card-expiry']) ? str_replace(array('/', ' '), '',  sanitize_text_field(wp_unslash($_POST['bmspay_blackstone_payment-card-expiry']))) : '',
        "CardNumber"            => isset($_POST['bmspay_blackstone_payment-card-number']) ? str_replace(array(' ', '-'), '',  sanitize_text_field(wp_unslash($_POST['bmspay_blackstone_payment-card-number']))) : '',
        "CVN"                   => isset($_POST['bmspay_blackstone_payment-card-cvc']) ? sanitize_text_field(wp_unslash($_POST['bmspay_blackstone_payment-card-cvc'])) : '',
        "NameOnCard"            => $full_name,

        "UserTransactionNumber" => $userTransactionNumber,
        "Source"                => $Source,
        "SecureData"            => $SecureData,
        "PosCode"               => "Moto",
        "SecureTransactionId"   => $SecureTransactionId,
        "SaveToken"             => "True",

        "x_first_name"          => $customer_order->get_billing_first_name(),
        "x_last_name"           => $customer_order->get_billing_last_name(),
        "x_address"             => $customer_order->get_billing_address_1(),
        "x_city"                => $customer_order->get_billing_city(),
        "x_state"               => $customer_order->get_billing_state(),
        "x_zip"                 => $customer_order->get_billing_postcode(),
        "x_country"             => $customer_order->get_billing_country(),
        "x_phone"               => $customer_order->get_billing_phone(),
        "x_email"               => $customer_order->get_billing_email(),

        // Customer fields
        "SaveCustomer"           => 'True',
        "IsTest"                 => $is_test,
        "CustomerId"             => $order_id,
        "CustomerPhone"          => $customer_order->get_billing_phone(),
        "CustomerEmail"          => $customer_order->get_billing_email(),
        "CustomerCountry"        => $customer_order->get_billing_country(),
        "CustomerState"          => $customer_order->get_billing_state(),
        "CustomerCity"           => $customer_order->get_billing_city(),
        "CustomerAddress"        => $customer_order->get_billing_address_1(),
        "OrderReference"         => $order_id,

        "x_ship_to_first_name"  => $customer_order->get_shipping_first_name(),
        "x_ship_to_last_name"   => $customer_order->get_shipping_last_name(),
        "x_ship_to_company"     => $customer_order->get_shipping_company(),
        "x_ship_to_address"     => $customer_order->get_shipping_address_1(),
        "x_ship_to_city"        => $customer_order->get_shipping_city(),
        "x_ship_to_country"     => $customer_order->get_shipping_country(),
        "x_ship_to_state"       => $customer_order->get_shipping_state(),
        "x_ship_to_zip"         => $customer_order->get_shipping_postcode(),
        "x_cust_id"             => $customer_order->get_user_id(),
        "x_customer_ip"         => $remote_ip,
      );

      $response = wp_remote_post($environment_url, array(
        'method'               => 'POST',
        'headers'              => array('Content-Type' => 'application/x-www-form-urlencoded'),
        'body'                 => http_build_query($payload),
        'timeout'              => 90,
        'sslverify'            => false,
      ));

      if (is_wp_error($response))
        throw new Exception(esc_html__('There is issue for connectin payment gateway. Sorry for the inconvenience.', 'blackstone-online-gateway'));
      if (empty($response['body']))
        throw new Exception(esc_html__('Blackstone\'s Response was not get any data.', 'blackstone-online-gateway'));

      $response_body = wp_remote_retrieve_body($response);
      $resp = json_decode($response_body, true);

      if (isset($resp['ResponseCode']) && $resp['ResponseCode'] == "200") {

        $customer_order->add_order_note(__('Blackstone complete payment.', 'blackstone-online-gateway'));

        if (isset($resp['ServiceReferenceNumber'])) {
          $ServiceReferenceNumber = $resp['ServiceReferenceNumber'];
          $customer_order->update_meta_data('_bmspay_service_reference_number', $ServiceReferenceNumber);
          $customer_order->add_order_note(__('Transaction ID: ', 'blackstone-online-gateway') . $ServiceReferenceNumber);
        }
        if (isset($payload['UserTransactionNumber'])) {
          $UserTransactionNumber = $payload['UserTransactionNumber'];
          $customer_order->update_meta_data('_bmspay_transaction_number',  $UserTransactionNumber);
          $customer_order->add_order_note(__('User Transaction Number: ', 'blackstone-online-gateway') . $UserTransactionNumber);
        }
        $customer_order->payment_complete();
        $woocommerce->cart->empty_cart();

        $customer_order->save();


        if (isset($resp['Token'])) {

          $user_id = $customer_order->get_user_id();

          $last4 = sanitize_text_field($resp['LastFour']);
          $card_type = sanitize_text_field($resp['CardType']);
          $expiry_month = substr(sanitize_text_field($payload['ExpDate']), 0, 2);
          $expiry_year = "20" . substr(sanitize_text_field($payload['ExpDate']), 2, 2);

          $existing_tokens = WC_Payment_Tokens::get_tokens(['user_id' => $user_id, 'type' => 'CC']);

          $card_exists = false;

          foreach ($existing_tokens as $existing_token) {
            /** @var WC_Payment_Token_CC $existing_token */
            if (
              $existing_token->get_last4() === $last4 &&
              $existing_token->get_expiry_month() === $expiry_month &&
              $existing_token->get_expiry_year() === $expiry_year &&
              $existing_token->get_card_type() === $card_type
            ) {
              $card_exists = true;
              break;
            }
          }
          if (isset($_POST['save_card']) && sanitize_text_field(wp_unslash($_POST['save_card'])) == '1') {
            if (!$card_exists) {
              $token = new WC_Payment_Token_CC();
              $token->set_token($resp['Token']);
              $token->set_gateway_id($this->id);
              $token->set_user_id($user_id);
              $token->set_last4($last4);
              $token->set_card_type($card_type);
              $token->set_expiry_month($expiry_month);
              $token->set_expiry_year($expiry_year);

              $token->save();
            }
          }
        }

        return array(
          'result'   => 'success',
          'redirect' => $this->get_return_url($customer_order),
        );
      } else {
        $msg = $this->get_message_error($resp);
        wc_add_notice($msg, 'error');
        $msg = $this->get_message_error_full($resp, $userTransactionNumber);
        $customer_order->add_order_note('Error: ' . $msg);
      }
    }
  }

  public function get_message_error($response_data)
  {
    $msg = $response_data['Msg'][0] ?? __('No message provided', 'blackstone-online-gateway');
    $verbiage = $response_data['verbiage'] ?? __('No verbiage provided', 'blackstone-online-gateway');
    $avs = $response_data['avs'] ?? __('No AVS response', 'blackstone-online-gateway');
    $cv = $response_data['cv'] ?? __('No CV response', 'blackstone-online-gateway');
    return "$msg . More details: $verbiage.";
  }
  public function get_message_error_full($response_data, $userTransactionNumber)
  {
    $msg = $response_data['Msg'][0] ?? __('No message provided', 'blackstone-online-gateway');
    $verbiage = $response_data['verbiage'] ?? __('No verbiage provided', 'blackstone-online-gateway');
    $avs = $response_data['avs'] ?? __('No AVS response', 'blackstone-online-gateway');
    $cv = $response_data['cv'] ?? __('No CV response', 'blackstone-online-gateway');
    return "$msg . More details: $verbiage. Extra validation: Zip ($avs), CVV ($cv), UserTransactionNumber: $userTransactionNumber";
  }

  public function validate_fields()
  {
    return true;
  }
  public function do_ssl_check()
  {
    if ($this->enabled == "yes") {
      if (get_option('woocommerce_force_ssl_checkout') == "no") {
        // echo "<div class=\"error\"><p>" . sprintf(__("<strong>%s</strong> is enabled and WooCommerce is not forcing the SSL certificate on your checkout page. Please ensure that you have a valid SSL certificate and that you are <a href=\"%s\">forcing the checkout pages to be secured.</a>"), $this->method_title, admin_url('admin.php?page=wc-settings&tab=checkout')) . "</p></div>";
      }
    }
  }
  public function getEnvironment()
  {
    return $this->environment;
  }
  public function getEnvironment3DS()
  {
    return $this->environment_3ds;
  }
  public function isPluginActive()
  {
    return $this->enabled;
  }
  public function getLabelSurcharge()
  {
    return $this->label_surcharge;
  }
  public function getLabelCardDifference()
  {
    return $this->label_card_difference;
  }
}

function bmspay_add_payment_gateway($gateways)
{
  $gateways[] = 'bmspay_Blackstone_Payment';
  return $gateways;
}

add_filter('woocommerce_payment_gateways', 'bmspay_add_payment_gateway');

function bmspay_calculate_and_set_fees()
{
  if (!bmspay_get_state_plugin()) return;
  $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();
  $cart_total = 0;
  if (WC()->cart->get_cart_contents_count() > 0) {
    $cart_total = WC()->cart->get_subtotal() + WC()->cart->get_shipping_total() - WC()->cart->get_discount_total();
  } else {
    $cart_total = WC()->session->get('bmspay_blackstone_cart_subtotal');
    if ($cart_total === null || $cart_total === false) {
      $cart_total = 0;
    }
  }
  $should_apply_fees = bmspay_get_state_plugin();
  $surcharge_data = $bmspay_Blackstone_Payment->get_cached_surcharge_data();
  $surcharge_merchant = $surcharge_data['response_SurchargePercent'];
  $surcharge_enabled = $surcharge_data['response_SurchargeEnabled'];
  $card_difference_percent = $surcharge_data['response_CardDifferencePercent'];
  $card_difference_enabled = $surcharge_data['response_CardDifferenceEnabled'];
  $threed_secure_enabled = $surcharge_data['response_ThreeDSecureEnabled'];
  WC()->session->set('bmspay_threed_secure_enabled', $threed_secure_enabled);


  $payment_method = '';
  if (isset($_POST['payment_method']) && isset($_POST['security']) && wp_verify_nonce(sanitize_key(wp_unslash($_POST['security'])), 'update-order-review')) {
    $payment_method = sanitize_text_field(wp_unslash($_POST['payment_method']));

    if ($payment_method === 'bmspay_blackstone_payment') {
      if ($surcharge_enabled) {
        $surcharge = number_format(($cart_total * $surcharge_merchant / 100), 2);
        WC()->session->set('bmspay_surcharge_amount', $surcharge);
        WC()->session->set('bmspay_surcharge_percent', $surcharge_merchant);
      } else {
        WC()->session->__unset('bmspay_surcharge_amount');
      }

      if ($card_difference_enabled) {
        $card_difference =  number_format(($cart_total * $card_difference_percent / 100), 2);
        WC()->session->set('bmspay_card_difference_amount', $card_difference);
        WC()->session->set('bmspay_card_difference_percent', $card_difference_percent);
      } else {
        WC()->session->__unset('bmspay_card_difference_amount');
      }
    } else {
      WC()->session->__unset('bmspay_surcharge_amount');
      WC()->session->__unset('bmspay_card_difference_amount');
    }
  }
}

add_action('woocommerce_review_order_before_order_total', function () {

  if (!bmspay_get_state_plugin()) return;

  bmspay_calculate_and_set_fees();

  $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();
  $payment_method = '';
  if (isset($_POST['payment_method']) && isset($_POST['security']) && wp_verify_nonce(sanitize_key(wp_unslash($_POST['security'])), 'update-order-review')) {
    $payment_method = sanitize_text_field(wp_unslash($_POST['payment_method']));
  }

  if ($payment_method === 'bmspay_blackstone_payment') {
    $surcharge = WC()->session->get('bmspay_surcharge_amount');
    $surcharge_percent = WC()->session->get('bmspay_surcharge_percent');


    if ($surcharge) {
      echo '<tr class="order-total">
      <th>' . sprintf('%s (%s%%)', esc_html($bmspay_Blackstone_Payment->getLabelSurcharge()), number_format($surcharge_percent, 2)) . '</th>
      <td>' . wp_kses_post(wc_price($surcharge)) . '</td>
      </tr>';
    }

    $card_difference = WC()->session->get('bmspay_card_difference_amount');
    $card_difference_percent = WC()->session->get('bmspay_card_difference_percent');
    if ($card_difference) {
      echo '<tr class="order-total">
      <th>' . sprintf('%1$s (%2$s%%)', esc_html($bmspay_Blackstone_Payment->getLabelCardDifference()), number_format($card_difference_percent, 2)) . '</th>
      <td>' . wp_kses_post(wc_price($card_difference)) . '</td>
      </tr>';
    }
  }
});
add_action('template_redirect', function () {
  if (!bmspay_get_state_plugin()) return;
  if (is_wc_endpoint_url('order-pay') && isset($_GET['key'])) {
    if (isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_key(wp_unslash($_GET['_wpnonce'])), 'order-pay')) {
      // nonce verified
    }
    $key = sanitize_text_field(wp_unslash($_GET['key']));
    $order_id = wc_get_order_id_by_order_key($key);
    $order = wc_get_order($order_id);

    if ($order) {
      $subtotal = $order->get_subtotal() + $order->get_shipping_total() - $order->get_discount_total();
      WC()->session->set('bmspay_blackstone_cart_subtotal', $subtotal);
    }
  }
});
add_filter('woocommerce_calculated_total', function ($total) {
  if (!bmspay_get_state_plugin()) return $total;
  $surcharge = WC()->session->get('bmspay_surcharge_amount');
  $card_difference = WC()->session->get('bmspay_card_difference_amount');
  if (isset($_POST['payment_method'])) {
    if (!isset($_POST['security']) || !wp_verify_nonce(sanitize_key(wp_unslash($_POST['security'])), 'update-order-review')) {
      // Optional for filters usually, but complying with standard
    }
    $payment_method = sanitize_text_field(wp_unslash($_POST['payment_method']));
    if ($payment_method === 'bmspay_blackstone_payment') {
      if ($surcharge) {
        $total += $surcharge;
      }
      if ($card_difference) {
        $total += $card_difference;
      }
    }
  }
  return $total;
});
function bmspay_get_state_plugin()
{
  static $should_apply_fees = null;

  if ($should_apply_fees === null) {
    $payment_gateways = WC()->payment_gateways->get_available_payment_gateways();
    $gateway_id = 'bmspay_blackstone_payment';

    $should_apply_fees = isset($payment_gateways[$gateway_id])
      && ($payment_gateways[$gateway_id]->enabled === 'yes');
  }

  return $should_apply_fees;
}
add_filter('woocommerce_get_order_item_totals', function ($totals, $order, $tax_display) {
  if (!bmspay_get_state_plugin() || !WC()->session) return $totals;
  if (WC()->session) {
    $surcharge = WC()->session->get('bmspay_surcharge_amount');
    $card_difference = WC()->session->get('bmspay_card_difference_amount');
    $surcharge_percent = WC()->session->get('bmspay_surcharge_percent');
    $card_difference_percent = WC()->session->get('bmspay_card_difference_percent');

    if (($surcharge || $card_difference) && bmspay_get_state_plugin()) {
      $new_totals = [];
      $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();

      foreach ($totals as $key => $total) {
        if ($key === 'order_total') {
          if ($surcharge) {
            $new_totals['surcharge'] = [
              'label' => $bmspay_Blackstone_Payment->getLabelSurcharge() . ' (' . number_format($surcharge_percent, 2) . '%)',
              'value' => wp_kses_post(wc_price($surcharge)),
            ];
          }
          if ($card_difference) {
            $new_totals['card_difference'] = [
              'label' => $bmspay_Blackstone_Payment->getLabelCardDifference() . ' (' . number_format($card_difference_percent, 2) . '%)',
              'value' => wp_kses_post(wc_price($card_difference)),
            ];
          }
        }
        $new_totals[$key] = $total;
      }

      return $new_totals;
    }
  }

  return $totals;
}, 10, 3);

add_action('woocommerce_checkout_update_order_meta', function ($order_id) {
  if (!bmspay_get_state_plugin() || !WC()->session) return;
  if (WC()->session && bmspay_get_state_plugin()) {
    $surcharge = WC()->session->get('bmspay_surcharge_amount');
    $card_difference = WC()->session->get('bmspay_card_difference_amount');
    $surcharge_percent = WC()->session->get('bmspay_surcharge_percent');
    $card_difference_percent = WC()->session->get('bmspay_card_difference_percent');

    if ($surcharge) {
      update_post_meta($order_id, '_bmspay_surcharge_amount', $surcharge);
      update_post_meta($order_id, '_bmspay_surcharge_percent', $surcharge_percent);
    }
    if ($card_difference) {
      update_post_meta($order_id, '_bmspay_card_difference_amount', $card_difference);
      update_post_meta($order_id, '_bmspay_card_difference_percent', $card_difference_percent);
    }
  }
});

function bmspay_recalculate_order_total_with_fees($order_id)
{
  $order = wc_get_order($order_id);

  // Obtener porcentajes guardados
  $surcharge_percent = floatval(get_post_meta($order_id, '_bmspay_surcharge_percent', true));
  $card_difference_percent = floatval(get_post_meta($order_id, '_bmspay_card_difference_percent', true));

  // Calcular subtotal base (productos + envío - descuentos)
  $subtotal = $order->get_subtotal() + $order->get_shipping_total() - $order->get_discount_total();

  // Calcular cargos
  $surcharge_amount = ($surcharge_percent > 0) ? ($subtotal * $surcharge_percent / 100) : 0;
  $card_difference_amount = ($card_difference_percent > 0) ? ($subtotal * $card_difference_percent / 100) : 0;

  // Calcular nuevo total
  $new_total = $subtotal + $surcharge_amount + $card_difference_amount;

  // Actualizar el total directamente
  $order->set_total($new_total);

  // Guardar los montos actualizados en metadatos
  update_post_meta($order_id, '_bmspay_surcharge_amount', $surcharge_amount);
  update_post_meta($order_id, '_bmspay_card_difference_amount', $card_difference_amount);

  $order->save();
}
add_action('woocommerce_order_status_processing_to_pending', 'bmspay_handle_order_status_change_to_pending', 10, 1);

function bmspay_handle_order_status_change_to_pending($order_id)
{
  if (!bmspay_get_state_plugin()) return;
  // Verificar que es nuestro método de pago
  $order = wc_get_order($order_id);
  if ($order->get_payment_method() === 'bmspay_blackstone_payment') {
    bmspay_recalculate_order_total_with_fees($order_id);
  }
}
add_action('woocommerce_order_after_calculate_totals', 'bmspay_custom_adjust_order_totals_with_meta', 10, 2);

function bmspay_custom_adjust_order_totals_with_meta($and_taxes, $order)
{
  if (!bmspay_get_state_plugin()) return;
  // Solo aplicarlo si es nuestro método de pago
  // Primero verifica si NO es un pedido válido o SI es un reembolso
  if (!($order instanceof WC_Order) || $order instanceof WC_Order_Refund) {
    return;
  }
  // Luego verifica el método de pago (sabemos que $order es WC_Order)
  if ($order->get_payment_method() !== 'bmspay_blackstone_payment') {
    return;
  }

  // Obtener porcentajes guardados
  $order_id = $order->get_id();
  $surcharge_percent = floatval(get_post_meta($order_id, '_bmspay_surcharge_percent', true));
  $card_difference_percent = floatval(get_post_meta($order_id, '_bmspay_card_difference_percent', true));

  // Calcular subtotal base (productos + envío - descuentos)
  $subtotal = $order->get_subtotal() + $order->get_shipping_total() - $order->get_discount_total();

  // Calcular cargos
  $surcharge_amount = ($surcharge_percent > 0) ? ($subtotal * $surcharge_percent / 100) : 0;
  $card_difference_amount = ($card_difference_percent > 0) ? ($subtotal * $card_difference_percent / 100) : 0;

  // Calcular nuevo total
  $new_total = $subtotal + $surcharge_amount + $card_difference_amount;

  // Actualizar el total del pedido
  $order->set_total($new_total);

  // Guardar montos en metadatos
  update_post_meta($order_id, '_bmspay_surcharge_amount', $surcharge_amount);
  update_post_meta($order_id, '_bmspay_card_difference_amount', $card_difference_amount);
}


add_action('woocommerce_admin_order_totals_after_tax', function ($order_id) {
  if (!bmspay_get_state_plugin()) return;
  $order = wc_get_order($order_id);
  $payment_method = $order->get_payment_method();
  $surcharge = get_post_meta($order_id, '_bmspay_surcharge_amount', true);
  $surcharge_percent = floatval(get_post_meta($order_id, '_bmspay_surcharge_percent', true)) ?? 0;

  $card_difference = get_post_meta($order_id, '_bmspay_card_difference_amount', true);
  $card_difference_percent = floatval(get_post_meta($order_id, '_bmspay_card_difference_percent', true)) ?? 0;

  if (($surcharge || $card_difference) && bmspay_get_state_plugin() && $payment_method === 'bmspay_blackstone_payment') {
    $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();
    if ($surcharge && floatval($surcharge) > 0) {
      $label_surcharge = $bmspay_Blackstone_Payment->getLabelSurcharge();
      if ($surcharge_percent > 0) {
        $label = sprintf('%1$s (%2$s%%)', esc_html($label_surcharge), number_format($surcharge_percent ?? 0, 2));
      } else {
        $label = esc_html($label_surcharge);
      }
    ?>
      <tr>
        <td class="label"><?php echo esc_html($label); ?>:</td>
        <td width="1%"></td>
        <td class="total"><?php echo wp_kses_post(wc_price($surcharge)); ?></td>
      </tr>
    <?php
    }
    if ($card_difference  && floatval($card_difference) > 0) {
      $label_card_difference = $bmspay_Blackstone_Payment->getLabelCardDifference();
      if ($card_difference_percent > 0) {
        $label = sprintf('%1$s (%2$s%%)', esc_html($label_card_difference), number_format($card_difference_percent, 2));
      } else {
        $label = esc_html($label_card_difference);
      }
    ?>
      <tr>
        <td class="label"><?php echo esc_html($label); ?>:</td>
        <td width="1%"></td>
        <td class="total"><?php echo wp_kses_post(wc_price($card_difference)); ?></td>
      </tr>
<?php }
  }
});
add_filter('woocommerce_account_menu_items', 'bmspay_add_payment_methods_to_my_account');

function bmspay_add_payment_methods_to_my_account($items)
{
  if (isset($items['payment-methods'])) {
    unset($items['payment-methods']);
  }
  $logout = $items['customer-logout'];
  unset($items['customer-logout']);
  $items['payment-methods'] = __('Payment methods', 'blackstone-online-gateway');
  $items['customer-logout'] = $logout;

  return $items;
}

add_action('woocommerce_review_order_before_submit', 'bmspay_add_save_card_option');
add_action('woocommerce_pay_order_before_submit', 'bmspay_add_save_card_option');

function bmspay_add_save_card_option()
{
  if (!bmspay_get_state_plugin()) return;
  // Verificar si es página de pago de pedido
  global $wp;
  $is_pay_for_order = isset($wp->query_vars['order-pay']);

  // Obtener el método de pago según el contexto
  $payment_method = '';

  if ($is_pay_for_order) {
    // Para página de pago de pedido
    if (isset($_POST['payment_method'])) {
      if (isset($_POST['_wpnonce']) && wp_verify_nonce(sanitize_key(wp_unslash($_POST['_wpnonce'])), 'woocommerce-process_checkout')) {
        // Nonce verified
      }
      $payment_method = sanitize_text_field(wp_unslash($_POST['payment_method']));
    } else {
      $order_id = absint($wp->query_vars['order-pay']);
      $order = wc_get_order($order_id);
      $payment_method = $order ? $order->get_payment_method() : '';
    }
  } else {
    // Para checkout normal
    if (isset($_POST['payment_method'])) {
      if (isset($_POST['security']) && wp_verify_nonce(sanitize_key(wp_unslash($_POST['security'])), 'update-order-review')) {
        // Nonce verified
      }
      $payment_method = sanitize_text_field(wp_unslash($_POST['payment_method']));
    } else {
      $payment_method = '';
    }
  }

  // Mostrar opción solo si el método de pago es el nuestro y el usuario está logueado
  if ($payment_method === 'bmspay_blackstone_payment' && is_user_logged_in()) {
    if (isset($_POST['woocommerce-process-checkout-nonce']) || isset($_POST['_wpnonce'])) {
      // En checkout suele haber nonce, pero esto es solo para mostrar el campo
    }
    echo '<p class="form-row woocommerce-SavedPaymentMethods-saveNew">';
    woocommerce_form_field('save_card', [
      'type'  => 'checkbox',
      'class' => ['form-row-wide'],
      'label' => __('Save card for future purchases', 'blackstone-online-gateway'),
    ]);
    echo '</p>';
  }
}

function bmspay_enqueue_threeds_script()
{
  if (!bmspay_get_state_plugin()) return;
  if (is_checkout() || bmspay_is_order_pay_page()) {
    wp_enqueue_script(
      'bmspay-threeds-script',
      'https://cdn.3dsintegrator.com/threeds.2.2.20231219.min.js',
      array(),
      '2.2.20231219',
      true
    );
  }
}
add_action('wp_enqueue_scripts', 'bmspay_enqueue_threeds_script');

add_action('wp_enqueue_scripts', 'bmspay_change_sweetalert2', 20);
add_action('admin_enqueue_scripts', 'bmspay_change_sweetalert2');
function bmspay_change_sweetalert2()
{
  if (!bmspay_get_state_plugin()) return;

  // Permitir en checkout solo si 3DS está habilitado
  if (is_checkout() || bmspay_is_order_pay_page()) {
    $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();
    $surcharge_data = $bmspay_Blackstone_Payment->get_cached_surcharge_data();
    $threeds_enabled = $surcharge_data['response_ThreeDSecureEnabled'];

    // Solo cargar si 3DS está activo
    if (!$threeds_enabled) {
      return;
    }
  }

  wp_enqueue_script(
    'bmspay-sweetalert2',
    plugins_url('assets/js/sweetalert2_11.js', __FILE__),
    array('jquery'),
    '11.26.18',
    true
  );
}


add_action('woocommerce_after_order_notes', 'bmspay_add_threeds_hidden_field');

function bmspay_add_threeds_hidden_field($checkout)
{
  if (!bmspay_get_state_plugin()) return;
  echo '<input type="hidden" name="threeds_response" id="threeds_response" value="">';
}
function bmspay_get_total_amount()
{
  global $wp;

  if (isset($wp->query_vars['order-pay'])) {
    $order_id = absint($wp->query_vars['order-pay']);
    $order = wc_get_order($order_id);
    return $order->get_total();
  }
  $cart = WC()->cart;

  $subtotal = $cart->get_subtotal();
  $discount_total = $cart->get_discount_total();
  $shipping_total = $cart->get_shipping_total();

  $total_tax = $cart->get_total_tax();
  $discount_tax   = $cart->get_discount_tax();

  $total_fees = 0;
  foreach ($cart->get_fees() as $fee) {
    $total_fees += $fee->amount;
  }

  $calculated_total = ($subtotal - $discount_total)
    + $shipping_total
    + ($total_tax - $discount_tax)
    + $total_fees;

  $calculated_total = wc_format_decimal($calculated_total, 2);

  return $calculated_total;
}
add_action('wp_ajax_bmspay_update_order_checkout_fees', 'bmspay_update_fees_based_on_payment_method');
add_action('wp_ajax_nopriv_bmspay_update_order_checkout_fees', 'bmspay_update_fees_based_on_payment_method');

function bmspay_update_fees_based_on_payment_method()
{
  check_ajax_referer('update-order-review', 'security');
  if (!bmspay_get_state_plugin()) {
    wp_send_json_error('Plugin no activo');
  }
  if (!isset($_POST['payment_method'])) {
    wp_send_json_error('Método de pago no recibido');
  }
  $cart = WC()->cart;

  bmspay_calculate_and_set_fees();

  $cart->calculate_totals();

  ob_start();
  woocommerce_order_review();
  $order_review = ob_get_clean();

  wp_send_json([
    'success' => true,
    'fragments' => apply_filters('bmspay_woocommerce_update_order_review_fragments', [
      '.woocommerce-checkout-review-order-table' => $order_review
    ])
  ]);
}

// TEMPORALMENTE DESHABILITADO PARA DEBUG

add_action('wp_enqueue_scripts', 'bmspay_enqueue_payment_method_script', 20);
function bmspay_enqueue_payment_method_script()
{
  if (!bmspay_get_state_plugin() || !is_checkout()) {
    return;
  }

  wp_register_script(
    'bmspay-payment-method-custom',
    plugins_url('/assets/js/payment-method-custom.js', __FILE__),
    ['jquery', 'jquery-blockui'],
    '4.5.53',
    true
  );

  wp_enqueue_script('bmspay-payment-method-custom');
}


function bmspay_is_order_pay_page()
{
  global $wp;
  return isset($wp->query_vars['order-pay']);
}

add_action('wp_ajax_bmspay_3ds_log', array('bmspay_Blackstone_Payment', 'bmspay_3ds_log'));
add_action('wp_ajax_nopriv_bmspay_3ds_log', array('bmspay_Blackstone_Payment', 'bmspay_3ds_log'));
