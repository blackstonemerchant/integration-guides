=== Blackstone Online Gateway ===
Contributors: carlosraul7
Donate link: https://blackstoneonline.com/
Tags: woocommerce, payment, gateway, blackstone, credit card
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 4.7.7
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Custom payment gateway integration for WooCommerce using Blackstone Merchant. Secure, fast and reliable payments for your online store.

== Description ==

**Blackstone Online Gateway** is a custom payment integration for WooCommerce that allows merchants to process credit card payments through the Blackstone Merchant platform. It provides a seamless checkout experience, secure communication with the API, and supports refund handling directly via WooCommerce.

### Main Features

* Full integration with WooCommerce checkout and order management.
* Secure API connection to Blackstone Merchant Services.
* Supports payment authorization, capture and refund.
* 3D Secure (3DS) authentication for fraud prevention.
* Saved payment tokens — customers can securely save and reuse credit cards.
* Surcharge and dual pricing (card difference) support with configurable labels.
* Full and partial refund processing via API with stock management.
* Test/sandbox mode for development and staging environments.
* Admin settings page for easy configuration of merchant credentials.
* Localization support with Spanish (es_ES) translation included.
* Compatible with the latest versions of WooCommerce and WordPress.

### How It Works

1. The customer selects Blackstone Merchant as the payment method at checkout.
2. They can enter a new credit card or choose a previously saved card.
3. If 3DS is enabled, the transaction is authenticated via 3D Secure.
4. The payment is processed securely through the Blackstone API.
5. The card can optionally be saved as a token for future purchases.

This plugin requires an active merchant account with [Blackstone Merchant](https://www.blackstonemerchant.com/).

== External Services ==

This plugin connects to external services to process payments and perform security verifications.

**BMS Pay API**
This service is used to process payments and refunds securely.
*   **Source**: `https://services.bmspay.com/`
*   **Data Sent**: Transaction details, card information (processed securely), and order amounts.
*   **Provider**: Blackstone Merchant Services.
*   **Terms & Privacy**: Please refer to [Blackstone Merchant](https://www.blackstonemerchant.com/) and [Documentation](https://documentation.bmspay.com/).

**3DS Integrator**
This service is used for 3D Secure (3DS) authentication to prevent fraud.
*   **Source**: `https://cdn.3dsintegrator.com/` (Script), `https://api.3dsintegrator.com/` (API).
*   **Data Sent**: Card identifiers and transaction context for risk analysis.
*   **Provider**: 3DS Integrator (via Blackstone).
*   **Terms & Privacy**: Usage is covered under your agreement with [Blackstone Merchant](https://www.blackstonemerchant.com/).

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install it directly from the WordPress Plugin Directory.
2. Activate the plugin through the *Plugins* menu in WordPress.
3. Go to **WooCommerce → Settings → Payments → Blackstone Merchant**.
4. Enable the gateway and enter your merchant credentials (Username, Password, MID, CID, AppKey, AppType).
5. Optionally enable 3D Secure and configure the 3DS API key and token.
6. Save changes and test the payment process using test mode.

== Frequently Asked Questions ==

= Do I need a Blackstone Merchant account? =
Yes. You must have an approved merchant account from [Blackstone Merchant](https://www.blackstonemerchant.com/) to process transactions.

= Does this plugin support refunds? =
Yes. Full and partial refunds can be processed directly from the WooCommerce order screen. The plugin sends refund requests securely to the Blackstone API and can optionally restock items.

= What is 3D Secure (3DS)? =
3D Secure is an additional authentication layer that helps prevent fraudulent transactions. When enabled, the cardholder may be asked to verify their identity during checkout. This plugin integrates with the 3DS Integrator service to handle this process.

= Can customers save their credit cards? =
Yes. Customers can choose to save their credit card as a payment token during checkout. Saved cards can be reused for future purchases without re-entering card details. No sensitive card data is stored on your server.

= Does it support test/sandbox mode? =
Yes. The plugin includes a test mode toggle in the settings page. This allows you to test transactions in a sandbox environment before going live. There is also a separate test mode toggle for 3DS authentication.

= Is it compatible with WooCommerce Subscriptions or Bookings? =
Currently, it supports standard one-time payments. Future versions may include support for recurring billing.

= Does it store credit card information? =
No. The plugin does **not** store or log any sensitive card data. All transactions are handled securely through the Blackstone Merchant gateway. Saved payment tokens are managed by WooCommerce's built-in token system.

= What is the surcharge/dual pricing feature? =
The plugin supports adding a surcharge or card difference amount to orders. This can be configured with custom labels in the admin settings and is displayed as a separate line item in the order.

== Screenshots ==

1. Payment gateway settings — General configuration screen under WooCommerce → Settings → Payments → Blackstone Merchant.
2. Payment gateway credentials — API credentials and 3DS configuration options.
3. Checkout page — The Blackstone Merchant payment option displayed to customers.

== Changelog ==

= 4.7.7 =
* Fixed Blackstone Refund buttons not appearing on the order edit screen under High-Performance Order Storage (HPOS). The detector relied on `get_post_type() === 'shop_order'`, which returns `'shop_order_placehold'` when HPOS is active without compatibility sync, so the refund JavaScript was never enqueued. The detector now accepts the placeholder type and falls back to `wc_get_order()` for storage-agnostic resolution, covering Legacy, HPOS+sync, and HPOS-only configurations.

= 4.7.6 =
* Fixed pay-for-order pages charging the original order amount instead of the current items total when the admin modified items without clicking "Recalculate" — the persisted order total is now refreshed automatically before rendering the customer pay page and again defensively before charging the API. An order note records every recalculation for auditing. Skipped on orders carrying surcharge/card-difference fee metadata to preserve the existing fee flow.

= 4.7.5 =
* Fixed 3DS verification not triggering on the pay-for-order page on sites with translated WooCommerce slugs — detection now uses the pay_for_order=true query parameter instead of the English-only order-pay URL slug.

= 4.7.4 =
* Added client-side UUID generation for clientTransactionId using crypto.randomUUID() with Math.random() fallback; each checkout attempt generates a unique identifier.
* Added automatic JWT refresh on 401 errors from the 3DS SDK — refreshes server-side token and retries verify() once with a new clientTransactionId.
* Added "Force 3DS (Sandbox only)" admin toggle to bypass the merchant API flag during sandbox testing; automatically selects sandbox endpoint when active.
* Added billing address, email, city, state, and ISO 3166-1 numeric country code to 3DS form data fields.
* Added ISO 4217 numeric currency code conversion with MXN support.
* Fixed 3DS challenge iframe sizing — scoped CSS injected in document.head prevents SDK from overriding iframe dimensions; modal width set to 460px, iframe fixed at 390x400.
* Fixed <style> tag accumulation across multiple failed 3DS attempts — cleanup now removes injected style nodes from the DOM.
* Fixed silent error callback — unknown 3DS errors now show a user-facing message instead of resetting the form with no feedback.
* Fixed 401 detection false positives — regex now matches word-boundary \b401\b instead of substring, preventing matches on amounts or error codes containing "401".
* Fixed force_3ds_sandbox endpoint selection — sandbox endpoint is now correctly used when the flag is active regardless of gateway environment setting.
* Added rate limiting to the 3DS token refresh AJAX endpoint (1 request per 60 seconds per session) to prevent API abuse.
* Switched 3DS SDK to stable version 2.2.20231219.

= 4.7.3 =
* Fixed 3DS retry leaving the Place Order button permanently disabled when the error callback received a falsy value.
* Fixed stale session surcharge and card difference values causing INVALID CARD DIFFERENCE AMOUNT rejections after merchant settings change.
* Fixed JS-to-server AJAX log handler bypassing the debug-mode gate for debug and info level messages.
* Switched logger from prepend to append mode, eliminating crash data-loss risk and O(n) I/O per write.
* Capped incoming JS log messages at 500 characters.
* Cached 3DS token with a 5-minute transient to prevent blocking HTTP calls on every checkout update.
* Fixed stale #billing-form causing 3DS retries to use previous card data.
* Fixed "No result found" polling message incorrectly destroying the 3DS session mid-poll.
* Updated 3DS library from 2.2.20231219 to 2.2.20250411.
* Fixed _bmspay_original_amount to store the full charged amount including surcharge and card difference.
* Added server-side JS logging via AJAX for full 3DS trace in WC logs.

= 4.7.2 =
* Fixed cart total not including fee at checkout — switched from get_total('raw') to get_subtotal() inside woocommerce_calculated_total filter.
* Fixed incorrect CardDifferenceAmount sent to Blackstone API — order base now subtracts stored fee meta to avoid circular calculation.
* Fixed order total double-counting fee on Order Received page — removed redundant set_total() call in save_order_meta.
* Fixed empty surcharge row in admin order view — each fee row is now conditionally rendered.
* Fixed fee row alignment in admin — corrected to WooCommerce's three-column structure (label | spacer | total).
* Fixed HPOS compatibility — replaced get/update_post_meta with order object API throughout refund flow.
* Fixed partial refund buttons remaining disabled after cancelling confirm dialog.
* Fixed full refund tax calculation to subtract already-refunded tax from prior partial refunds.
* Fixed missing return statements after wp_send_json_error() calls in refund handler.
* Fixed SweetAlert2 SRI hashes — pinned to exact version 11.26.24.
* Removed unused dead code: post_form, get_3ds_credentials, is_3ds_mode.

= 4.7.1 =
* Fixed PHP 8.1+ typed properties initialization to prevent fatal errors when accessing properties before initialization.
* Added default values to all typed properties in the gateway, API client, and credential manager classes.
* Fixed surcharge and card difference percentage display in checkout.
* Improved charge breakdown calculation to include percentage values.

= 4.6.6 =
* Completed Spanish translations for all active plugin strings and regenerated the compiled language pack.

= 4.6.5 =
* Restored active Spanish translations and regenerated localization catalogs without obsolete entries.
* Fixed final refund bookkeeping so orders move to refunded when the remaining refundable balance reaches zero after prior partial refunds.
* Removed the unused refund card form, template, and input mask asset from the plugin package.

= 4.6.4 =
* Hardened the Blackstone refund flow with stricter server-side validation, immutable sale references, and refund-specific tracking metadata.
* Prevented refund modal hangs by improving AJAX error handling and aligning the custom refund action across PHP and JavaScript.
* Removed sensitive payment logging and restored standard TLS verification for payment requests.
* Limited the checkout input mask script to the intended checkout context.
* Regenerated translation catalogs and synchronized plugin metadata to the current release.

= 4.6.3 =
* Fixed wallet partial payments so gateway charges, 3DS amounts, and surcharge calculations use the net WooCommerce total including negative wallet fees.
* Removed the custom checkout refresh flow that cleared cart fees and now rely on WooCommerce recalculation to preserve wallet discounts.

= 4.6.2 =
* Fixed 3DS Integrator CDN URL to use the minified version.

= 4.6.1 =
* Added automated ZIP packaging, artifact publishing, and GitHub release publication for the plugin.
* Added automated integration-guides updates for the latest ZIP alias and WooCommerce plugin versions table.

= 4.6.0 =
* Released a new minor version to re-align WordPress.org deployment history.
* Preserved the checkout script conflict fixes and token update safeguards from the previous release.

= 4.5.49 =
* Fixed JavaScript conflict on checkout page (undefined 'defaults' error) by restricting script loading.
* Improved script loading logic to prevent conflicts with other plugins.
* Fixed token update to only apply when it belongs to the same gateway.

= 4.5.43 =
* Added compatibility with WooCommerce 9.x.
* Improved refund API handling and error responses.
* Minor performance and security updates.
* Improved text translation.
* Added data to refund notes for better traceability.
* Standardized file and folder names.

= 4.5.0 =
* Initial public release.
* Added support for payment authorization and capture.
* Introduced refund integration via API.

== Upgrade Notice ==

= 4.6.6 =
* Completes the active Spanish translation set and refreshes the compiled language pack.

= 4.6.5 =
* Restores Spanish translations, fixes final refund completion after prior partial refunds, and removes unused refund form code.

= 4.6.4 =
* Improves refund reliability and hardens payment transport and release metadata for production use.

= 4.6.3 =
* Fixes partial wallet payments so only the remaining balance is charged to the card and related surcharges stay aligned with the net total.

= 4.6.1 =
* Adds automated release distribution and integration-guides publication for plugin updates.

== License ==

This plugin is licensed under the GPLv2 or later license.
You are free to modify and redistribute it under the same license.
See https://www.gnu.org/licenses/gpl-2.0.html for details.

== Credits ==

Developed and maintained by **Blackstone**
Website: [https://blackstoneonline.com/](https://blackstoneonline.com/)
Blackstone Merchant official site: [https://www.blackstonemerchant.com/](https://www.blackstonemerchant.com/)
