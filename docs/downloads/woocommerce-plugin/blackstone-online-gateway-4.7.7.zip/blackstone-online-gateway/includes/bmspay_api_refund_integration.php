<?php
if (!defined('ABSPATH')) {
    exit;
}

class BMSPAY_API_Refund_Integration
{
    const AJAX_ACTION      = 'bmspay_process_api_refund';
    const FULL_REFUND_ACTION = 'bmspay_process_full_refund';
    const NONCE_ACTION = 'api-refund-nonce';

    const LEGACY_SERVICE_REFERENCE_META = '_bmspay_service_reference_number';
    const LEGACY_USER_TRANSACTION_META = '_bmspay_transaction_number';

    const SALE_SERVICE_REFERENCE_META = '_bmspay_sale_service_reference_number';
    const SALE_USER_TRANSACTION_META = '_bmspay_sale_user_transaction_number';
    const SALE_ORIGINAL_AMOUNT_META = '_bmspay_original_amount';

    const REFUND_SERVICE_REFERENCE_META = '_bmspay_refund_service_reference_number';
    const REFUND_USER_TRANSACTION_META = '_bmspay_refund_user_transaction_number';

    private ?Bmspay_Api_Client $api_client = null;
    private ?Bmspay_Request_Builder $request_builder = null;
    private ?Bmspay_Response_Parser $response_parser = null;

    public function __construct()
    {
        add_action('admin_print_footer_scripts', [$this, 'add_api_refund_button']);
        add_action('wp_ajax_' . self::AJAX_ACTION, [$this, 'bmspay_process_api_refund']);
        add_action('wp_ajax_' . self::FULL_REFUND_ACTION, [$this, 'bmspay_process_full_refund']);
        add_action('woocommerce_order_refunded', [$this, 'clear_cache_on_refund'], 10, 2);

        $this->init_api_clients();
    }

    private function init_api_clients()
    {
        $gateway = $this->get_gateway();

        if ($gateway) {
            $this->request_builder = new Bmspay_Request_Builder($gateway);
            $this->response_parser = new Bmspay_Response_Parser();
            $this->api_client = new Bmspay_Api_Client($gateway);
        } else {
            if ( function_exists( 'wc_get_logger' ) ) {
                $logger = wc_get_logger();
                $logger->error( 'BMSPAY: Failed to initialize API clients - gateway not available', array( 'source' => 'bmspay-refund' ) );
            }
        }
    }

    private function get_gateway()
    {
        if (!class_exists('WC_Payment_Gateways')) {
            return null;
        }

        $payment_gateways = WC_Payment_Gateways::instance()->payment_gateways();

        return isset($payment_gateways['bmspay_blackstone_payment'])
            ? $payment_gateways['bmspay_blackstone_payment']
            : null;
    }

    public function clear_cache_on_refund($order_id, $refund_id)
    {
        $this->clear_order_cache($order_id);

        if (!empty($refund_id)) {
            $this->clear_order_cache($refund_id);
        }
    }

    public function add_api_refund_button()
    {
        $order_id = $this->detect_order_id_from_request();

        if ( ! $order_id ) {
            return;
        }

        $order = wc_get_order( $order_id );

        if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
            return;
        }

        if ( ! $this->should_show_api_refund_button( $order ) ) {
            return;
        }

        $is_es       = get_locale() === 'es_ES';
        $button_text = $is_es ? esc_html__( 'Reembolsar con Blackstone', 'blackstone-online-gateway' ) : esc_html__( 'Blackstone Refund', 'blackstone-online-gateway' );

		wp_enqueue_style( 'sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11.26.24/dist/sweetalert2.min.css', array(), '11.26.24' );
		wp_style_add_data( 'sweetalert2', 'integrity', 'sha384-OxWqvePLOm0AAoo759Ls7uD8ysM4N0fSXEE+QUY3pkVXBtkv6jkKNsPMC0KFMxWe' );
		wp_style_add_data( 'sweetalert2', 'crossorigin', 'anonymous' );

		wp_enqueue_script( 'sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11.26.24/dist/sweetalert2.min.js', array( 'jquery' ), '11.26.24', true );
		wp_script_add_data( 'sweetalert2', 'integrity', 'sha384-Nkb7LRzblHpSjchPwLtsgr8Ehgu63kNqniAR4kZn9VgYMnlAIYqUPYpXiZgzAKeu' );
		wp_script_add_data( 'sweetalert2', 'crossorigin', 'anonymous' );

		wp_enqueue_script( 'bmspay-admin-refund', esc_url( plugins_url( '../assets/js/bmspay-admin-refund.js', __FILE__ ) ), array( 'jquery', 'sweetalert2' ), '1.2.0', true );

        wp_localize_script('bmspay-admin-refund', 'bmspay_refund_params', [
            'ajaxurl'           => admin_url('admin-ajax.php'),
            'action'            => self::AJAX_ACTION,
            'fullRefundAction'  => self::FULL_REFUND_ACTION,
            'security'          => wp_create_nonce(self::NONCE_ACTION),
            'order_id'          => $order->get_id(),
            'remainingBalance'  => number_format((float) $this->get_remaining_balance($order), 2, '.', ''),
            'buttonText'        => $button_text,
            'fullRefundText'    => $is_es ? esc_html__( 'Reembolso Total Blackstone', 'blackstone-online-gateway' ) : esc_html__( 'Blackstone Full Refund', 'blackstone-online-gateway' ),
        ]);
    }

    /**
     * Detect the order ID from the current admin request.
     *
     * Storage-agnostic: works under Legacy posts, HPOS+sync and HPOS-only.
     * Under HPOS without sync, the legacy ?post=X URL becomes a post of type
     * 'shop_order_placehold' (a stub), so the historical
     * `get_post_type() === 'shop_order'` check returned false and the refund
     * button was never enqueued. We accept the placeholder type and also fall
     * back to wc_get_order(), which is storage-agnostic.
     *
     * @return int Order ID, or 0 if the request is not an order edit screen.
     */
    private function detect_order_id_from_request(): int
    {
        // HPOS admin URL: ?page=wc-orders&id=X (with or without &action=edit)
        if ( isset( $_GET['page'], $_GET['id'] ) && sanitize_text_field( wp_unslash( $_GET['page'] ) ) === 'wc-orders' ) {
            $candidate = absint( wp_unslash( $_GET['id'] ) );
            if ( $candidate > 0 && wc_get_order( $candidate ) instanceof WC_Order ) {
                return $candidate;
            }
        }

        // Legacy URL: ?post=X (typically &action=edit). Still emitted by some
        // links and bookmarks even when HPOS is the active store.
        if ( isset( $_GET['post'] ) ) {
            $candidate = absint( wp_unslash( $_GET['post'] ) );
            if ( $candidate > 0 ) {
                $post_type = get_post_type( $candidate );
                if ( in_array( $post_type, array( 'shop_order', 'shop_order_placehold' ), true ) ) {
                    return $candidate;
                }
                // Last-resort safety net: trust wc_get_order regardless of
                // wp_posts state. Covers HPOS-only setups and edge cases where
                // the legacy post row is missing or out of sync.
                if ( wc_get_order( $candidate ) instanceof WC_Order ) {
                    return $candidate;
                }
            }
        }

        return 0;
    }

    private function should_show_api_refund_button($order)
    {
        if (!$order || !is_a($order, 'WC_Order')) {
            return false;
        }

        if ($order->get_payment_method() !== 'bmspay_blackstone_payment') {
            return false;
        }

        if ($this->get_remaining_balance($order) <= 0) {
            return false;
        }

        return true;
    }

    public function bmspay_process_api_refund()
    {
        check_ajax_referer(self::NONCE_ACTION, 'security');

        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(['message' => $this->translate_message(
                'No tiene permisos para procesar reembolsos.',
                'You are not allowed to process refunds.'
            )]);
            return;
        }

        $order_id = isset($_POST['order_id']) ? absint(wp_unslash($_POST['order_id'])) : 0;
        $order = wc_get_order($order_id);

        if (!$order || !is_a($order, 'WC_Order')) {
            wp_send_json_error(['message' => $this->translate_message('Pedido no encontrado.', 'Order not found.')]);
            return;
        }

        if ($order->get_payment_method() !== 'bmspay_blackstone_payment') {
            wp_send_json_error(['message' => $this->translate_message(
                'Este pedido no fue procesado con Blackstone.',
                'This order was not processed with Blackstone.'
            )]);
            return;
        }

        $refund_data = $this->parse_refund_request($_POST, $order);

        if (is_wp_error($refund_data)) {
            wp_send_json_error(['message' => $refund_data->get_error_message()]);
            return;
        }

        $sale_references = $this->get_sale_references($order);

        if (is_wp_error($sale_references)) {
            wp_send_json_error(['message' => esc_html( $sale_references->get_error_message() )]);
            return;
        }

        $lock_key = 'bmspay_refund_lock_' . $order_id;

        if ( get_transient( $lock_key ) ) {
            wp_send_json_error(['message' => $this->translate_message(
                'Ya se está procesando un reembolso para este pedido. Por favor espere.',
                'A refund is already being processed for this order. Please wait.'
            )]);
            return;
        }

        set_transient( $lock_key, 1, 60 );

        try {
            $api_result = $this->process_in_blackstone_api($order, $refund_data, $sale_references);
        } finally {
            delete_transient( $lock_key );
        }

        if ($api_result['success']) {
            wp_send_json_success(['message' => esc_html( $api_result['message'] )]);
        }

        wp_send_json_error(['message' => esc_html( $api_result['message'] )]);
    }

    private function process_in_blackstone_api($order, $refund_data, $sale_references)
    {
        try {
            return $this->process_refund_request($order, $refund_data, $sale_references);
        } catch (Exception $e) {
            return ['success' => false, 'message' => esc_html( $e->getMessage() )];
        }
    }

    private function parse_refund_request($post_data, $order)
    {
        $refund_amount = isset($post_data['refund_amount']) ? (float) wp_unslash($post_data['refund_amount']) : 0;
        $refund_amount = number_format( $refund_amount, 2, '.', '' );

        if ($refund_amount <= 0) {
            return new WP_Error(
                'invalid_refund_amount',
                $this->translate_message(
                    'El monto del reembolso debe ser mayor a 0.',
                    'The refund amount must be greater than 0.'
                )
            );
        }

        $remaining_balance = (float) wc_format_decimal($this->get_remaining_balance($order));

        if ($refund_amount - $remaining_balance > 0.01) {
            return new WP_Error(
                'refund_amount_exceeds_balance',
                $this->translate_message(
                    'El monto del reembolso excede el saldo reembolsable restante.',
                    'The refund amount exceeds the remaining refundable balance.'
                )
            );
        }

        $line_items_raw = [];

        if (!empty($post_data['line_items'])) {
            $line_items_raw = json_decode(wp_unslash($post_data['line_items']), true);
        }

        if (!is_array($line_items_raw) || empty($line_items_raw)) {
            return new WP_Error(
                'missing_refund_lines',
                $this->translate_message(
                    'Seleccione al menos una línea válida del pedido para reembolsar.',
                    'Select at least one valid order line to refund.'
                )
            );
        }

        $parsed_items = [];
        $calculated_total = 0.0;

        foreach ($line_items_raw as $raw_item) {
            $parsed_item = $this->parse_refund_line_item($order, $raw_item);

            if (is_wp_error($parsed_item)) {
                return $parsed_item;
            }

            if (empty($parsed_item)) {
                continue;
            }

            $parsed_items[$parsed_item['id']] = $parsed_item['payload'];
            $calculated_total += (float) $parsed_item['amount'];
        }

        if (empty($parsed_items)) {
            return new WP_Error(
                'missing_refund_lines',
                $this->translate_message(
                    'Seleccione al menos una línea válida del pedido para reembolsar.',
                    'Select at least one valid order line to refund.'
                )
            );
        }

        if (abs($calculated_total - $refund_amount) > 0.01) {
            return new WP_Error(
                'refund_amount_mismatch',
                $this->translate_message(
                    'El monto total de las líneas seleccionadas no coincide con el monto del reembolso.',
                    'The total of the selected lines does not match the refund amount.'
                )
            );
        }

        return [
            'amount' => wc_format_decimal($refund_amount),
            'reason' => isset($post_data['refund_reason']) ? sanitize_text_field(wp_unslash($post_data['refund_reason'])) : '',
            'restock_items' => !empty($post_data['restock_items']) && (int) $post_data['restock_items'] === 1,
            'items' => $parsed_items,
        ];
    }

    private function parse_refund_line_item($order, $raw_item)
    {
        if (!is_array($raw_item)) {
            return new WP_Error(
                'invalid_refund_line',
                $this->translate_message(
                    'Se recibió una línea de reembolso inválida.',
                    'An invalid refund line was received.'
                )
            );
        }

        $item_id = isset($raw_item['id']) ? absint($raw_item['id']) : 0;
        $order_item = $item_id ? $order->get_item($item_id, false) : false;

        if (!$item_id || !$order_item) {
            return new WP_Error(
                'invalid_refund_line',
                $this->translate_message(
                    'Se recibió una línea de reembolso inválida.',
                    'An invalid refund line was received.'
                )
            );
        }

        $qty = isset($raw_item['qty']) ? wc_stock_amount(wp_unslash($raw_item['qty'])) : 0;
        $refund_total = isset($raw_item['total']) ? (float) wc_format_decimal(wp_unslash($raw_item['total'])) : 0.0;
        $tax_data = isset($raw_item['tax']) && is_array($raw_item['tax']) ? $raw_item['tax'] : [];
        $refund_tax = [];
        $tax_total = 0.0;
        $item_total = (float) $order_item->get_total();
        $item_id = $order_item->get_id();
        $already_refunded = (float) $order->get_total_refunded_for_item($item_id);
        $remaining_total = max(0.0, $item_total - $already_refunded);

        foreach ($tax_data as $tax_id => $tax_amount) {
            $formatted_tax = (float) wc_format_decimal(wp_unslash($tax_amount));

            if ($formatted_tax <= 0) {
                continue;
            }

            $normalized_tax_key = is_numeric($tax_id) ? absint($tax_id) : sanitize_key((string) $tax_id);
            $refund_tax[$normalized_tax_key] = wc_format_decimal($formatted_tax);
            $tax_total += $formatted_tax;
        }

        if ($qty < 0 || $refund_total < 0 || $tax_total < 0) {
            return new WP_Error(
                'invalid_refund_line',
                $this->translate_message(
                    'Los valores del reembolso no pueden ser negativos.',
                    'Refund values cannot be negative.'
                )
            );
        }

        if ($refund_total - $remaining_total > 0.01) {
            return new WP_Error(
                'invalid_refund_total',
                $this->translate_message(
                    'El total seleccionado excede el total reembolsable restante de una de las líneas.',
                    'The selected total exceeds the remaining refundable total for one of the lines.'
                )
            );
        }

        $order_item_type = $order_item->get_type();
        $payload = [];

        if ($order_item_type === 'line_item' && $qty > 0) {
            $qty_purchased        = (int) $order_item->get_quantity();
            $qty_already_refunded = absint( $order->get_qty_refunded_for_item( $item_id ) );
            $qty_remaining        = max( 0, $qty_purchased - $qty_already_refunded );

            if ($qty > $qty_remaining) {
                return new WP_Error(
                    'invalid_refund_quantity',
                    $this->translate_message(
                        'La cantidad seleccionada excede la cantidad reembolsable de uno de los artículos.',
                        'The selected quantity exceeds the refundable quantity for one of the items.'
                    )
                );
            }

            $payload['qty'] = $qty;
        }

        if ($refund_total > 0) {
            $payload['refund_total'] = wc_format_decimal($refund_total);
        }

        if (!empty($refund_tax)) {
            $payload['refund_tax'] = $refund_tax;
        }

        if (empty($payload) || (!isset($payload['qty']) && !isset($payload['refund_total']) && !isset($payload['refund_tax']))) {
            return [];
        }

        return [
            'id' => $item_id,
            'payload' => $payload,
            'amount' => $refund_total + $tax_total,
        ];
    }

    private function get_sale_references($order)
    {
        $sale_service_reference = (string) $order->get_meta(self::SALE_SERVICE_REFERENCE_META, true);
        $sale_user_transaction = (string) $order->get_meta(self::SALE_USER_TRANSACTION_META, true);
        $sale_original_amount = (float) $order->get_meta(self::SALE_ORIGINAL_AMOUNT_META, true);

        if ($sale_service_reference !== '') {
            return [
                'service_reference' => $sale_service_reference,
                'user_transaction' => $sale_user_transaction,
                'original_amount' => $sale_original_amount,
                'bootstrapped' => false,
            ];
        }

        $legacy_service_reference = (string) $order->get_meta(self::LEGACY_SERVICE_REFERENCE_META, true);
        $legacy_user_transaction = (string) $order->get_meta(self::LEGACY_USER_TRANSACTION_META, true);

        if ($legacy_service_reference !== '' && !$this->order_has_refunds($order)) {
            $order->update_meta_data(self::SALE_SERVICE_REFERENCE_META, $legacy_service_reference);

            if ($legacy_user_transaction !== '') {
                $order->update_meta_data(self::SALE_USER_TRANSACTION_META, $legacy_user_transaction);
            }

            $order->save();

            return [
                'service_reference' => $legacy_service_reference,
                'user_transaction' => $legacy_user_transaction,
                'original_amount' => $sale_original_amount,
                'bootstrapped' => true,
            ];
        }

        return new WP_Error(
            'missing_sale_reference',
            $this->translate_message(
                'No se pudo procesar el reembolso porque falta la referencia original de venta de Blackstone o ya no es confiable. Revise el pedido manualmente.',
                'The refund could not be processed because the original Blackstone sale reference is missing or no longer reliable. Review the order manually.'
            )
        );
    }

    public function get_remaining_balance($order)
    {
        if (is_numeric($order)) {
            $order = wc_get_order($order);
        }

        if (!$order || !is_a($order, 'WC_Order')) {
            return 0;
        }

        // Usar el Amount original de Blackstone si está disponible
        $original_amount = (float) $order->get_meta(self::SALE_ORIGINAL_AMOUNT_META, true);

        if ($original_amount > 0) {
            $total_refunded = (float) $order->get_total_refunded();
            // El refunded puede incluir refunds manuales de WooCommerce, así que usamos el menor
            return max(0, $original_amount - $total_refunded);
        }

        return (float) $order->get_total() - (float) $order->get_total_refunded();
    }

    public function process_refund_request($order, $refund_data, $sale_references)
    {
        if (is_numeric($order)) {
            $order = wc_get_order($order);
        }

        if (!$order || !is_a($order, 'WC_Order')) {
            return ['success' => false, 'message' => $this->translate_message('Pedido inválido.', 'Invalid order.')];
        }

        if (!isset($this->api_client) || !isset($this->request_builder) || !isset($this->response_parser)) {
            return ['success' => false, 'message' => $this->translate_message(
                'No se pudo procesar el reembolso. Por favor contacte al administrador.',
                'Unable to process the refund. Please contact the administrator.'
            )];
        }

        $payload = $this->request_builder->build_refund_payload(
            $refund_data['amount'],
            $sale_references['service_reference'],
            $order
        );

        $response = $this->api_client->process_refund($payload);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $this->translate_message(
                    'No fue posible conectar con Blackstone para procesar el reembolso.',
                    'Could not connect to Blackstone to process the refund.'
                ) . ' ' . $response->get_error_message(),
            ];
        }

        $refund_service_reference = isset($response['ServiceReferenceNumber']) ? sanitize_text_field($response['ServiceReferenceNumber']) : '';
        $refund_user_transaction = isset($payload['UserTransactionNumber']) ? sanitize_text_field($payload['UserTransactionNumber']) : '';

        if (!$this->response_parser->is_refund_success($response)) {
            $message = $this->get_message_error($response);
            $message .= $sale_references['service_reference'] !== ''
                ? ' ' . sprintf(
                    $this->translate_message('Sale Ref: %s.', 'Sale Ref: %s.'),
                    $sale_references['service_reference']
                )
                : '';

            return [
                'success' => false,
                'message' => $message,
            ];
        }

        $refund = wc_create_refund([
            'amount' => $refund_data['amount'],
            'reason' => $refund_data['reason'] !== ''
                ? $refund_data['reason']
                : $this->translate_message('Reembolso procesado vía API.', 'Refund processed via API.'),
            'order_id' => $order->get_id(),
            'refund_payment' => false,
            'restock_items' => $refund_data['restock_items'],
            'line_items' => $refund_data['items'],
        ]);

        if (is_wp_error($refund)) {
            $order->add_order_note(sprintf(
                $this->translate_message(
                    'Blackstone procesó el reembolso remotamente, pero WooCommerce no pudo registrar el reembolso local. Se requiere conciliación manual. Refund Ref: %1$s. Error: %2$s',
                    'Blackstone processed the refund remotely, but WooCommerce could not create the local refund. Manual reconciliation is required. Refund Ref: %1$s. Error: %2$s'
                ),
                $refund_service_reference !== '' ? $refund_service_reference : __('N/A', 'blackstone-online-gateway'),
                $refund->get_error_message()
            ));
            $order->save();

            return [
                'success' => false,
                'message' => $this->translate_message(
                    'Blackstone procesó el reembolso, pero WooCommerce no pudo registrarlo localmente. Revise las notas del pedido.',
                    'Blackstone processed the refund, but WooCommerce could not register it locally. Review the order notes.'
                ),
            ];
        }

        if (!$refund || !is_a($refund, 'WC_Order_Refund')) {
            $order->add_order_note(sprintf(
                $this->translate_message(
                    'Blackstone procesó el reembolso remotamente, pero WooCommerce devolvió un objeto de reembolso inválido. Se requiere conciliación manual. Refund Ref: %s',
                    'Blackstone processed the refund remotely, but WooCommerce returned an invalid refund object. Manual reconciliation is required. Refund Ref: %s'
                ),
                $refund_service_reference !== '' ? $refund_service_reference : __('N/A', 'blackstone-online-gateway')
            ));
            $order->save();

            return [
                'success' => false,
                'message' => $this->translate_message(
                    'Blackstone procesó el reembolso, pero WooCommerce no pudo registrar un reembolso válido. Revise las notas del pedido.',
                    'Blackstone processed the refund, but WooCommerce could not register a valid refund. Review the order notes.'
                ),
            ];
        }

        if ($refund_service_reference !== '') {
            $refund->update_meta_data(self::REFUND_SERVICE_REFERENCE_META, $refund_service_reference);
        }

        $refund->update_meta_data(self::REFUND_USER_TRANSACTION_META, $refund_user_transaction);
        $refund->save();

        $sale_reference_note = sprintf(
            $this->translate_message('Sale Ref: %s', 'Sale Ref: %s'),
            $sale_references['service_reference']
        );
        $refund_reference_note = sprintf(
            $this->translate_message('Refund Ref: %s', 'Refund Ref: %s'),
            $refund_service_reference !== '' ? $refund_service_reference : __('N/A', 'blackstone-online-gateway')
        );
        $refund_transaction_note = sprintf(
            $this->translate_message('Refund User Transaction Number: %s', 'Refund User Transaction Number: %s'),
            $refund_user_transaction
        );

        $order->add_order_note(
            $this->translate_message('Blackstone refund processed via API.', 'Blackstone refund processed via API.')
            . ' ' . $sale_reference_note
            . '. ' . $refund_reference_note
            . '. ' . $refund_transaction_note . '.'
        );

        if ($refund_data['restock_items']) {
            $order->add_order_note($this->translate_message(
                'Artículos reembolsados repuestos automáticamente en inventario.',
                'Refunded items were restocked automatically.'
            ));
        }

        $refreshed_order = wc_get_order($order->get_id());

        if ($refreshed_order && is_a($refreshed_order, 'WC_Order')) {
            $order = $refreshed_order;
        }

        $remaining_balance = max(0.0, (float) $this->get_remaining_balance($order));

        if ($remaining_balance > 0.01) {
            $order->add_order_note(sprintf(
                __('Partial refund of %s via API', 'blackstone-online-gateway'),
                wc_price($refund_data['amount'])
            ));
        } else {
            $order->add_order_note(sprintf(
                __('Total refund of %s via API', 'blackstone-online-gateway'),
                wc_price($refund_data['amount'])
            ));
            $order->update_status('refunded');
        }

        $order->save();
        $this->clear_cache_on_refund($order->get_id(), $refund->get_id());

        $message = $this->translate_message('Refund completed successfully.', 'Refund completed successfully.');

        if ($refund_service_reference !== '') {
            $message .= ' ' . sprintf(
                $this->translate_message('Refund Ref: %s', 'Refund Ref: %s'),
                $refund_service_reference
            );
        }

        return [
            'success' => true,
            'message' => $message,
        ];
    }

    public function bmspay_process_full_refund()
    {
        check_ajax_referer(self::NONCE_ACTION, 'security');

        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(['message' => $this->translate_message(
                'No tiene permisos para procesar reembolsos.',
                'You are not allowed to process refunds.'
            )]);
            return;
        }

        $order_id = isset($_POST['order_id']) ? absint(wp_unslash($_POST['order_id'])) : 0;
        $order    = wc_get_order($order_id);

        if (!$order || !is_a($order, 'WC_Order')) {
            wp_send_json_error(['message' => $this->translate_message('Pedido no encontrado.', 'Order not found.')]);
            return;
        }

        if ($order->get_payment_method() !== 'bmspay_blackstone_payment') {
            wp_send_json_error(['message' => $this->translate_message(
                'Este pedido no fue procesado con Blackstone.',
                'This order was not processed with Blackstone.'
            )]);
            return;
        }

        $remaining_balance = $this->get_remaining_balance($order);

        if ($remaining_balance <= 0) {
            wp_send_json_error(['message' => $this->translate_message(
                'No hay saldo pendiente para reembolsar.',
                'There is no remaining balance to refund.'
            )]);
            return;
        }

        $sale_references = $this->get_sale_references($order);

        if (is_wp_error($sale_references)) {
            wp_send_json_error(['message' => esc_html($sale_references->get_error_message())]);
            return;
        }

        $lock_key = 'bmspay_refund_lock_' . $order_id;

        if (get_transient($lock_key)) {
            wp_send_json_error(['message' => $this->translate_message(
                'Ya se está procesando un reembolso para este pedido. Por favor espere.',
                'A refund is already being processed for this order. Please wait.'
            )]);
            return;
        }

        set_transient($lock_key, 1, 60);

        try {
            $refund_data = [
                'amount'        => wc_format_decimal($remaining_balance),
                'reason'        => $this->translate_message('Reembolso total vía API de Blackstone.', 'Full refund via Blackstone API.'),
                'restock_items' => false,
                'items'         => $this->build_full_refund_items($order),
            ];

            $api_result = $this->process_in_blackstone_api($order, $refund_data, $sale_references);
        } finally {
            delete_transient($lock_key);
        }

        if ($api_result['success']) {
            wp_send_json_success(['message' => esc_html($api_result['message'])]);
        }

        wp_send_json_error(['message' => esc_html($api_result['message'])]);
    }

    private function build_full_refund_items(WC_Order $order): array
    {
        $items = [];

        foreach ($order->get_items(['line_item', 'shipping', 'fee']) as $item_id => $item) {
            $item_total       = (float) $item->get_total();
            $item_tax         = (float) $item->get_total_tax();
            $already_refunded = (float) $order->get_total_refunded_for_item($item_id);
            $remaining        = max(0.0, $item_total - $already_refunded);

            if ($remaining <= 0) {
                continue;
            }

            $entry = ['refund_total' => wc_format_decimal($remaining)];

            if ($item->get_type() === 'line_item') {
                $qty_purchased        = (int) $item->get_quantity();
                $qty_already_refunded = absint( $order->get_qty_refunded_for_item( $item_id ) );
                $qty_remaining        = max( 0, $qty_purchased - $qty_already_refunded );

                if ($qty_remaining > 0) {
                    $entry['qty'] = $qty_remaining;
                }
            }

            if ($item_tax > 0) {
                $taxes = $item->get_taxes();
                if (!empty($taxes['total'])) {
                    $refund_tax = [];
                    foreach ($taxes['total'] as $tax_id => $tax_amount) {
                        $original_tax      = (float) wc_format_decimal($tax_amount);
                        $already_refunded  = (float) $order->get_tax_refunded_for_item($item_id, absint($tax_id));
                        $remaining_tax     = max(0.0, $original_tax - abs($already_refunded));
                        if ($remaining_tax > 0) {
                            $refund_tax[absint($tax_id)] = wc_format_decimal($remaining_tax);
                        }
                    }
                    if (!empty($refund_tax)) {
                        $entry['refund_tax'] = $refund_tax;
                    }
                }
            }

            $items[$item_id] = $entry;
        }

        return $items;
    }

    public function get_message_error($response_data)
    {
        $msg = __('No message provided', 'blackstone-online-gateway');

        if (isset($response_data['Msg']) && is_array($response_data['Msg'])) {
            $msg = implode(', ', array_map('sanitize_text_field', $response_data['Msg']));
        }

        return $msg;
    }

    private function order_has_refunds($order)
    {
        $refunds = $order->get_refunds();

        return !empty($refunds);
    }

    private function clear_order_cache($order_id)
    {
        clean_post_cache($order_id);
        wp_cache_delete($order_id, 'posts');
        wp_cache_delete($order_id, 'post_meta');
        wc_delete_shop_order_transients($order_id);
        delete_transient('wc_order_data_' . $order_id);
    }

    private function translate_message($spanish, $english)
    {
        return get_locale() === 'es_ES' ? $spanish : $english;
    }
}
