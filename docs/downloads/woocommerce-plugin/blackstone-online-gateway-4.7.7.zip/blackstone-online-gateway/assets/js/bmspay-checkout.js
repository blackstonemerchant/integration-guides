jQuery(document).ready(function($) {
    var canSubmitForm = false;

    // Country code conversion map (alpha-2 to ISO 3166-1 numeric)
    var countryCodeMap = {
        'US': '840', 'ES': '724', 'GB': '826', 'FR': '250', 'DE': '276',
        'IT': '380', 'CA': '124', 'AU': '036', 'JP': '392', 'CN': '156',
        'IN': '356', 'BR': '076', 'MX': '484', 'NL': '528', 'SE': '752',
        'CH': '756', 'BE': '056', 'AT': '040'
    };

    function convertCountryCode(countryCode) {
        if (!countryCode) return '840';
        return countryCodeMap[countryCode.toUpperCase()] || '840';
    }

    // Generate a fresh RFC 4122 v4 UUID for each 3DS authentication attempt.
    // Each checkout attempt is semantically a distinct transaction; reusing the
    // same id across retries collapses them into one in correlation logs.
    function generateClientTransactionId() {
        if (window.crypto && typeof window.crypto.randomUUID === 'function') {
            return window.crypto.randomUUID();
        }
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0;
            var v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    // Alert helper - uses SweetAlert2 with native alert fallback
    var BmspayAlert = {
        show: function(message, type) {
            type = type || 'info';
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: type === 'error' ? 'Error' : (type === 'success' ? 'Éxito' : 'Información'),
                    text: message,
                    icon: type,
                    confirmButtonText: 'OK'
                });
            } else {
                alert((type === 'error' ? 'Error: ' : '') + message);
            }
        },
        showError: function(message) {
            this.show(message, 'error');
        },
        showSuccess: function(message) {
            this.show(message, 'success');
        },
        close: function() {
            if (typeof Swal !== 'undefined' && Swal.getPopup()) {
                Swal.close();
            }
        },
        showLoading: function(title, html, options) {
            if (typeof Swal !== 'undefined') {
                Swal.fire(Object.assign({
                    title: title || 'Cargando',
                    html: html || 'Por favor espere...',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                }, options || {}));
            }
        }
    };

    // Send a log entry to the server via AJAX.
    function serverLog(level, message) {
        var params = bmspay_checkout_params || {};
        if (!params.logAjaxUrl || !params.logNonce) {
            return;
        }
        $.post(params.logAjaxUrl, {
            action: 'bmspay_3ds_client_log',
            nonce: params.logNonce,
            level: level,
            message: message
        });
    }

    // Card validation functions (matching PHP validation)
    var BmspayValidator = {
        // Luhn algorithm for card number validation
        luhnCheck: function(cardNumber) {
            var digits = cardNumber.replace(/\D/g, '').split('').reverse();
            var total = 0;
            var odd = false;

            for (var i = 0; i < digits.length; i++) {
                var digit = parseInt(digits[i], 10);
                if (odd) {
                    digit *= 2;
                    if (digit > 9) {
                        digit -= 9;
                    }
                }
                total += digit;
                odd = !odd;
            }

            return total % 10 === 0;
        },

        isValidNumber: function(cardNumber) {
            var clean = cardNumber.replace(/\D/g, '');
            if (clean.length < 13 || clean.length > 19) {
                return false;
            }
            return this.luhnCheck(clean);
        },

        isValidExpiry: function(expiry) {
            var match = expiry.match(/^(0[1-9]|1[0-2])\s*\/\s*([0-9]{2}|[0-9]{4})$/);
            if (!match) {
                return false;
            }

            var month = parseInt(match[1], 10);
            var year = parseInt(match[2], 10);

            if (year < 100) {
                year += 2000;
            }

            var now = new Date();
            var currentYear = now.getFullYear();
            var currentMonth = now.getMonth() + 1;

            // Check if expired
            if (year < currentYear) {
                return false;
            }
            if (year === currentYear && month < currentMonth) {
                return false;
            }

            return true;
        },

        isValidCvc: function(cvc) {
            var clean = cvc.replace(/\D/g, '');
            return clean.length === 3 || clean.length === 4;
        }
    };

    // Determinar si es página de pago de pedido.
    // Se chequea el query param pay_for_order=true (invariante al slug del idioma)
    // y el slug en inglés como fallback para instalaciones sin traducción.
    var isPayForOrder = window.location.search.indexOf('pay_for_order=true') !== -1
        || window.location.href.indexOf('order-pay') !== -1
        || ($('#order_review').length > 0 && $('form.checkout').length === 0);

    // Seleccionar el formulario correcto
    var $form = isPayForOrder ? $('#order_review') : $('form.checkout');

    function getSubmitButton() {
        if (isPayForOrder) {
            return $('#place_order');
        }

        var $btn = $('#place_order');
        if ($btn.length === 0) {
            $btn = $('button[name="woocommerce_checkout_place_order"]');
        }
        if ($btn.length === 0) {
            $btn = $('form.checkout').find('button[type="submit"]');
        }
        return $btn;
    }

    function enableSubmitButton() {
        var $submitBtn = getSubmitButton();
        if ($submitBtn.length) {
            $submitBtn.prop('disabled', false);
        }
        $('.woocommerce-ajax-loader').hide();
    }

    function disableSubmitButton() {
        var $submitBtn = getSubmitButton();
        if ($submitBtn.length) {
            $submitBtn.prop('disabled', true);
        }
        $('.woocommerce-ajax-loader').show();
    }

    function cleanup3DS() {
        $('iframe[id^="container-challenge-3ds"]').remove();
        $('#billing-form').remove();
        $('style[data-bmspay-3ds]').remove();
        BmspayAlert.close();
        window.tds = undefined;
        serverLog('debug', '3DS: cleanup done');
    }

    function getChargeAmount() {
        var amount = parseFloat($('#bmspay-charge-amount').val());

        if (Number.isNaN(amount)) {
            amount = parseFloat(bmspay_checkout_params.total);
        }

        return Number.isNaN(amount) ? 0 : amount;
    }

    // Detect a 401-class error from the 3DS SDK error callback.
    // The SDK normalises errors to either a string ("401 Unauthorized") or an
    // object ({ error|message, statusCode|status }). We look in both shapes.
    function is401Error(errorObj, errorMessage) {
        if (errorObj !== null && !Array.isArray(errorObj) && typeof errorObj === 'object') {
            if (errorObj.statusCode === 401 || errorObj.status === 401 || errorObj.code === 401) {
                return true;
            }
            if (errorObj.response && errorObj.response.status === 401) {
                return true;
            }
        }
        var msg = typeof errorMessage === 'string' ? errorMessage : '';
        if (/\b401\b/.test(msg)) return true;
        if (msg.toLowerCase().indexOf('unauthorized') !== -1) return true;
        if (/jwt.*(expired|invalid)/i.test(msg)) return true;
        if (/token.*(expired|invalid)/i.test(msg)) return true;
        return false;
    }

    // Ask the server to delete the cached JWT and fetch a new one.
    // Resolves with { apiKey, token }; rejects with a string error message.
    function refreshThreeDsToken() {
        return $.ajax({
            url: bmspay_checkout_params.logAjaxUrl,
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'bmspay_3ds_refresh_token',
                nonce: bmspay_checkout_params.refreshTokenNonce
            }
        }).then(function(response) {
            if (response && response.success && response.data && response.data.apiKey && response.data.token) {
                return response.data;
            }
            var msg = response && response.data && response.data.message ? response.data.message : 'Token refresh failed';
            return $.Deferred().reject(msg).promise();
        }, function(xhr) {
            var msg = 'Token refresh request failed';
            if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                msg = xhr.responseJSON.data.message;
            }
            return $.Deferred().reject(msg).promise();
        });
    }

    function initialize3DS(chargeAmount, lastFour, clientTransactionId, isRetry) {
        const uniqueId = Date.now();
        const iframeId = 'container-challenge-3ds-' + uniqueId;
        const wrapperId = 'challenge-wrapper-' + uniqueId;
        const loaderId = 'challenge-loader-' + uniqueId;

        serverLog('debug', '3DS: verify started — card=****' + lastFour + ' amount=' + chargeAmount + ' clientTxnId=' + clientTransactionId + (isRetry ? ' (retry)' : ''));

        var styleEl = document.createElement('style');
        styleEl.setAttribute('data-bmspay-3ds', iframeId);
        styleEl.textContent = '#' + iframeId + ' { display: block !important; width: 390px !important; height: 400px !important; border: none !important; }';
        document.head.appendChild(styleEl);

        var html_3ds = `
            <div class="threeds-modal-content">
                <div style="position: relative; width: 390px; height: 400px; margin: 0 auto; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9; box-sizing: border-box; overflow: hidden;">
                    <div id="${wrapperId}" style="width: 100%; height: 100%;"></div>
                    <div id="${loaderId}" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; pointer-events: none;">
                        <div class="spinner"></div>
                        <p style="margin-top: 8px; color: #555;">Procesando verificación de seguridad...</p>
                    </div>
                </div>
                <p style="margin-top: 15px; font-size: 12px; color: #666; text-align: center;">Por favor no cierre esta ventana.</p>
            </div>
        `;

        BmspayAlert.showLoading('Verificación 3D Secure', html_3ds, { width: '460px' });

        setTimeout(function() {
            const wrapper = document.getElementById(wrapperId);
            if (!wrapper) {
                serverLog('error', '3DS: wrapper element not found after showLoading');
                BmspayAlert.showError('Error al inicializar 3D Secure');
                enableSubmitButton();
                return;
            }

            const iframe = document.createElement('iframe');
            iframe.id = iframeId;
            iframe.name = iframeId;
            iframe.style.opacity = '0';
            iframe.style.transition = 'opacity 0.3s ease';

            wrapper.appendChild(iframe);

            var apiKey = bmspay_checkout_params.apiKey;
            var token = bmspay_checkout_params.token;

            window.tds = new ThreeDS(
                "billing-form",
                apiKey,
                token,
                {
                    endpoint: bmspay_checkout_params.endpoint,
                    autoSubmit: false,
                    showChallenge: true,
                    popup: false,
                    iframeId: iframeId,
                    forcedTimeOut: '10',
                    challengeWindowSize: '02',
                    clientTransactionId: clientTransactionId
                }
            );

            iframe.onload = function() {
                var loader = document.getElementById(loaderId);
                if (loader) loader.style.display = 'none';
                iframe.style.opacity = '1';
            };

window.tds.verify(
                function(response) {
                    var $tempForm = $('#billing-form');

                    if (!response || (response.status !== 'Y' && response.status !== 'A')) {
                        var status = response && response.status ? response.status : 'unknown';
                        var errorMessage = '3D Secure Verification Failed';
                        if (response && response.transStatusReasonDetail) {
                            errorMessage += ': ' + $('<div>').text(response.transStatusReasonDetail).html();
                        } else if (response && response.status) {
                            errorMessage += ' (Status: ' + $('<div>').text(response.status).html() + ')';
                        }

                        serverLog('warning', '3DS: verify callback — status=' + status + ' card=****' + lastFour);
                        $tempForm.remove();
                        // Also clean up any leftover iframes from this attempt.
                        $('iframe[id^="container-challenge-3ds"]').remove();
                        window.tds = undefined;
                        BmspayAlert.close();
                        BmspayAlert.showError(errorMessage);
                        enableSubmitButton();
                        canSubmitForm = false;
                        return false;
                    }

                    serverLog('debug', '3DS: verify callback — status=' + response.status + ' card=****' + lastFour);

                    var threeDsTransactionId = window.tds.threeDsTransactionId;
                    if (threeDsTransactionId) {
                        response.threeDsTransactionId = threeDsTransactionId;
                    }

                    $tempForm.remove();
                    canSubmitForm = true;
                    BmspayAlert.close();

                    var $targetForm = isPayForOrder ? $('#order_review') : $('form.checkout');

                    if (!$targetForm.find('input[name=threeds_response]').length) {
                        $('<input>').attr({
                            type: 'hidden',
                            name: 'threeds_response',
                            value: JSON.stringify(response)
                        }).appendTo($targetForm);
                    } else {
                        $targetForm.find('input[name=threeds_response]').val(JSON.stringify(response));
                    }

                    cleanup3DS();
                    $targetForm.submit();
                },
                function(error) {
                    var errorObj = error;
                    var errorMessage = '';

                    if (typeof error === 'string') {
                        if (error.trim() === '') {
                            errorMessage = 'Error de conexión desconocido';
                        } else {
                            try {
                                errorObj = JSON.parse(error);
                            } catch (e) {
                                errorMessage = error;
                            }
                        }
                    }

                    if (!errorMessage && errorObj && typeof errorObj === 'object') {
                        errorMessage = errorObj.error || errorObj.message || 'Error de conexión desconocido';
                    }

                    if (errorMessage === 'No result found for transaction as yet. Please subscribe again' ||
                        errorMessage === 'No result found for transaction as yet') {
                        // Per Blackstone docs: this message is emitted by the library's internal
                        // polling loop and is NOT a terminal error. Do not clean up — let the
                        // library continue polling until it gets a final result.
                        serverLog('debug', '3DS: polling — no result yet for card=****' + lastFour);
                        return;
                    }

                    if (!errorMessage) {
                        serverLog('warning', '3DS: error callback with no message — card=****' + lastFour);
                        cleanup3DS();
                        BmspayAlert.showError('Error en la verificación 3D Secure. Por favor intente de nuevo.');
                        enableSubmitButton();
                        canSubmitForm = false;
                        return;
                    }

                    // 401 means the cached JWT was rejected. Refresh server-side
                    // and retry once with a fresh token + new clientTransactionId.
                    // Skip on a retry attempt to avoid an infinite refresh loop.
                    if (!isRetry && is401Error(errorObj, errorMessage)) {
                        serverLog('warning', '3DS: 401 detected, refreshing token — card=****' + lastFour);
                        cleanup3DS();
                        refreshThreeDsToken().done(function(data) {
                            bmspay_checkout_params.apiKey = data.apiKey;
                            bmspay_checkout_params.token = data.token;
                            serverLog('debug', '3DS: token refreshed, retrying verify — card=****' + lastFour);
                            setTimeout(function() {
                                initialize3DS(chargeAmount, lastFour, generateClientTransactionId(), true);
                            }, 350);
                        }).fail(function(refreshError) {
                            serverLog('error', '3DS: token refresh failed — ' + String(refreshError).substring(0, 200));
                            BmspayAlert.close();
                            BmspayAlert.showError(refreshError || 'Error al refrescar credenciales 3DS');
                            enableSubmitButton();
                            canSubmitForm = false;
                        });
                        return false;
                    }

                    serverLog('error', '3DS: error callback — ' + errorMessage.substring(0, 200) + ' card=****' + lastFour);
                    // Ensure #billing-form and iframes are removed so a retry starts clean.
                    cleanup3DS();
                    BmspayAlert.close();
                    BmspayAlert.showError(errorMessage);
                    enableSubmitButton();
                    canSubmitForm = false;
                    return false;
                },
                {
                    amount: chargeAmount,
                    currency: bmspay_checkout_params.currency || '840'
                }
            );
        }, 100);
    }

    $form.on('submit', function(e) {
        if ($('input[name="payment_method"]:checked').val() === 'bmspay_blackstone_payment') {
            if (!canSubmitForm) {
                e.preventDefault();
                e.stopImmediatePropagation();

                disableSubmitButton();

                var selectedToken = $('input[name="wc-saved-payment-token"]:checked').val();
                if (selectedToken && selectedToken !== 'new') {
                    canSubmitForm = true;
                    $form.trigger('submit');
                    return;
                }

                var cardNumber = $('#bmspay_blackstone_payment-card-number').val().replace(/\s+/g, '');
                var expiry = $('#bmspay_blackstone_payment-card-expiry').val().replace(/\s+/g, '');
                var cvv = $('#bmspay_blackstone_payment-card-cvc').val();
                var billingPostCode = $('#billing_postcode').val();
                var cardHolderName = $('#billing_first_name').val() + ' ' + $('#billing_last_name').val();
                var email = $('#billing_email').val();
                var billingLine1 = $('#billing_address_1').val();
                var billingCity = $('#billing_city').val();
                var billingState = $('#billing_state').val();
                var billingCountry = $('#billing_country').val();
                var chargeAmount = getChargeAmount();
                var lastFour = cardNumber.slice(-4);

                // Card validation (matching PHP Bmspay_Card_Validator)
                if (!BmspayValidator.isValidNumber(cardNumber)) {
                    BmspayAlert.showError('Por favor ingrese un número de tarjeta válido');
                    enableSubmitButton();
                    return;
                }

                var expiryMatch = expiry.match(/^(0[1-9]|1[0-2])\s*\/\s*([0-9]{2}|[0-9]{4})$/);
                if (!expiryMatch || !BmspayValidator.isValidExpiry(expiry)) {
                    BmspayAlert.showError('Por favor ingrese una fecha de expiración válida (MM/YY) y que no esté vencida');
                    enableSubmitButton();
                    return;
                }

                var month = expiryMatch[1];
                var year = expiryMatch[2];

                if (!BmspayValidator.isValidCvc(cvv)) {
                    BmspayAlert.showError('Por favor ingrese un código de seguridad (CVV) válido (3 o 4 dígitos)');
                    enableSubmitButton();
                    return;
                }

                var clientTransactionId = generateClientTransactionId();

                // Convert country code from alpha-2 to numeric for 3DS API
                var billingCountryNumeric = convertCountryCode(billingCountry);

                // Remove any leftover #billing-form from a previous failed attempt
                // before creating a fresh one with the current card data.
                $('#billing-form').remove();

                var $tempForm = $('<form id="billing-form" style="display:none;"></form>').appendTo('body');
                $tempForm.append($('<input type="hidden" name="billing-card-amount" />').val(chargeAmount).attr('data-threeds', 'amount'));
                $tempForm.append($('<input type="hidden" name="billing-card-pan" />').val(cardNumber).attr('data-threeds', 'pan'));
                $tempForm.append($('<input type="hidden" name="billing-card-month" />').val(month).attr('data-threeds', 'month'));
                $tempForm.append($('<input type="hidden" name="billing-card-year" />').val(year).attr('data-threeds', 'year'));
                $tempForm.append($('<input type="hidden" name="billing-card-cvv" />').val(cvv).attr('data-threeds', 'cvv'));
                $tempForm.append($('<input type="hidden" name="billing-card-holder-name" />').val(cardHolderName).attr('data-threeds', 'cardHolderName'));
                $tempForm.append($('<input type="hidden" name="billing-card-email" />').val(email).attr('data-threeds', 'email'));
                $tempForm.append($('<input type="hidden" name="billing-card-billing-line1" />').val(billingLine1).attr('data-threeds', 'billingLine1'));
                $tempForm.append($('<input type="hidden" name="billing-card-billing-city" />').val(billingCity).attr('data-threeds', 'billingCity'));
                $tempForm.append($('<input type="hidden" name="billing-card-billing-state" />').val(billingState).attr('data-threeds', 'billingState'));
                $tempForm.append($('<input type="hidden" name="billing-card-billing-post-code" />').val(billingPostCode).attr('data-threeds', 'billingPostCode'));
                $tempForm.append($('<input type="hidden" name="billing-card-billing-country" />').val(billingCountryNumeric).attr('data-threeds', 'billingCountry'));

                initialize3DS(chargeAmount, lastFour, clientTransactionId);
            }
        }
    });
});
