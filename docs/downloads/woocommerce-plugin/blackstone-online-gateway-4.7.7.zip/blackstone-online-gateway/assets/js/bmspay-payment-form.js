jQuery(document).ready(function($) {
    function toggleSaveCard() {
        var selectedToken = $('input[name="wc-saved-payment-token"]:checked').val();
        if (selectedToken === 'new') {
            $('#save-card-wrapper').show();
        } else {
            $('#save-card-wrapper').hide();
        }
    }

    function toggleNewPaymentMethod() {
        var selectedToken = $('input[name="wc-saved-payment-token"]:checked').val();
        if (selectedToken === 'new') {
            $('#new-payment-method').slideDown();
        } else {
            $('#new-payment-method').slideUp();
        }
    }

    toggleSaveCard();
    toggleNewPaymentMethod();

    $('input[name="wc-saved-payment-token"]').change(function() {
        toggleSaveCard();
        toggleNewPaymentMethod();
    });
});
