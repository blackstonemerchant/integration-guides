jQuery(document).ready(function($) {
    // Find the debug checkbox
    var $debugRow = $('input[name^="bmspay_blackstone_payment"][name$="-debug"]').closest('tr');
    
    if ($debugRow.length === 0) {
        $debugRow = $('tr:has(input[type="checkbox"]:visible)').filter(function() {
            return $(this).text().indexOf('Debug Log') !== -1;
        });
    }

    if ($debugRow.length > 0) {
        // Add clear logs button - positioned like WooCommerce buttons
        var clearLogsBtn = $('<button type="button" class="button bmspay-clear-logs">' + bmspay_admin_params.clear_logs_btn_text + '</button>');
        
        // Create proper table row structure like WooCommerce
        var newRow = $('<tr class="bmspay-clear-logs-row">');
        newRow.append('<th scope="row" class="titledesc" style="visibility:hidden;"></th>');
        newRow.append(
            $('<td class="forminp forminp-button">').append(clearLogsBtn)
        );
        
        $debugRow.after(newRow);

        // Handle click
        clearLogsBtn.on('click', function(e) {
            e.preventDefault();

            if (!confirm(bmspay_admin_params.clear_logs_confirm)) {
                return;
            }

            var $btn = $(this);
            var originalText = $btn.text();
            $btn.prop('disabled', true).text(bmspay_admin_params.clear_logs_text);

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'bmspay_clear_logs',
                    nonce: bmspay_admin_params.clear_logs_nonce
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    } else {
                        alert(response.data.message);
                    }
                },
                error: function() {
                    alert(bmspay_admin_params.clear_logs_error);
                },
                complete: function() {
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        });
    }
});