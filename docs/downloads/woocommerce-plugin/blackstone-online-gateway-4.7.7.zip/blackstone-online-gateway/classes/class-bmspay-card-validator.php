<?php
/**
 * Card Validation Service
 *
 * Handles validation of credit card data.
 *
 * @package Blackstone_Online_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bmspay_Card_Validator class.
 */
class Bmspay_Card_Validator {

	/**
	 * Validate card number using Luhn algorithm.
	 *
	 * @param string $card_number Card number.
	 * @return bool
	 */
	public function is_valid_number( string $card_number ): bool {
		$card_number = preg_replace( '/\D/', '', $card_number );

		if ( strlen( $card_number ) < 13 || strlen( $card_number ) > 19 ) {
			return false;
		}

		return $this->luhn_check( $card_number );
	}

	/**
	 * Luhn algorithm for card number validation.
	 *
	 * @param string $number Card number.
	 * @return bool
	 */
	protected function luhn_check( string $number ): bool {
		$digits    = str_split( $number );
		$odd_digit = false;
		$total     = 0;

		foreach ( array_reverse( $digits ) as $digit ) {
			if ( $odd_digit ) {
				$digit *= 2;
				if ( $digit > 9 ) {
					$digit -= 9;
				}
			}
			$total     += $digit;
			$odd_digit  = ! $odd_digit;
		}

		return 0 === ( $total % 10 );
	}

	/**
	 * Validate card expiry date.
	 *
	 * @param string $expiry Expiry date (MM/YY or MM/YYYY).
	 * @return bool
	 */
	public function is_valid_expiry( string $expiry ): bool {
		$expiry = sanitize_text_field( trim( $expiry ) );

		if ( ! preg_match( '/^(0[1-9]|1[0-2])\s*\/\s*([0-9]{2}|[0-9]{4})$/', $expiry ) ) {
			return false;
		}

		$parts = preg_split( '/\s*\/\s*/', $expiry );

		if ( count( $parts ) < 2 ) {
			return false;
		}

		$month = (int) trim( $parts[0] );
		$year  = (int) trim( $parts[1] );

		if ( 100 > $year ) {
			$year += 2000;
		}

		$now = new DateTime();

		$last_day = (int) date( 't', mktime( 0, 0, 0, $month, 1, $year ) );
		$expiry_date = DateTime::createFromFormat( 'Y-m-d', sprintf( '%d-%02d-%02d', $year, $month, $last_day ) );

		if ( ! $expiry_date ) {
			return false;
		}

		return $expiry_date >= $now->setTime( 0, 0, 0 );
	}

	/**
	 * Validate card CVC.
	 *
	 * @param string $cvc Card security code.
	 * @return bool
	 */
	public function is_valid_cvc( string $cvc ): bool {
		$cvc = preg_replace( '/\D/', '', $cvc );

		return 3 === strlen( $cvc ) || 4 === strlen( $cvc );
	}
}
