<?php
/**
 * Blackstone Logger
 *
 * File-based logger that appends entries to the log file.
 * Writes to the same WC log directory so entries appear in WC admin.
 *
 * @package Blackstone_Online_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bmspay_Logger class.
 */
class Bmspay_Logger {

	/**
	 * Write a log entry, appending it to the log file.
	 *
	 * @param string $level   Log level (debug, info, warning, error).
	 * @param string $message Log message.
	 * @param string $source  Log file source/name.
	 * @return void
	 */
	public static function log( string $level, string $message, string $source = 'bmspay-gateway' ): void {
		$log_dir = self::get_log_dir();

		if ( ! $log_dir ) {
			error_log( '[BMSPAY ' . strtoupper( $level ) . '] ' . $message );
			return;
		}

		$file = self::get_log_file( $log_dir, $source );

		$timestamp = current_time( 'c' );
		$entry     = $timestamp . ' ' . strtoupper( $level ) . ' ' . $message . "\n";

		self::append_to_file( $file, $entry );
	}

	/**
	 * Log debug message (only when WC debug logging is enabled).
	 *
	 * @param string $message Log message.
	 * @param string $source  Log source.
	 * @return void
	 */
	public static function debug( string $message, string $source = 'bmspay-gateway' ): void {
		if ( ! self::is_debug_enabled() ) {
			return;
		}
		self::log( 'debug', $message, $source );
	}

	/**
	 * Log info message (only when WC debug logging is enabled).
	 *
	 * @param string $message Log message.
	 * @param string $source  Log source.
	 * @return void
	 */
	public static function info( string $message, string $source = 'bmspay-gateway' ): void {
		if ( ! self::is_debug_enabled() ) {
			return;
		}
		self::log( 'info', $message, $source );
	}

	/**
	 * Log warning message (always written, regardless of debug setting).
	 *
	 * @param string $message Log message.
	 * @param string $source  Log source.
	 * @return void
	 */
	public static function warning( string $message, string $source = 'bmspay-gateway' ): void {
		self::log( 'warning', $message, $source );
	}

	/**
	 * Log error message (always written, regardless of debug setting).
	 *
	 * @param string $message Log message.
	 * @param string $source  Log source.
	 * @return void
	 */
	public static function error( string $message, string $source = 'bmspay-gateway' ): void {
		self::log( 'error', $message, $source );
	}

	/**
	 * Get WC log directory path.
	 *
	 * @return string|null
	 */
	private static function get_log_dir(): ?string {
		if ( function_exists( 'wc_get_log_file_path' ) ) {
			$sample = wc_get_log_file_path( 'bmspay' );
			return dirname( $sample );
		}

		$upload_dir = wp_upload_dir();
		$log_dir    = trailingslashit( $upload_dir['basedir'] ) . 'wc-logs';

		if ( is_dir( $log_dir ) ) {
			return $log_dir;
		}

		return null;
	}

	/**
	 * Build log file path, matching WC's naming convention.
	 * Format: {source}-{Y-m-d}-{hash}.log
	 *
	 * @param string $log_dir Base log directory.
	 * @param string $source  Log source name.
	 * @return string Full file path.
	 */
	private static function get_log_file( string $log_dir, string $source ): string {
		// Match WC's hash so we write to the same file WC would use for this source.
		$hash = sanitize_file_name( wp_hash( $source ) );
		$date = gmdate( 'Y-m-d' );
		$file = trailingslashit( $log_dir ) . $source . '-' . $date . '-' . $hash . '.log';
		return $file;
	}

	/**
	 * Append a log entry to a file.
	 *
	 * @param string $file  Full path to log file.
	 * @param string $entry Log entry string to append.
	 * @return void
	 */
	private static function append_to_file( string $file, string $entry ): void {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		$fp = fopen( $file, 'a' );
		if ( ! $fp ) {
			return;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		fwrite( $fp, $entry );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		fclose( $fp );
	}

	/**
	 * Check if plugin debug logging is enabled (reads gateway setting).
	 *
	 * @return bool
	 */
	private static function is_debug_enabled(): bool {
		$settings = get_option( 'woocommerce_bmspay_blackstone_payment_settings', array() );
		return isset( $settings['debug'] ) && $settings['debug'] === 'yes';
	}
}
