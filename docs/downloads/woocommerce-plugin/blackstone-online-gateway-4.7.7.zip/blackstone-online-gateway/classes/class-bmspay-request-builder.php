<?php
/**
 * Blackstone Request Builder
 *
 * Builds API request payloads for Blackstone transactions.
 *
 * @package Blackstone_Online_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bmspay_Request_Builder class.
 *
 * 
 */
class Bmspay_Request_Builder {

	/**
	 * Gateway instance.
	 *
	 * @var BMSPay_Blackstone_Payment
	 */
	private BMSPay_Blackstone_Payment $gateway;

	/**
	 * Credential manager instance.
	 *
	 * @var Bmspay_Credential_Manager
	 */
	private Bmspay_Credential_Manager $credential_manager;

	/**
	 * Card validator instance.
	 *
	 * @var Bmspay_Card_Validator
	 */
	private Bmspay_Card_Validator $card_validator;

	/**
	 * Constructor.
	 *
	 *
	 * @param BMSPay_Blackstone_Payment $gateway Gateway instance.
	 */
	public function __construct( BMSPay_Blackstone_Payment $gateway ) {
		$this->gateway           = $gateway;
		$this->credential_manager = new Bmspay_Credential_Manager( $gateway );
		$this->card_validator    = new Bmspay_Card_Validator();
	}

	/**
	 * Build sale payload for card payment.
	 *
	 *
	 * @param WC_Order $order Order object.
	 * @param array    $charge_breakdown Charge breakdown array.
	 * @param string   $secure_data 3DS secure data.
	 * @param string   $secure_transaction_id 3DS transaction ID.
	 * @return array
	 */
	public function build_sale_payload( WC_Order $order, array $charge_breakdown, string $secure_data = '', string $secure_transaction_id = '' ): array {
		$credentials = $this->credential_manager->get_credentials();

		$payload = array(
			'UserName'              => $credentials['UserName'],
			'Password'              => $credentials['Password'],
			'mid'                   => $credentials['mid'],
			'cid'                   => $credentials['cid'],
			'AppKey'                => $credentials['AppKey'],
			'AppType'               => $credentials['AppType'],
			'Amount'                => $this->format_amount( $charge_breakdown['base_amount'] ),
			'TaxAmount'             => 0,
			'TipAmount'             => 0,
			'SurchargeAmount'       => $this->format_amount( $charge_breakdown['surcharge_amount'] ),
			'CardDifferenceAmount'  => $this->format_amount( $charge_breakdown['card_difference_amount'] ),
			'TransactionType'       => Bmspay_Constants::TRANSACTION_TYPES['sale'],
			'Track2'               => '',
			'ZipCode'               => $this->get_zip_code(),
			'ExpDate'               => $this->get_card_expiry(),
			'CardNumber'            => $this->get_card_number(),
			'CVN'                   => $this->get_card_cvv(),
			'NameOnCard'            => $this->get_full_name( $order ),
			'UserTransactionNumber' => $this->generate_transaction_id( $order ),
			'Source'                => Bmspay_Constants::SOURCE,
			'SecureData'            => $secure_data,
			'PosCode'               => Bmspay_Constants::POS_CODE,
			'SecureTransactionId'   => $secure_transaction_id,
			'SaveToken'             => 'True',

			'x_first_name'         => $order->get_billing_first_name(),
			'x_last_name'          => $order->get_billing_last_name(),
			'x_address'            => $order->get_billing_address_1(),
			'x_city'               => $order->get_billing_city(),
			'x_state'              => $order->get_billing_state(),
			'x_zip'                => $order->get_billing_postcode(),
			'x_country'            => $order->get_billing_country(),
			'x_phone'              => $order->get_billing_phone(),
			'x_email'              => $order->get_billing_email(),

			'SaveCustomer'          => 'True',
			'IsTest'               => $credentials['UserTest'],
			'CustomerId'           => $order->get_id(),
			'CustomerPhone'        => $order->get_billing_phone(),
			'CustomerEmail'        => $order->get_billing_email(),
			'CustomerCountry'      => $order->get_billing_country(),
			'CustomerState'        => $order->get_billing_state(),
			'CustomerCity'         => $order->get_billing_city(),
			'CustomerAddress'      => $order->get_billing_address_1(),
			'OrderReference'       => $order->get_id(),

			'x_ship_to_first_name' => $order->get_shipping_first_name(),
			'x_ship_to_last_name'  => $order->get_shipping_last_name(),
			'x_ship_to_company'     => $order->get_shipping_company(),
			'x_ship_to_address'    => $order->get_shipping_address_1(),
			'x_ship_to_city'       => $order->get_shipping_city(),
			'x_ship_to_country'    => $order->get_shipping_country(),
			'x_ship_to_state'      => $order->get_shipping_state(),
			'x_ship_to_zip'        => $order->get_shipping_postcode(),
			'x_cust_id'            => $order->get_user_id(),
			'x_customer_ip'        => $this->credential_manager->get_remote_ip(),
		);

		return $payload;
	}

	/**
	 * Build token sale payload for saved card payment.
	 *
	 * 
	 * @param WC_Order $order Order object.
	 * @param string   $token Payment token.
	 * @param array    $charge_breakdown Charge breakdown array.
	 * @param string   $secure_data 3DS secure data.
	 * @param string   $secure_transaction_id 3DS transaction ID.
	 * @return array
	 */
	public function build_token_sale_payload( WC_Order $order, string $token, array $charge_breakdown, string $secure_data = '', string $secure_transaction_id = '' ): array {
		$credentials = $this->credential_manager->get_credentials();

		$payload = array(
			'Token'                 => $token,
			'UserName'              => $credentials['UserName'],
			'Password'              => $credentials['Password'],
			'mid'                   => $credentials['mid'],
			'cid'                   => $credentials['cid'],
			'AppKey'                => $credentials['AppKey'],
			'AppType'               => $credentials['AppType'],
			'Amount'                => $this->format_amount( $charge_breakdown['base_amount'] ),
			'TaxAmount'             => 0,
			'TipAmount'             => 0,
			'SurchargeAmount'       => $this->format_amount( $charge_breakdown['surcharge_amount'] ),
			'CardDifferenceAmount'  => $this->format_amount( $charge_breakdown['card_difference_amount'] ),
			'TransactionType'       => Bmspay_Constants::TRANSACTION_TYPES['sale_with_token'],
			'Track2'               => '',
			'ZipCode'               => $order->get_billing_postcode(),
			'ExpDate'               => '',
			'NameOnCard'            => $this->get_full_name( $order ),
			'UserTransactionNumber' => $this->generate_transaction_id( $order ),
			'Source'                => Bmspay_Constants::SOURCE,
			'SecureData'            => $secure_data,
			'PosCode'               => Bmspay_Constants::POS_CODE,
			'SecureTransactionId'   => $secure_transaction_id,

			'x_first_name'         => $order->get_billing_first_name(),
			'x_last_name'          => $order->get_billing_last_name(),
			'x_address'            => $order->get_billing_address_1(),
			'x_city'               => $order->get_billing_city(),
			'x_state'              => $order->get_billing_state(),
			'x_zip'                => $order->get_billing_postcode(),
			'x_country'            => $order->get_billing_country(),
			'x_phone'              => $order->get_billing_phone(),
			'x_email'              => $order->get_billing_email(),

			'SaveCustomer'          => 'True',
			'IsTest'               => $credentials['UserTest'],
			'CustomerId'           => $order->get_id(),
			'CustomerPhone'        => $order->get_billing_phone(),
			'CustomerEmail'        => $order->get_billing_email(),
			'CustomerCountry'      => $order->get_billing_country(),
			'CustomerState'        => $order->get_billing_state(),
			'CustomerCity'         => $order->get_billing_city(),
			'CustomerAddress'      => $order->get_billing_address_1(),
			'OrderReference'       => $order->get_id(),

			'x_ship_to_first_name' => $order->get_shipping_first_name(),
			'x_ship_to_last_name'  => $order->get_shipping_last_name(),
			'x_ship_to_company'     => $order->get_shipping_company(),
			'x_ship_to_address'    => $order->get_shipping_address_1(),
			'x_ship_to_city'       => $order->get_shipping_city(),
			'x_ship_to_country'    => $order->get_shipping_country(),
			'x_ship_to_state'      => $order->get_shipping_state(),
			'x_ship_to_zip'        => $order->get_shipping_postcode(),
			'x_cust_id'            => $order->get_user_id(),
			'x_customer_ip'        => $this->credential_manager->get_remote_ip(),
		);

		return $payload;
	}

/**
	 * Build refund payload.
	 *
	 * 
	 * @param float        $amount Refund amount.
	 * @param string       $service_reference Service reference number.
	 * @param WC_Order|null $order Order object.
	 * @return array
	 */
	public function build_refund_payload( float $amount, string $service_reference, ?WC_Order $order = null ): array {
		$credentials = $this->credential_manager->get_credentials();

		$payload = array(
			'Amount'                  => $this->format_amount( $amount ),
			'TrackData'               => '',
			'UserTransactionNumber'   => $this->generate_refund_transaction_id( $service_reference ),
			'ServiceTransactionNumber' => $service_reference,
			'SURI'                    => '',
			'AppKey'                  => $credentials['AppKey'],
			'AppType'                 => $credentials['AppType'],
			'mid'                     => $credentials['mid'],
			'cid'                     => $credentials['cid'],
			'UserName'                => $credentials['UserName'],
			'Password'                => $credentials['Password'],
			'IpAddress'               => $this->credential_manager->get_remote_ip(),
			'IsTest'                  => $credentials['UserTest'],
		);

		return $payload;
	}

	/**
	 * Format amount for API.
	 *
	 * 
	 * @param float $amount Amount to format.
	 * @return string
	 */
	private function format_amount( float $amount ): string {
		return number_format( (float) $amount, 2, '.', '' );
	}

	/**
	 * Get zip code from POST or default.
	 *
	 * 
	 * @return string
	 */
	private function get_zip_code(): string {
		$post_key = 'bmspay_blackstone_payment-card-postcode';
		$zip_code = isset( $_POST[ $post_key ] )
			? sanitize_text_field( wp_unslash( $_POST[ $post_key ] ) )
			: '';

		if ( empty( $zip_code ) && isset( WC()->customer ) && method_exists( WC()->customer, 'get_billing_postcode' ) ) {
			$zip_code = WC()->customer->get_billing_postcode();
		}

		return $zip_code;
	}

	/**
	 * Get card expiry from POST.
	 *
	 *
	 * @return string
	 */
	private function get_card_expiry(): string {
		$post_key = 'bmspay_blackstone_payment-card-expiry';
		if ( ! isset( $_POST[ $post_key ] ) ) {
			return '';
		}

		$expiry = sanitize_text_field( wp_unslash( $_POST[ $post_key ] ) );
		return str_replace( array( '/', ' ' ), '', $expiry );
	}

	/**
	 * Get card number from POST.
	 *
	 * 
	 * @return string
	 */
	private function get_card_number(): string {
		$post_key = 'bmspay_blackstone_payment-card-number';
		if ( ! isset( $_POST[ $post_key ] ) ) {
			return '';
		}

		$number = sanitize_text_field( wp_unslash( $_POST[ $post_key ] ) );
		return str_replace( array( ' ', '-' ), '', $number );
	}

	/**
	 * Get card CVV from POST.
	 *
	 * 
	 * @return string
	 */
	private function get_card_cvv(): string {
		$post_key = 'bmspay_blackstone_payment-card-cvc';
		return isset( $_POST[ $post_key ] )
			? sanitize_text_field( wp_unslash( $_POST[ $post_key ] ) )
			: '';
	}

	/**
	 * Get customer's full name from order.
	 *
	 * 
	 * @param WC_Order $order Order object.
	 * @return string
	 */
	private function get_full_name( WC_Order $order ): string {
		return $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
	}

	/**
	 * Generate unique transaction ID.
	 *
	 *
	 * @param WC_Order $order Order object.
	 * @return string
	 */
	private function generate_transaction_id( WC_Order $order ): string {
		$order_id    = $order->get_id();
		$timestamp   = time();
		$random      = bin2hex( random_bytes( 8 ) );

		return sprintf( 'ord_%d_%d_%s', $order_id, $timestamp, $random );
	}

	/**
	 * Generate unique refund transaction ID.
	 *
	 *
	 * @param string $service_reference Service reference number.
	 * @return string
	 */
	private function generate_refund_transaction_id( string $service_reference ): string {
		$timestamp = time();
		$random    = bin2hex( random_bytes( 8 ) );

		return sprintf( 'ref_%s_%d_%s', substr( $service_reference, 0, 8 ), $timestamp, $random );
	}
}
