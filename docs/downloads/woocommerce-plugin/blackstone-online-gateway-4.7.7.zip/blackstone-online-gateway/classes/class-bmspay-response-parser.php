<?php
/**
 * Blackstone Response Parser
 *
 * Handles parsing and interpretation of Blackstone API responses.
 *
 * @package Blackstone_Online_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bmspay_Response_Parser class.
 *
 * 
 */
class Bmspay_Response_Parser {

	/**
	 * Parse WordPress HTTP response.
	 *
	 * 
	 * @param array|WP_Error $response HTTP response or error.
	 * @return array
	 */
	public function parse_wp_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			return $this->error_result(
				__( 'There is issue for connecting payment gateway. Sorry for the inconvenience.', 'blackstone-online-gateway' )
			);
		}

		$body = wp_remote_retrieve_body( $response );

		if ( empty( $body ) ) {
			return $this->error_result(
				__( "Blackstone's Response was not get any data.", 'blackstone-online-gateway' )
			);
		}

		$data = json_decode( $body, true );

		if ( ! is_array( $data ) ) {
			return $this->error_result(
				__( 'Invalid response from payment gateway.', 'blackstone-online-gateway' )
			);
		}

		return $this->parse_response_data( $data );
	}

	/**
	 * Parse response data array.
	 *
	 * 
	 * @param array $data Response data.
	 * @return array
	 */
	public function parse_response_data( array $data ): array {
		$response_code = isset( $data['ResponseCode'] ) ? (string) $data['ResponseCode'] : '';

		if ( Bmspay_Constants::is_success_code( $response_code ) ) {
			return $this->success_result( $data );
		}

		return $this->error_result_from_data( $data );
	}

	/**
	 * Parse merchant settings response.
	 *
	 * 
	 * @param array $data Response data.
	 * @return array
	 */
	public function parse_merchant_settings( array $data ): array {
		$surcharge_enabled       = false;
		$surcharge_percent       = 0;
		$card_difference_enabled = false;
		$card_difference_percent = 0;
		$threed_secure_enabled   = false;

		if ( isset( $data['SurchargeEnabled'] ) && $data['SurchargeEnabled'] === true ) {
			$surcharge_enabled   = true;
			$surcharge_percent   = isset( $data['SurchargePercent'] ) ? $data['SurchargePercent'] : 0;
		}

		if ( isset( $data['CardDifferenceEnabled'] ) && $data['CardDifferenceEnabled'] === true ) {
			$card_difference_enabled = true;
			$card_difference_percent = isset( $data['CardDifferencePercent'] )
				? $data['CardDifferencePercent']
				: 0;
		}

		if ( isset( $data['ThreeDSecureEnabled'] ) && $data['ThreeDSecureEnabled'] === true ) {
			$threed_secure_enabled = true;
		}

		return array(
			'response_SurchargeEnabled'        => $surcharge_enabled,
			'response_SurchargePercent'        => $surcharge_percent,
			'response_CardDifferenceEnabled'   => $card_difference_enabled,
			'response_CardDifferencePercent'   => $card_difference_percent,
			'response_ThreeDSecureEnabled'     => $threed_secure_enabled,
			'response_ApiAvailable'            => true,
		);
	}

	/**
	 * Parse 3D Secure response from JSON string.
	 *
	 * 
	 * @param string $json_string JSON response string.
	 * @return array
	 */
	public function parse_3ds_response( string $json_string ): array {
		if ( empty( $json_string ) ) {
			return $this->error_result_3ds(
				__( 'No 3DS response received.', 'blackstone-online-gateway' )
			);
		}

		$data = json_decode( $json_string, true );

		if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $data ) ) {
			$json_error = json_last_error_msg();
			return $this->error_result_3ds(
				sprintf(
					__( 'Invalid 3DS response data. JSON error: %s', 'blackstone-online-gateway' ),
					$json_error
				)
			);
		}

		return $this->parse_3ds_data( $data );
	}

	/**
	 * Parse 3D Secure data array.
	 *
	 * 
	 * @param array $data 3DS response data.
	 * @return array
	 */
	public function parse_3ds_data( array $data ): array {
		$status = isset( $data['status'] ) ? $data['status'] : null;

		if ( empty( $status ) ) {
			return $this->error_result_3ds(
				__( '3DS response missing status.', 'blackstone-online-gateway' )
			);
		}

		if ( Bmspay_Constants::is_3ds_success( $status ) ) {
			return $this->success_result_3ds( $data );
		}

		if ( Bmspay_Constants::is_3ds_failure( $status ) ) {
			return $this->error_result_3ds( $this->get_3ds_error_message( $status, $data ) );
		}

		return $this->error_result_3ds(
			__( '3DS verification failed. Please try again or use a different payment method.', 'blackstone-online-gateway' )
		);
	}

	/**
	 * Check if response indicates success.
	 *
	 * 
	 * @param array $data Response data.
	 * @return bool
	 */
	public function is_success( array $data ): bool {
		$response_code = isset( $data['ResponseCode'] ) ? (string) $data['ResponseCode'] : '';
		return Bmspay_Constants::is_success_code( $response_code );
	}

	/**
	 * Check if refund response indicates success.
	 *
	 * 
	 * @param array $data Response data.
	 * @return bool
	 */
	public function is_refund_success( array $data ): bool {
		$response_code = isset( $data['ResponseCode'] ) ? (string) $data['ResponseCode'] : '';
		$phard_code   = isset( $data['phard_code'] ) ? strtoupper( $data['phard_code'] ) : '';

		if ( Bmspay_Constants::is_success_code( $response_code ) ) {
			return true;
		}

		if ( $phard_code === 'SUCCESS' ) {
			return true;
		}

		return false;
	}

	/**
	 * Get user-friendly message from response.
	 *
	 * 
	 * @param array $data Response data.
	 * @return string
	 */
	public function get_user_message( array $data ): string {
		$response_code = isset( $data['ResponseCode'] ) ? (string) $data['ResponseCode'] : '';

		if ( ! empty( Bmspay_Constants::RESPONSE_CODES[ $response_code ] ) ) {
			return Bmspay_Constants::RESPONSE_CODES[ $response_code ];
		}

		$msg = '';

		if ( isset( $data['Msg'] ) ) {
			if ( is_array( $data['Msg'] ) && ! empty( $data['Msg'][0] ) ) {
				$msg = $data['Msg'][0];
			} elseif ( is_string( $data['Msg'] ) && ! empty( $data['Msg'] ) ) {
				$msg = $data['Msg'];
			}
		}

		if ( ! empty( $msg ) ) {
			return $msg;
		}

		$response_msg = isset( $data['ResponseMessage'] ) ? $data['ResponseMessage'] : '';
		if ( ! empty( $response_msg ) ) {
			return $response_msg;
		}

		return __( 'Payment failed. Please try again or contact support.', 'blackstone-online-gateway' );
	}

	/**
	 * Get full error details string.
	 *
	 * 
	 * @param array  $data Response data.
	 * @param string $user_transaction_number Transaction reference.
	 * @return string
	 */
	public function get_full_error_details( array $data, string $user_transaction_number ): string {
		$response_code = isset( $data['ResponseCode'] )
			? $data['ResponseCode']
			: 'unknown';
		$avs = isset( $data['avs'] )
			? $data['avs']
			: __( 'Not verified', 'blackstone-online-gateway' );
		$cv  = isset( $data['cv'] )
			? $data['cv']
			: __( 'Not verified', 'blackstone-online-gateway' );

		return sprintf(
			__( 'Error code: %1$s | Address verification: %2$s | CVV verification: %3$s | Ref: %4$s', 'blackstone-online-gateway' ),
			$response_code,
			$avs,
			$cv,
			$user_transaction_number
		);
	}

	/**
	 * Build success result array.
	 *
	 * 
	 * @param array $data Response data.
	 * @return array
	 */
	private function success_result( $data ): array {
		return array(
			'success'                  => true,
			'response_code'            => '200',
			'service_reference_number' => isset( $data['ServiceReferenceNumber'] )
				? $data['ServiceReferenceNumber']
				: '',
			'user_transaction_number'  => isset( $data['UserTransactionNumber'] )
				? $data['UserTransactionNumber']
				: '',
			'token'                    => isset( $data['Token'] )
				? $data['Token']
				: '',
			'last_four'                => isset( $data['LastFour'] )
				? $data['LastFour']
				: '',
			'card_type'                => isset( $data['CardType'] )
				? $data['CardType']
				: '',
			'raw_response'             => $data,
		);
	}

	/**
	 * Build error result array.
	 *
	 * 
	 * @param string $message Error message.
	 * @return array
	 */
	private function error_result( string $message ): array {
		return array(
			'success'       => false,
			'response_code' => 'unknown',
			'message'       => $message,
		);
	}

	/**
	 * Build error result from response data.
	 *
	 * 
	 * @param array $data Response data.
	 * @return array
	 */
	private function error_result_from_data( array $data ): array {
		$response_code = isset( $data['ResponseCode'] ) ? (string) $data['ResponseCode'] : 'unknown';

		$msg = '';
		if ( isset( $data['Msg'] ) ) {
			if ( is_array( $data['Msg'] ) && ! empty( $data['Msg'][0] ) ) {
				$msg = $data['Msg'][0];
			} elseif ( is_string( $data['Msg'] ) && ! empty( $data['Msg'] ) ) {
				$msg = $data['Msg'];
			}
		}

		$verbiage     = isset( $data['verbiage'] ) ? $data['verbiage'] : '';
		$response_msg = isset( $data['ResponseMessage'] ) ? $data['ResponseMessage'] : '';

		$user_msg = $this->get_user_message( $data );

		if ( ! empty( $verbiage ) && $verbiage !== $msg ) {
			$user_msg .= ' (' . $verbiage . ')';
		}

		return array(
			'success'       => false,
			'response_code' => $response_code,
			'message'       => $user_msg,
			'raw_message'   => $msg ?: $response_msg,
			'verbiage'      => $verbiage,
		);
	}

	/**
	 * Build 3DS success result array.
	 *
	 * 
	 * @param array $data 3DS response data.
	 * @return array
	 */
	private function success_result_3ds( array $data ): array {
		$auth_value = isset( $data['authenticationValue'] ) ? sanitize_text_field( $data['authenticationValue'] ) : '';
		$trans_id = isset( $data['threeDsTransactionId'] ) ? sanitize_text_field( $data['threeDsTransactionId'] ) : '';

		if ( empty( $auth_value ) || empty( $trans_id ) ) {
			return $this->error_result_3ds(
				__( 'Invalid 3DS authentication data received.', 'blackstone-online-gateway' )
			);
		}

		if ( strlen( $auth_value ) > 512 || strlen( $trans_id ) > 128 ) {
			return $this->error_result_3ds(
				__( '3DS authentication data exceeds expected length.', 'blackstone-online-gateway' )
			);
		}

		return array(
			'success'              => true,
			'message'              => $this->get_3ds_status_message( $data['status'] ),
			'authentication_value' => $auth_value,
			'transaction_id'       => $trans_id,
		);
	}

	/**
	 * Build 3DS error result array.
	 *
	 * 
	 * @param string $message Error message.
	 * @return array
	 */
	private function error_result_3ds( string $message ): array {
		return array(
			'success' => false,
			'message' => $message,
		);
	}

	/**
	 * Get 3DS status message.
	 *
	 * 
	 * @param string $status 3DS status.
	 * @return string
	 */
	private function get_3ds_status_message( string $status ): string {
		if ( isset( Bmspay_Constants::THREE_DS_STATUS_MESSAGES[ $status ] ) ) {
			return Bmspay_Constants::THREE_DS_STATUS_MESSAGES[ $status ];
		}

		return $this->get_default_3ds_error_message();
	}

	/**
	 * Get 3DS error message with optional reason.
	 *
	 * 
	 * @param string $status 3DS status.
	 * @param array  $data Response data.
	 * @return string
	 */
	private function get_3ds_error_message( string $status, array $data ): string {
		$base_message = $this->get_3ds_status_message( $status );
		$reason = isset( $data['transStatusReasonDetail'] )
			? $data['transStatusReasonDetail']
			: '';

		if ( ! empty( $reason ) ) {
			return $base_message . '. Reason: ' . $reason;
		}

		return $base_message;
	}

	/**
	 * Get default 3DS error message based on locale.
	 *
	 * 
	 * @return string
	 */
	private function get_default_3ds_error_message(): string {
		$locale = get_locale();

		if ( strpos( $locale, 'es' ) === 0 ) {
			return 'No se pudo completar la verificación de su método de pago. Intente nuevamente o use otro método';
		}

		return 'The verification of your payment method could not be completed. Please try again or use a different method.';
	}
}
