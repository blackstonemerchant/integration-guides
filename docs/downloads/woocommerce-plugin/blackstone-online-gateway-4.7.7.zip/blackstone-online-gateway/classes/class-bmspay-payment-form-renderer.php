<?php
/**
 * Payment Form Renderer
 *
 * Handles rendering of the payment form at checkout.
 *
 * @package Blackstone_Online_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bmspay_Payment_Form_Renderer class.
 */
class Bmspay_Payment_Form_Renderer {

	/**
	 * Gateway instance.
	 *
	 * @var BMSPay_Blackstone_Payment
	 */
	private BMSPay_Blackstone_Payment $gateway;

	/**
	 * Constructor.
	 *
	 * @param BMSPay_Blackstone_Payment $gateway Gateway instance.
	 */
	public function __construct( BMSPay_Blackstone_Payment $gateway ) {
		$this->gateway = $gateway;
	}

	/**
	 * Render the payment form.
	 *
	 * @return void
	 */
	public function render(): void {
		if ( $this->gateway->enabled !== 'yes' ) {
			return;
		}

		$this->render_saved_payment_methods();
		$this->render_new_payment_method();
	}

	/**
	 * Render saved payment methods.
	 *
	 * @return void
	 */
	private function render_saved_payment_methods(): void {
		$user_id       = get_current_user_id();
		$all_tokens    = WC_Payment_Tokens::get_customer_tokens( $user_id );
		$saved_methods = array();

		foreach ( $all_tokens as $token ) {
			$token_gateway_id = method_exists( $token, 'get_gateway_id' ) ? $token->get_gateway_id() : '';
			if ( $token_gateway_id === $this->gateway->id ) {
				$saved_methods[] = $token;
			}
		}

		echo '<div id="saved-payment-methods" class="payment-methods-container">';

		if ( $saved_methods ) {
			echo '<p class="payment-methods-title">' . esc_html__( 'Select a saved card:', 'blackstone-online-gateway' ) . '</p>';
			echo '<ul class="wc-saved-payment-methods">';

			foreach ( $saved_methods as $token ) {
				$last4    = $token->get_last4();
				$token_id = $token->get_id();

				echo '<li class="payment-option">';
				echo '<input type="radio" id="token-' . esc_attr( $token_id ) . '" name="wc-saved-payment-token" value="' . esc_attr( $token_id ) . '" />';
				echo '<label for="token-' . esc_attr( $token_id ) . '" class="payment-label">';
				echo '<span class="card-icon" aria-hidden="true">&#x1F4B3;</span> ';
				echo esc_html__( 'Card ending in:', 'blackstone-online-gateway' ) . ' ' . esc_html( $last4 );
				echo '</label>';
				echo '</li>';
			}

			echo '</ul>';
		} else {
			echo '<p class="no-saved-methods">' . esc_html__( 'You do not have saved payment methods', 'blackstone-online-gateway' ) . '</p>';
		}

		$this->render_new_card_option();

		echo '</div>';
	}

	/**
	 * Render "use new card" option.
	 *
	 * @return void
	 */
	private function render_new_card_option(): void {
		echo '<ul class="wc-saved-payment-methods">';
		echo '<li class="payment-option">';
		echo '<input type="radio" id="token-new" name="wc-saved-payment-token" value="new" checked />';
		echo '<label for="token-new" class="payment-label">';
		echo '<span class="card-icon" aria-hidden="true">💳</span> ' . esc_html__( 'Use a new payment method', 'blackstone-online-gateway' );
		echo '</label>';
		echo '</li>';
		echo '</ul>';
	}

	/**
	 * Render new payment method section.
	 *
	 * @return void
	 */
	private function render_new_payment_method(): void {
		echo '<div id="new-payment-method" class="new-payment-method-section">';
		echo '<p class="new-payment-title">' . esc_html__( 'Enter your card details:', 'blackstone-online-gateway' ) . '</p>';
		$this->gateway->form();
		$this->render_save_card_checkbox();
		echo '</div>';
	}

	/**
	 * Render save card checkbox.
	 *
	 * @return void
	 */
	private function render_save_card_checkbox(): void {
		echo '<p class="save-card-option" id="save-card-wrapper">';
		echo '<label for="save_card">';
		echo '<input type="checkbox" id="save_card" name="save_card" value="1" />';
		echo ' ' . esc_html__( 'Save this card for future purchases', 'blackstone-online-gateway' );
		echo '</label>';
		echo '</p>';
	}
}