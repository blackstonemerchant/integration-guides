<?php
/**
 * Blackstone Payment Gateway for WooCommerce
 *
 * @package Blackstone_Online_Gateway
 * @extends WC_Payment_Gateway_CC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * BMSPay_Blackstone_Payment class.
 *
 * 
 * @extends WC_Payment_Gateway_CC
 */
class BMSPay_Blackstone_Payment extends WC_Payment_Gateway_CC {

	/**
	 * API Client for communicating with Blackstone.
	 *
	 * @var Bmspay_Api_Client
	 */
	protected Bmspay_Api_Client $api_client;

	/**
	 * Request builder for constructing API payloads.
	 *
	 * @var Bmspay_Request_Builder
	 */
	protected Bmspay_Request_Builder $request_builder;

	/**
	 * Response parser for handling API responses.
	 *
	 * @var Bmspay_Response_Parser
	 */
	protected Bmspay_Response_Parser $response_parser;

	/**
	 * Card validator for payment field validation.
	 *
	 * @var Bmspay_Card_Validator
	 */
	protected Bmspay_Card_Validator $card_validator;

	/**
	 * Payment form renderer.
	 *
	 * @var Bmspay_Payment_Form_Renderer
	 */
	protected Bmspay_Payment_Form_Renderer $form_renderer;

	/**
	 * API Username.
	 *
	 * @var string
	 */
	protected string $api_username = '';

	/**
	 * API Password.
	 *
	 * @var string
	 */
	protected string $api_password = '';

	/**
	 * Merchant ID (MID).
	 *
	 * @var string
	 */
	protected string $api_mid = '';

	/**
	 * Client ID (CID).
	 *
	 * @var string
	 */
	protected string $api_cid = '';

	/**
	 * App Type.
	 *
	 * @var string
	 */
	protected string $app_type = '';

	/**
	 * App Key.
	 *
	 * @var string
	 */
	protected string $app_key = '';

	/**
	 * Environment (sandbox/production).
	 *
	 * @var string
	 */
	protected string $environment = 'no';

	/**
	 * 3DS Environment.
	 *
	 * @var string
	 */
	protected string $environment_3ds = 'no';

	/**
	 * Force 3DS in sandbox (bypass gateway API flag).
	 *
	 * @var string
	 */
	protected string $force_3ds_sandbox = 'no';

	/**
	 * Surcharge label.
	 *
	 * @var string
	 */
	protected string $label_surcharge = '';

	/**
	 * Card difference label.
	 *
	 * @var string
	 */
	protected string $label_card_difference = '';

	/**
	 * Debug mode.
	 *
	 * @var string
	 */
	protected string $debug = 'no';

	/**
	 * Constructor.
	 *
	 * 
	 */
	public function __construct() {
		$this->id                 = 'bmspay_blackstone_payment';
		$this->method_title       = __( 'Blackstone', 'blackstone-online-gateway' );
		$this->method_description = __( 'Blackstone Online Gateway Plug-in for WooCommerce', 'blackstone-online-gateway' );
		$this->title             = __( 'Blackstone', 'blackstone-online-gateway' );
		$this->icon              = null;
		$this->has_fields        = true;
		$this->supports          = array( 'default_credit_card_form' );

		$this->init_form_fields();
		$this->init_settings();

		foreach ( $this->settings as $setting_key => $value ) {
			$this->{$setting_key} = $this->sanitize_setting( $setting_key, $value );
		}

		$this->init_api_clients();

		add_action( 'admin_notices', array( $this, 'do_ssl_check' ) );
		remove_action( 'woocommerce_review_order_after_submit', 'woocommerce_order_submit_button', 10 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_assets' ) );
		add_action( 'wp_footer', array( $this, 'output_payment_toggle_script' ) );

		if ( is_admin() ) {
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		}
	}

	/**
	 * Enqueue admin scripts for settings page.
	 *
	 * 
	 * @return void
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( 'woocommerce_page_wc-settings' !== $hook ) {
			return;
		}

		if ( ! isset( $_GET['section'] ) || $_GET['section'] !== $this->id ) {
			return;
		}

		wp_enqueue_script(
			'bmspay-admin-settings',
			plugins_url( 'assets/js/bmspay-admin-settings.js', __FILE__ ),
			array( 'jquery' ),
			'1.0.0',
			true
		);

		wp_localize_script(
			'bmspay-admin-settings',
			'bmspay_admin_params',
			array(
				'clear_logs_nonce'     => wp_create_nonce( 'bmspay_clear_logs_nonce' ),
				'clear_logs_text'     => __( 'Deleting logs...', 'blackstone-online-gateway' ),
				'clear_logs_btn_text' => __( 'Delete Logs', 'blackstone-online-gateway' ),
				'clear_logs_confirm'  => __( 'Are you sure you want to delete all Blackstone plugin logs?', 'blackstone-online-gateway' ),
				'clear_logs_error'    => __( 'Error deleting logs.', 'blackstone-online-gateway' ),
			)
		);
	}

	/**
	 * Initialize API client instances.
	 *
	 * 
	 * @return void
	 */
	protected function init_api_clients() {
		$this->api_client       = new Bmspay_Api_Client( $this );
		$this->request_builder  = new Bmspay_Request_Builder( $this );
		$this->response_parser  = new Bmspay_Response_Parser();
		$this->card_validator   = new Bmspay_Card_Validator();
		$this->form_renderer    = new Bmspay_Payment_Form_Renderer( $this );
	}

	/**
	 * Initialize form fields for gateway settings.
	 *
	 * 
	 * @return void
	 */
	public function init_form_fields() {
		$this->form_fields = include __DIR__ . '/includes/settings-bmspay.php';
	}

	/**
	 * Enqueue frontend assets for checkout page.
	 *
	 * 
	 * @return void
	 */
	public function enqueue_checkout_assets() {
		if ( $this->enabled !== 'yes' ) {
			return;
		}

		if ( ! is_checkout() && ! is_wc_endpoint_url( 'order-pay' ) ) {
			return;
		}

		wp_enqueue_style(
			'bmspay-payment-form',
			plugins_url( 'assets/css/bmspay-payment-form.css', __FILE__ ),
			array(),
			'1.0.7'
		);

		wp_enqueue_style(
			'sweetalert2',
			'https://cdn.jsdelivr.net/npm/sweetalert2@11.26.24/dist/sweetalert2.min.css',
			array(),
			'11.26.24'
		);
		wp_style_add_data( 'sweetalert2', 'integrity', 'sha384-OxWqvePLOm0AAoo759Ls7uD8ysM4N0fSXEE+QUY3pkVXBtkv6jkKNsPMC0KFMxWe' );
		wp_style_add_data( 'sweetalert2', 'crossorigin', 'anonymous' );

		wp_enqueue_script(
			'bmspay-payment-form',
			plugins_url( 'assets/js/bmspay-payment-form.js', __FILE__ ),
			array( 'jquery' ),
			'1.0.7',
			true
		);

		wp_enqueue_script(
			'sweetalert2',
			'https://cdn.jsdelivr.net/npm/sweetalert2@11.26.24/dist/sweetalert2.min.js',
			array( 'jquery' ),
			'11.26.24',
			true
		);
		wp_script_add_data( 'sweetalert2', 'integrity', 'sha384-Nkb7LRzblHpSjchPwLtsgr8Ehgu63kNqniAR4kZn9VgYMnlAIYqUPYpXiZgzAKeu' );
		wp_script_add_data( 'sweetalert2', 'crossorigin', 'anonymous' );

		$this->enqueue_3ds_assets();

		wp_enqueue_script(
			'payment-method-custom',
			plugins_url( 'assets/js/payment-method-custom.js', __FILE__ ),
			array( 'jquery' ),
			'1.0.0',
			true
		);
	}

	/**
	 * Output inline script for payment method toggle.
	 *
	 * @return void
	 */
public function output_payment_toggle_script() {
		if ( ! is_checkout() ) {
			return;
		}
		?>
		<script type="text/javascript">
		(function() {
			if (typeof jQuery === 'undefined') return;
			var $ = jQuery;
			function doToggle() {
				var selected = $('input[name="wc-saved-payment-token"]:checked').val();
				if (selected === 'new') {
					$('#new-payment-method').show();
					$('#save-card-wrapper').show();
					$('#save_card_field').show();
				} else {
					$('#new-payment-method').hide();
					$('#save-card-wrapper').hide();
					$('#save_card_field').hide();
				}
			}
			setTimeout(doToggle, 100);
			$('body').on('change', 'input[name="wc-saved-payment-token"]', doToggle);
		})();
		</script>
		<?php
	}

	/**
	 * Enqueue 3D Secure assets when applicable.
	 *
	 * 
	 * @return void
	 */
	protected function enqueue_3ds_assets() {
		$surcharge_data         = $this->get_cached_surcharge_data();
		$threeds_api_enabled    = ! empty( $surcharge_data['response_ThreeDSecureEnabled'] );
		$threeds_plugin_enabled = $this->get_environment_3ds() === 'yes';
		$force_sandbox          = $this->force_3ds_sandbox === 'yes' && $this->is_test_environment();

		$this->log_debug( '3DS: API enabled=' . var_export( $threeds_api_enabled, true ) . ', Plugin enabled=' . var_export( $threeds_plugin_enabled, true ) . ', Force sandbox=' . var_export( $force_sandbox, true ) );

		if ( ! $threeds_plugin_enabled ) {
			return;
		}

		if ( ! $threeds_api_enabled && ! $force_sandbox ) {
			return;
		}

		// Cache the token in a short-lived transient to avoid an external HTTP call
		// on every checkout page update. The JWT from Blackstone expires in weeks;
		// 5 minutes is safe and eliminates the blocking call on each WC AJAX refresh.
		$token_cache_key = 'bmspay_3ds_token_' . substr( md5( $this->get_api_mid() . $this->get_api_cid() . $this->get_environment() ), 0, 12 );
		$cached          = get_transient( $token_cache_key );

		if ( $cached && ! empty( $cached['ApiKey'] ) && ! empty( $cached['Token'] ) ) {
			$api_key = $cached['ApiKey'];
			$token   = $cached['Token'];
			$this->log_debug( '3DS: api_key=' . substr( $api_key, 0, 8 ) . '... (cached)' );
		} else {
			$threed_secure_data = $this->api_client->get_threeds_token();

			if ( is_wp_error( $threed_secure_data ) ) {
				$this->log_debug( '3DS: get_threeds_token failed: ' . $threed_secure_data->get_error_message() );
				return;
			}

			$api_key = isset( $threed_secure_data['ApiKey'] ) ? $threed_secure_data['ApiKey'] : '';
			$token   = isset( $threed_secure_data['Token'] ) ? $threed_secure_data['Token'] : '';

			if ( empty( $api_key ) || empty( $token ) ) {
				$this->log_debug( '3DS: Empty api_key or token' );
				return;
			}

			set_transient( $token_cache_key, array( 'ApiKey' => $api_key, 'Token' => $token ), 5 * MINUTE_IN_SECONDS );
			$this->log_debug( '3DS: api_key=' . substr( $api_key, 0, 8 ) . '... (fetched)' );
		}

		WC()->session->set( 'threed_secure_apikey', $api_key );
		WC()->session->set( 'threed_secure_token', $token );

		wp_enqueue_script(
			'bmspay-3ds',
			'https://cdn.3dsintegrator.com/threeds.2.2.20231219.min.js',
			array(),
			null,
			true
		);
		$this->log_warning( '3DS: SRI hash should be configured for production use. See settings.' );
		$this->log_debug( '3DS: enqueued bmspay-3ds script' );

		$order_total = $this->get_order_total_for_3ds();

		wp_enqueue_script(
			'bmspay-checkout',
			plugins_url( 'assets/js/bmspay-checkout.js', __FILE__ ),
			array( 'jquery', 'sweetalert2', 'bmspay-3ds' ),
			Bmspay_Constants::PLUGIN_VERSION,
			true
		);
		$this->log_debug( '3DS: enqueued bmspay-checkout script' );

		wp_localize_script(
			'bmspay-checkout',
			'bmspay_checkout_params',
			array(
				'apiKey'      => $api_key,
				'token'       => $token,
				'total'       => $order_total,
				'endpoint'    => $this->api_client->get_3ds_endpoint(),
				'currency'    => $this->get_3ds_currency_code(),
				'logAjaxUrl'  => admin_url( 'admin-ajax.php' ),
				'logNonce'    => wp_create_nonce( 'bmspay_3ds_client_log' ),
				'refreshTokenNonce' => wp_create_nonce( 'bmspay_3ds_refresh_token' ),
			)
		);
	}

	/**
	 * Force-refresh the cached 3DS credentials.
	 *
	 * Called by the AJAX handler when the JS SDK gets a 401 from the 3DS API,
	 * which means the cached JWT was rejected (expired or revoked).
	 *
	 * @return array|WP_Error { apiKey, token } on success, WP_Error otherwise.
	 */
	public function refresh_3ds_token() {
		$token_cache_key = 'bmspay_3ds_token_' . substr( md5( $this->get_api_mid() . $this->get_api_cid() . $this->get_environment() ), 0, 12 );

		delete_transient( $token_cache_key );
		WC()->session->set( 'threed_secure_apikey', '' );
		WC()->session->set( 'threed_secure_token', '' );

		$threed_secure_data = $this->api_client->get_threeds_token();

		if ( is_wp_error( $threed_secure_data ) ) {
			$this->log_debug( '3DS: refresh_3ds_token failed: ' . $threed_secure_data->get_error_message() );
			return $threed_secure_data;
		}

		$api_key = isset( $threed_secure_data['ApiKey'] ) ? $threed_secure_data['ApiKey'] : '';
		$token   = isset( $threed_secure_data['Token'] ) ? $threed_secure_data['Token'] : '';

		if ( empty( $api_key ) || empty( $token ) ) {
			$this->log_debug( '3DS: refresh_3ds_token returned empty credentials' );
			return new WP_Error( 'bmspay_3ds_empty_token', __( 'Empty 3DS credentials returned from gateway', 'blackstone-online-gateway' ) );
		}

		set_transient( $token_cache_key, array( 'ApiKey' => $api_key, 'Token' => $token ), 5 * MINUTE_IN_SECONDS );
		WC()->session->set( 'threed_secure_apikey', $api_key );
		WC()->session->set( 'threed_secure_token', $token );

		$this->log_debug( '3DS: token refreshed via AJAX, api_key=' . substr( $api_key, 0, 8 ) . '...' );

		return array(
			'apiKey' => $api_key,
			'token'  => $token,
		);
	}

	/**
	 * Convert WooCommerce currency to ISO 4217 numeric code for 3DS API.
	 *
	 * @return string ISO 4217 numeric currency code (default: '840' for USD)
	 */
	protected function get_3ds_currency_code() {
		$currency_map = array(
			'USD' => '840',
			'EUR' => '978',
			'GBP' => '826',
			'JPY' => '392',
			'CAD' => '124',
			'AUD' => '036',
			'MXN' => '484',
		);

		$wc_currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
		return isset( $currency_map[ $wc_currency ] ) ? $currency_map[ $wc_currency ] : '840';
	}

	/**
	 * Convert WooCommerce country code (alpha-2) to ISO 3166-1 numeric code for 3DS API.
	 *
	 * @param string $country_code Alpha-2 country code (e.g., "US", "ES", "GB").
	 * @return string Numeric country code (e.g., "840", "724", "826").
	 */
	protected function get_3ds_country_code( $country_code ) {
		$country_map = array(
			'US' => '840',
			'ES' => '724',
			'GB' => '826',
			'FR' => '250',
			'DE' => '276',
			'IT' => '380',
			'CA' => '124',
			'AU' => '036',
			'JP' => '392',
			'CN' => '156',
			'IN' => '356',
			'BR' => '076',
			'MX' => '484',
			'NL' => '528',
			'SE' => '752',
			'CH' => '756',
			'BE' => '056',
			'AT' => '040',
		);

		return isset( $country_map[ strtoupper( $country_code ) ] ) ? $country_map[ strtoupper( $country_code ) ] : '840';
	}

	/**
	 * Get current order total for 3DS processing.
	 *
	 *
	 * @return float
	 */
	protected function get_order_total_for_3ds() {
		if ( is_checkout() && WC()->cart && is_callable( array( WC()->cart, 'get_total' ) ) ) {
			return (float) WC()->cart->get_total( 'raw' );
		}

		if ( function_exists( 'is_order_pay_page' ) && is_order_pay_page() && isset( $_GET['order_id'] ) ) {
			$order_id = absint( wp_unslash( $_GET['order_id'] ) );
			$order    = wc_get_order( $order_id );
			if ( $order ) {
				return (float) $order->get_total();
			}
		}

		return 0.0;
	}

	/**
	 * Output payment fields on checkout.
	 *
	 * 
	 * @return void
	 */
	public function payment_fields() {
		$this->form_renderer->render();
	}

	/**
	 * Get cached surcharge data from API or default.
	 *
	 * 
	 * @return array
	 */
	public function get_cached_surcharge_data() {
		if ( $this->enabled !== 'yes' ) {
			return $this->get_default_surcharge_data();
		}

		$cache_key      = 'bmspay_surcharge_' . substr( md5( $this->get_api_mid() . $this->get_api_cid() . $this->get_api_username() . $this->get_environment() ), 0, 12 );
		$surcharge_data = get_transient( $cache_key );

		if ( $surcharge_data === false ) {
			$surcharge_data = $this->fetch_merchant_settings();

			if ( $surcharge_data === false ) {
				$unavailable                      = $this->get_default_surcharge_data();
				$unavailable['response_ApiAvailable'] = false;
				return $unavailable;
			}

			set_transient( $cache_key, $surcharge_data, HOUR_IN_SECONDS );
		}

		return $surcharge_data;
	}

	/**
	 * Fetch merchant settings from Blackstone API.
	 *
	 * 
	 * @return array
	 */
	protected function fetch_merchant_settings() {
		$response = $this->api_client->get_merchant_settings();

		if ( is_wp_error( $response ) ) {
			return false;
		}

		return $this->response_parser->parse_merchant_settings( $response );
	}

	/**
	 * Get default surcharge data structure.
	 *
	 * 
	 * @return array
	 */
	protected function get_default_surcharge_data(): array {
		return array(
			'response_SurchargeEnabled'        => false,
			'response_SurchargePercent'        => 0,
			'response_CardDifferenceEnabled'   => false,
			'response_CardDifferencePercent'   => 0,
			'response_ThreeDSecureEnabled'     => false,
			'response_ApiAvailable'            => true,
		);
	}

	/**
	 * Process payment for given order.
	 *
	 * 
	 * @param int $order_id Order ID.
	 * @return array|null
	 */
	public function process_payment( $order_id ) {
		$customer_order = wc_get_order( $order_id );

		if ( ! $customer_order ) {
			return null;
		}

		$surcharge_data = $this->get_cached_surcharge_data();

		if ( isset( $surcharge_data['response_ApiAvailable'] ) && $surcharge_data['response_ApiAvailable'] === false ) {
			wc_add_notice(
				__( 'Payment is temporarily unavailable. Please try again in a few minutes.', 'blackstone-online-gateway' ),
				'error'
			);
			return null;
		}

		$lock_key = 'bmspay_payment_lock_' . $order_id;

		// Note: there is a theoretical TOCTOU window between get_transient and set_transient,
		// but WordPress does not expose an atomic test-and-set for transients. The window is
		// negligible in practice since payments complete in < 1 s and the finally block always
		// deletes the lock. A duplicate charge would be caught by Blackstone's idempotency key.
		if ( get_transient( $lock_key ) ) {
			wc_add_notice( __( 'A payment is already being processed for this order. Please wait.', 'blackstone-online-gateway' ), 'error' );
			return null;
		}

		set_transient( $lock_key, 1, 60 );

		try {
			$this->api_client->set_log_context( $order_id, 'sale' );

			// Safety net: ensure persisted total matches current items before charging.
			// The pay-page template_redirect handler normally already did this, so this
			// call only triggers when the order changed between page-load and submit.
			bmspay_ensure_order_total_consistency( $customer_order );

			$secure_data           = '';
			$secure_transaction_id = '';

			if ( $this->should_process_3ds() && ! isset( $_POST['threeds_response'] ) ) {
				if ( ! $this->validate_fields() ) {
					$this->api_client->clear_log_context();
					return array( 'result' => 'failure' );
				}
			}

			$token_id_value   = isset( $_POST['wc-saved-payment-token'] ) ? sanitize_text_field( wp_unslash( $_POST['wc-saved-payment-token'] ) ) : 'new';
			$is_token_payment = isset( $_POST['wc-saved-payment-token'] ) && $token_id_value !== 'new';

			if ( $this->should_process_3ds() && ! $is_token_payment ) {
				if ( ! isset( $_POST['threeds_response'] ) ) {
					$this->log_warning( '3DS: process_payment reached without threeds_response — order #' . $order_id );
					wc_add_notice(
						__( '3D Secure verification is required but no verification response was received. Please try again.', 'blackstone-online-gateway' ),
						'error'
					);
					$this->api_client->clear_log_context();
					return null;
				}

				$this->log_debug( '3DS: threeds_response received for order #' . $order_id . ', processing...' );
				$result = $this->process_3ds_response();
				if ( ! $result['success'] ) {
					wc_add_notice( wp_strip_all_tags( $result['message'] ), 'error' );
					$this->api_client->clear_log_context();
					return null;
				}
				$secure_data           = $result['authentication_value'];
				$secure_transaction_id = $result['transaction_id'];

				$this->log_debug( '3DS: Auth accepted — transaction_id=' . $secure_transaction_id . ', auth_value_len=' . strlen( $secure_data ) );
			}

			$result = null;
			if ( $is_token_payment ) {
				$result = $this->process_token_payment( $customer_order, $secure_data, $secure_transaction_id );
			} else {
				$result = $this->process_card_payment( $customer_order, $secure_data, $secure_transaction_id );
			}

			$this->api_client->clear_log_context();

			return $result;
		} finally {
			delete_transient( $lock_key );
		}
	}

	/**
	 * Check if 3DS should be processed.
	 *
	 * 
	 * @return bool
	 */
	protected function should_process_3ds() {
		$surcharge_data         = $this->get_cached_surcharge_data();
		$threeds_api_enabled    = ! empty( $surcharge_data['response_ThreeDSecureEnabled'] );
		$threeds_plugin_enabled = $this->get_environment_3ds() === 'yes';
		$force_sandbox          = $this->force_3ds_sandbox === 'yes' && $this->is_test_environment();

		return $threeds_plugin_enabled && ( $threeds_api_enabled || $force_sandbox );
	}

	/**
	 * Process 3D Secure response.
	 *
	 * 
	 * @return array
	 */
	protected function process_3ds_response() {
		if ( ! isset( $_POST['threeds_response'] ) ) {
			return array(
				'success' => false,
				'message' => __( 'No 3DS response received.', 'blackstone-online-gateway' ),
			);
		}

		$raw_response = sanitize_textarea_field( wp_unslash( $_POST['threeds_response'] ) );

		// Decode to log the status before full parse.
		$decoded = json_decode( $raw_response, true );
		$status  = is_array( $decoded ) && isset( $decoded['status'] ) ? $decoded['status'] : 'unknown';
		$this->log_debug( '3DS: Response received — status=' . $status );

		$result = $this->response_parser->parse_3ds_response( $raw_response );

		if ( ! $result['success'] ) {
			$this->log_warning( '3DS: Rejected — status=' . $status . ' message=' . $result['message'] );
		} else {
			$this->log_debug( '3DS: Parsed OK — transaction_id=' . $result['transaction_id'] );
		}

		return $result;
	}

	/**
	 * Log debug message (respects debug setting).
	 *
	 * 
	 * @param string $message Log message.
	 * @return void
	 */
	protected function log_debug( string $message ): void {
		Bmspay_Logger::debug( $message );
	}

	/**
	 * Log info message (respects debug setting).
	 *
	 *
	 * @param string $message Log message.
	 * @return void
	 */
	protected function log_info( string $message ): void {
		Bmspay_Logger::info( $message );
	}

	/**
	 * Log warning message.
	 *
	 *
	 * @param string $message Warning message.
	 * @return void
	 */
	protected function log_warning( $message ) {
		Bmspay_Logger::warning( (string) $message );
	}

	/**
	 * Process token payment.
	 *
	 * 
	 * @param WC_Order $order Order object.
	 * @param string   $secure_data 3DS secure data.
	 * @param string   $secure_transaction_id 3DS transaction ID.
	 * @return array|null
	 */
	protected function process_token_payment( $order, $secure_data, $secure_transaction_id ) {
		$token_id = isset( $_POST['wc-saved-payment-token'] ) ? absint( sanitize_text_field( wp_unslash( $_POST['wc-saved-payment-token'] ) ) ) : 0;
		$token    = WC_Payment_Tokens::get( $token_id );

		if ( ! $token ) {
			wc_add_notice( __( 'Invalid payment method selected.', 'blackstone-online-gateway' ), 'error' );
			return null;
		}

		$current_user_id = get_current_user_id();
		$token_user_id = $token->get_user_id();

		if ( $token_user_id !== $current_user_id ) {
			wc_add_notice( __( 'Invalid payment method selected.', 'blackstone-online-gateway' ), 'error' );
			return null;
		}

		$charge_breakdown = bmspay_get_order_charge_breakdown(
			$order,
			$this,
			bmspay_get_charge_overrides( $order->get_id() )
		);

		$payload = $this->request_builder->build_token_sale_payload(
			$order,
			$token->get_token(),
			$charge_breakdown,
			$secure_data,
			$secure_transaction_id
		);

		$response = $this->api_client->process_sale_with_token( $payload );

		if ( is_wp_error( $response ) ) {
			wc_add_notice(
				__( 'There is issue for connecting payment gateway. Sorry for the inconvenience.', 'blackstone-online-gateway' ),
				'error'
			);
			return null;
		}

		if ( ! $this->response_parser->is_success( $response ) ) {
			$this->handle_payment_error( $response, $order, $payload['UserTransactionNumber'] );
			return null;
		}

		$this->handle_payment_success( $order, $response, $payload );

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * Process card payment.
	 *
	 * 
	 * @param WC_Order $order Order object.
	 * @param string   $secure_data 3DS secure data.
	 * @param string   $secure_transaction_id 3DS transaction ID.
	 * @return array|null
	 */
	protected function process_card_payment( $order, $secure_data, $secure_transaction_id ) {
		$charge_breakdown = bmspay_get_order_charge_breakdown(
			$order,
			$this,
			bmspay_get_charge_overrides( $order->get_id() )
		);

		$payload = $this->request_builder->build_sale_payload(
			$order,
			$charge_breakdown,
			$secure_data,
			$secure_transaction_id
		);

		$response = $this->api_client->process_sale( $payload );

		if ( is_wp_error( $response ) ) {
			wc_add_notice(
				__( 'There is issue for connecting payment gateway. Sorry for the inconvenience.', 'blackstone-online-gateway' ),
				'error'
			);
			return null;
		}

		if ( ! $this->response_parser->is_success( $response ) ) {
			$this->handle_payment_error( $response, $order, $payload['UserTransactionNumber'] );
			return null;
		}

		$this->handle_payment_success( $order, $response, $payload );

		$save_card = isset( $_POST['save_card'] ) ? sanitize_text_field( wp_unslash( $_POST['save_card'] ) ) : '';
		$this->log_debug( 'Save card checkbox value: ' . ( empty( $save_card ) ? 'NOT CHECKED' : 'CHECKED - ' . $save_card ) );
		if ( $save_card === '1' ) {
			$this->save_payment_token( $order, $response, $payload );
		}

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * Handle successful payment.
	 *
	 * 
	 * @param WC_Order $order Order object.
	 * @param array    $response API response.
	 * @param array    $payload Request payload.
	 * @return void
	 */
	protected function handle_payment_success( $order, $response, $payload ) {
		$order->add_order_note( __( 'Blackstone complete payment.', 'blackstone-online-gateway' ) );

		$service_reference  = isset( $response['ServiceReferenceNumber'] ) ? $response['ServiceReferenceNumber'] : '';
		$user_transaction    = isset( $payload['UserTransactionNumber'] ) ? $payload['UserTransactionNumber'] : '';

		// Store the total actually charged (base + surcharge + card_difference) so that
		// the refund integration can send the correct full amount back to Blackstone.
		$base_amount     = isset( $payload['Amount'] ) ? (float) $payload['Amount'] : 0.0;
		$surcharge       = isset( $payload['SurchargeAmount'] ) ? (float) $payload['SurchargeAmount'] : 0.0;
		$card_diff       = isset( $payload['CardDifferenceAmount'] ) ? (float) $payload['CardDifferenceAmount'] : 0.0;
		$total_charged   = $base_amount + $surcharge + $card_diff;
		$original_amount = $total_charged > 0 ? $total_charged : null;

		$this->store_blackstone_references( $order, $service_reference, $user_transaction, $original_amount );

		$order->payment_complete();
		WC()->cart->empty_cart();
		$order->save();
	}

	/**
	 * Handle payment error.
	 *
	 * 
	 * @param array    $response API response.
	 * @param WC_Order $order Order object.
	 * @param string   $user_transaction_number Transaction reference.
	 * @return void
	 */
	protected function handle_payment_error( $response, $order, $user_transaction_number ) {
		$message     = $this->response_parser->get_user_message( $response );
		$full_details = $this->response_parser->get_full_error_details( $response, $user_transaction_number );

		wc_add_notice( wp_strip_all_tags( $message ), 'error' );
		$order->add_order_note( 'Error: ' . wp_strip_all_tags( $full_details ) );
	}

	/**
	 * Save payment token for future use.
	 *
	 * 
	 * @param WC_Order $order Order object.
	 * @param array    $response API response.
	 * @param array    $payload Request payload.
	 * @return void
	 */
	protected function save_payment_token( $order, $response, $payload ) {
		if ( ! isset( $response['Token'] ) ) {
			return;
		}

		$user_id        = $order->get_user_id();
		$last4          = isset( $response['LastFour'] ) ? sanitize_text_field( $response['LastFour'] ) : '';
		$card_type      = isset( $response['CardType'] ) ? sanitize_text_field( $response['CardType'] ) : '';
		$expiry_date    = isset( $payload['ExpDate'] ) ? sanitize_text_field( $payload['ExpDate'] ) : '';
		$expiry_month   = substr( $expiry_date, 0, 2 );
		$expiry_year    = '20' . substr( $expiry_date, 2, 2 );

		$existing_tokens = WC_Payment_Tokens::get_customer_tokens( $user_id );

		foreach ( $existing_tokens as $existing_token ) {
			if ( method_exists( $existing_token, 'get_gateway_id' ) && $existing_token->get_gateway_id() !== 'bmspay_blackstone_payment' ) {
				continue;
			}

			if ( $existing_token->get_token() === $response['Token'] ) {
				return;
			}

			if (
				$existing_token->get_last4() === $last4 &&
				$existing_token->get_expiry_month() === $expiry_month &&
				$existing_token->get_expiry_year() === $expiry_year &&
				$existing_token->get_card_type() === $card_type
			) {
				$existing_token->set_token( $response['Token'] );
				$existing_token->save();
				$order->add_order_note(
					sprintf(
						__( 'Payment token updated for card ending in %s.', 'blackstone-online-gateway' ),
						$last4
					)
				);
				return;
			}
		}

		$token = new WC_Payment_Token_CC();
		$token->set_token( $response['Token'] );
		$token->set_gateway_id( $this->id );
		$token->set_user_id( $user_id );
		$token->set_last4( $last4 );
		$token->set_card_type( $card_type );
		$token->set_expiry_month( $expiry_month );
		$token->set_expiry_year( $expiry_year );
		$token->save();

		$order->add_order_note(
			sprintf(
				__( 'Payment card saved for future use. Card: %s ending in %s, expires %s/%s', 'blackstone-online-gateway' ),
				$card_type,
				$last4,
				$expiry_month,
				$expiry_year
			)
		);
	}

	/**
	 * Store Blackstone references on order.
	 *
	 * 
	 * @param WC_Order $order Order object.
	 * @param string   $service_reference Service reference number.
	 * @param string   $user_transaction User transaction number.
	 * @param float|null $amount Original amount.
	 * @return void
	 */
	protected function store_blackstone_references( $order, $service_reference, $user_transaction, $amount = null ) {
		if ( empty( $service_reference ) ) {
			return;
		}

		$order->update_meta_data( '_bmspay_service_reference_number', $service_reference );
		$order->update_meta_data( '_bmspay_sale_service_reference_number', $service_reference );
		$order->add_order_note(
			sprintf( __( 'Blackstone Sale Ref: %s', 'blackstone-online-gateway' ), $service_reference )
		);

		if ( ! empty( $user_transaction ) ) {
			$order->update_meta_data( '_bmspay_transaction_number', $user_transaction );
			$order->update_meta_data( '_bmspay_sale_user_transaction_number', $user_transaction );
			$order->add_order_note(
				sprintf( __( 'Blackstone Sale User Transaction Number: %s', 'blackstone-online-gateway' ), $user_transaction )
			);
		}

		if ( $amount !== null ) {
			$order->update_meta_data( '_bmspay_original_amount', $amount );
			$order->add_order_note(
				sprintf( __( 'Blackstone Original Amount: %s', 'blackstone-online-gateway' ), $amount )
			);
		}
	}

	/**
	 * Validate payment fields.
	 *
	 * 
	 * @return bool
	 */
	public function validate_fields() {
		$is_valid = true;

		$token_id = isset( $_POST['wc-saved-payment-token'] ) ? sanitize_text_field( wp_unslash( $_POST['wc-saved-payment-token'] ) ) : '';
		$is_token_payment = ! empty( $token_id ) && $token_id !== 'new';

		if ( $is_token_payment ) {
			return $is_valid;
		}

		$card_number = isset( $_POST[ $this->id . '-card-number' ] )
			? wc_clean( wp_unslash( $_POST[ $this->id . '-card-number' ] ) )
			: '';
		$card_expiry = isset( $_POST[ $this->id . '-card-expiry' ] )
			? wc_clean( wp_unslash( $_POST[ $this->id . '-card-expiry' ] ) )
			: '';
		$card_cvc = isset( $_POST[ $this->id . '-card-cvc' ] )
			? wc_clean( wp_unslash( $_POST[ $this->id . '-card-cvc' ] ) )
			: '';

		if ( empty( $card_number ) ) {
			wc_add_notice(
				__( 'Card number is required.', 'blackstone-online-gateway' ),
				'error'
			);
			$is_valid = false;
		} elseif ( ! $this->card_validator->is_valid_number( $card_number ) ) {
			wc_add_notice(
				__( 'Please enter a valid card number.', 'blackstone-online-gateway' ),
				'error'
			);
			$is_valid = false;
		}

		if ( empty( $card_expiry ) ) {
			wc_add_notice(
				__( 'Card expiry date is required.', 'blackstone-online-gateway' ),
				'error'
			);
			$is_valid = false;
		} elseif ( ! $this->card_validator->is_valid_expiry( $card_expiry ) ) {
			wc_add_notice(
				__( 'Please enter a valid expiry date (MM/YY).', 'blackstone-online-gateway' ),
				'error'
			);
			$is_valid = false;
		}

		if ( empty( $card_cvc ) ) {
			wc_add_notice(
				__( 'Card security code (CVV) is required.', 'blackstone-online-gateway' ),
				'error'
			);
			$is_valid = false;
		} elseif ( ! $this->card_validator->is_valid_cvc( $card_cvc ) ) {
			wc_add_notice(
				__( 'Please enter a valid security code (3 or 4 digits).', 'blackstone-online-gateway' ),
				'error'
			);
			$is_valid = false;
		}

		return $is_valid;
	}

	/**
	 * Check SSL certificate status.
	 *
	 * 
	 * @return void
	 */
	public function do_ssl_check() {
		if ( $this->enabled !== 'yes' ) {
			return;
		}

		if ( get_option( 'woocommerce_force_ssl_checkout' ) === 'no' ) {
			printf(
				'<div class="error"><p>%s</p></div>',
				sprintf(
					__( '<strong>%s</strong> is enabled and WooCommerce is not forcing the SSL certificate on your checkout page. Please ensure that you have a valid SSL certificate and that you are <a href="%s">forcing the checkout pages to be secured.</a>', 'blackstone-online-gateway' ),
					esc_html( $this->method_title ),
					esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout' ) )
				)
			);
		}
	}

	/**
	 * Get environment setting.
	 *
	 * 
	 * @return string
	 */
	public function get_environment() {
		return $this->environment;
	}

	/**
	 * Get 3DS environment setting.
	 *
	 * 
	 * @return string
	 */
	public function get_environment_3ds() {
		return $this->environment_3ds;
	}

	public function get_force_3ds_sandbox() {
		return $this->force_3ds_sandbox;
	}

	/**
	 * Get surcharge label.
	 *
	 * 
	 * @return string
	 */
	public function get_label_surcharge() {
		return $this->label_surcharge;
	}

	/**
	 * Get card difference label.
	 *
	 * 
	 * @return string
	 */
	public function get_label_card_difference() {
		return $this->label_card_difference;
	}

	/**
	 * Get app key.
	 *
	 * 
	 * @return string
	 */
	public function get_app_key() {
		return $this->app_key;
	}

	/**
	 * Get API username.
	 *
	 * 
	 * @return string
	 */
	public function get_api_username() {
		return $this->api_username;
	}

	/**
	 * Get API password.
	 *
	 * 
	 * @return string
	 */
	public function get_api_password() {
		return $this->api_password;
	}

	/**
	 * Get API MID.
	 *
	 * 
	 * @return string
	 */
	public function get_api_mid() {
		return $this->api_mid;
	}

	/**
	 * Get API CID.
	 *
	 * 
	 * @return string
	 */
	public function get_api_cid() {
		return $this->api_cid;
	}

	/**
	 * Get app type.
	 *
	 * 
	 * @return string
	 */
	public function get_app_type() {
		return $this->app_type;
	}

	/**
	 * Check if running in test environment.
	 *
	 * 
	 * @return bool
	 */
	public function is_test_environment() {
		return $this->environment === 'yes';
	}

	/**
	 * Check if debug mode is enabled.
	 *
	 * 
	 * @return bool
	 */
	public function is_debug_enabled() {
		return $this->debug === 'yes';
	}

	/**
	 * Sanitize setting value based on key.
	 *
	 * 
	 * @param string $key Setting key.
	 * @param mixed  $value Setting value.
	 * @return mixed
	 */
	protected function sanitize_setting( $key, $value ) {
		$sensitive_fields = array( 'api_password', 'app_key' );
		if ( in_array( $key, $sensitive_fields, true ) ) {
			return sanitize_text_field( (string) $value );
		}

		$text_fields = array( 'title', 'description', 'label_surcharge', 'label_card_difference' );
		if ( in_array( $key, $text_fields, true ) ) {
			return sanitize_text_field( (string) $value );
		}

		$yes_no_fields = array( 'environment', 'environment_3ds', 'force_3ds_sandbox', 'enabled', 'debug' );
		if ( in_array( $key, $yes_no_fields, true ) ) {
			return in_array( $value, array( 'yes', 'no' ), true ) ? $value : 'no';
		}

		$credential_fields = array( 'api_username', 'api_mid', 'api_cid', 'app_type' );
		if ( in_array( $key, $credential_fields, true ) ) {
			return sanitize_text_field( (string) $value );
		}

		return sanitize_text_field( (string) $value );
	}
}

/**
 * Round amount to 2 decimal places.
 *
 * 
 * @param float $amount Amount to round.
 * @return float
 */
function bmspay_round_amount( $amount ) {
	return round( (float) $amount, 2 );
}

/**
 * Format decimal amount.
 *
 *
 * @param float $amount Amount to format.
 * @return string
 */
function bmspay_format_decimal_amount( $amount ) {
	return number_format( (float) $amount, 2, '.', '' );
}

/**
 * Ensure the persisted order total matches the current items sum.
 *
 * WooCommerce admin does not auto-recalculate the order total when items are
 * removed/edited unless the admin clicks "Recalculate". This means
 * $order->get_total() can return a stale value while $order->get_subtotal()
 * (which reads items live) returns the new one — leading to charging the
 * customer a different amount from what they see on the pay-for-order page.
 *
 * @param WC_Order $order Order to validate.
 * @return bool True if a recalc was applied (i.e., total had drifted).
 */
function bmspay_ensure_order_total_consistency( WC_Order $order ): bool {
	// If the order already carries surcharge/card-difference fee metadata, the
	// dedicated surcharge flow (Bmspay_Checkout_Display::adjust_order_totals)
	// owns the total. Re-running calculate_totals here re-triggers that hook
	// and the existing fee maths double-count the cached surcharge. Skip.
	$has_surcharge       = (float) $order->get_meta( '_bmspay_surcharge_amount', true ) > 0;
	$has_card_difference = (float) $order->get_meta( '_bmspay_card_difference_amount', true ) > 0;
	if ( $has_surcharge || $has_card_difference ) {
		return false;
	}

	$total_before = (float) $order->get_total();
	$order->calculate_totals( false );
	$total_after = (float) $order->get_total();

	if ( abs( $total_before - $total_after ) <= 0.01 ) {
		return false;
	}

	$order->save();

	$note = sprintf(
		/* translators: 1: previous total, 2: recalculated total */
		__( 'Blackstone: Order total recalculated from %1$s to %2$s before charge. Order items had been modified without recalculating.', 'blackstone-online-gateway' ),
		wc_price( $total_before, array( 'currency' => $order->get_currency() ) ),
		wc_price( $total_after, array( 'currency' => $order->get_currency() ) )
	);
	$order->add_order_note( wp_strip_all_tags( $note ) );

	if ( class_exists( 'Bmspay_Logger' ) ) {
		Bmspay_Logger::warning( sprintf(
			'Order #%d total recalculated before charge: %s -> %s',
			$order->get_id(),
			$total_before,
			$total_after
		) );
	}

	return true;
}

/**
 * Build charge breakdown array.
 *
 * 
 * @param float $base_amount Base order amount.
 * @param float $surcharge_amount Surcharge amount.
 * @param float $card_difference_amount Card difference amount.
 * @return array
 */
function bmspay_build_charge_breakdown( $base_amount, $surcharge_amount = 0, $card_difference_amount = 0, $surcharge_percent = 0.0, $card_difference_percent = 0.0 ) {
	return array(
		'base_amount'             => bmspay_round_amount( $base_amount ),
		'surcharge_amount'        => bmspay_round_amount( $surcharge_amount ),
		'card_difference_amount'  => bmspay_round_amount( $card_difference_amount ),
		'total'                   => bmspay_round_amount( $base_amount + $surcharge_amount + $card_difference_amount ),
		'surcharge_percent'       => (float) $surcharge_percent,
		'card_difference_percent' => (float) $card_difference_percent,
	);
}

/**
 * Get cart base amount.
 *
 * 
 * @return float
 */
function bmspay_get_cart_base_amount() {
	if ( ! isset( WC()->cart ) ) {
		return 0;
	}

	// get_subtotal() is set during calculate_item_totals() which runs before the
	// woocommerce_calculated_total filter fires. get_total('raw') returns 0 at that
	// point because reset_totals() resets it and set_total() hasn't been called yet.
	return max( 0, bmspay_round_amount( WC()->cart->get_subtotal() ) );
}

/**
 * Get order base amount.
 *
 * 
 * @param WC_Order $order Order object.
 * @return float
 */
function bmspay_get_order_base_amount( $order ) {
	$total    = (float) $order->get_total();
	$surcharge = (float) $order->get_meta( '_bmspay_surcharge_amount', true );
	$card_diff = (float) $order->get_meta( '_bmspay_card_difference_amount', true );
	// Subtract stored fees so the base is the items-only amount, not total-including-fees.
	return bmspay_round_amount( $total - $surcharge - $card_diff );
}

/**
 * Get charge overrides from session.
 *
 * 
 * @param int $order_id Order ID.
 * @return array
 */
function bmspay_get_charge_overrides( $order_id = 0 ) {
	return array_merge(
		bmspay_get_charge_overrides_from_order_meta( $order_id ),
		bmspay_get_charge_overrides_from_session()
	);
}

/**
 * Get charge overrides from session.
 *
 * @return array
 */
function bmspay_get_charge_overrides_from_session() {
	if ( ! WC()->session ) {
		return array();
	}

	$overrides = array();

	$surcharge_percent      = WC()->session->get( 'bmspay_surcharge_percent' );
	$card_difference_percent = WC()->session->get( 'bmspay_card_difference_percent' );

	if ( $surcharge_percent !== null && $surcharge_percent !== '' ) {
		$overrides['response_SurchargePercent']  = (float) $surcharge_percent;
		$overrides['response_SurchargeEnabled'] = ( (float) $surcharge_percent ) > 0;
	}

	if ( $card_difference_percent !== null && $card_difference_percent !== '' ) {
		$overrides['response_CardDifferencePercent']  = (float) $card_difference_percent;
		$overrides['response_CardDifferenceEnabled'] = ( (float) $card_difference_percent ) > 0;
	}

	return $overrides;
}

/**
 * Get charge overrides from order meta.
 *
 * @param int $order_id Order ID.
 * @return array
 */
function bmspay_get_charge_overrides_from_order_meta( $order_id ) {
	if ( ! $order_id ) {
		return array();
	}

	$overrides = array();

	$order = wc_get_order( $order_id );

	if ( ! $order instanceof WC_Order ) {
		return $overrides;
	}

	$surcharge_percent       = $order->get_meta( '_bmspay_surcharge_percent', true );
	$card_difference_percent = $order->get_meta( '_bmspay_card_difference_percent', true );

	if ( $surcharge_percent !== '' ) {
		$overrides['response_SurchargePercent']  = (float) $surcharge_percent;
		$overrides['response_SurchargeEnabled'] = ( (float) $surcharge_percent ) > 0;
	}

	if ( $card_difference_percent !== '' ) {
		$overrides['response_CardDifferencePercent']  = (float) $card_difference_percent;
		$overrides['response_CardDifferenceEnabled'] = ( (float) $card_difference_percent ) > 0;
	}

	return $overrides;
}

/**
 * Get cart charge breakdown.
 *
 * 
 * @return array
 */
function bmspay_get_cart_charge_breakdown() {
	$gateway        = new BMSPay_Blackstone_Payment();
	$surcharge_data = $gateway->get_cached_surcharge_data();

	$base_amount = bmspay_get_cart_base_amount();

	$surcharge_percent = (float) ( $surcharge_data['response_SurchargePercent'] ?? 0 );
	$surcharge_amount  = 0;
	if ( ! empty( $surcharge_data['response_SurchargeEnabled'] ) && $surcharge_percent > 0 && $base_amount > 0 ) {
		$surcharge_amount = $base_amount * ( $surcharge_percent / 100 );
	}

	$card_difference_percent = (float) ( $surcharge_data['response_CardDifferencePercent'] ?? 0 );
	$card_difference_amount  = 0;
	if ( ! empty( $surcharge_data['response_CardDifferenceEnabled'] ) && $card_difference_percent > 0 && $base_amount > 0 ) {
		$card_difference_amount = $base_amount * ( $card_difference_percent / 100 );
	}

	return bmspay_build_charge_breakdown( $base_amount, $surcharge_amount, $card_difference_amount, $surcharge_percent, $card_difference_percent );
}

/**
 * Get order charge breakdown.
 *
 * 
 * @param WC_Order $order Order object.
 * @param object  $gateway Gateway object.
 * @param array   $overrides Override values.
 * @return array
 */
function bmspay_get_order_charge_breakdown( $order, $gateway, $overrides = array() ) {
	$surcharge_data = array(
		'response_SurchargeEnabled'      => false,
		'response_SurchargePercent'       => 0,
		'response_CardDifferenceEnabled'  => false,
		'response_CardDifferencePercent'  => 0,
	);

	if ( ! empty( $overrides ) && is_array( $overrides ) ) {
		$surcharge_data = wp_parse_args( $overrides, $surcharge_data );
	} elseif ( $gateway !== null && method_exists( $gateway, 'get_cached_surcharge_data' ) ) {
		$surcharge_data = $gateway->get_cached_surcharge_data();
	}

	$base_amount = bmspay_get_order_base_amount( $order );

	$surcharge_percent       = (float) ( $surcharge_data['response_SurchargePercent'] ?? 0 );
	$card_difference_percent = (float) ( $surcharge_data['response_CardDifferencePercent'] ?? 0 );

	$surcharge_amount = 0;
	if ( ! empty( $surcharge_data['response_SurchargeEnabled'] ) && $surcharge_percent > 0 && $base_amount > 0 ) {
		$surcharge_amount = $base_amount * ( $surcharge_percent / 100 );
	}

	$card_difference_amount = 0;
	if ( ! empty( $surcharge_data['response_CardDifferenceEnabled'] ) && $card_difference_percent > 0 && $base_amount > 0 ) {
		$card_difference_amount = $base_amount * ( $card_difference_percent / 100 );
	}

	return bmspay_build_charge_breakdown( $base_amount, $surcharge_amount, $card_difference_amount, $surcharge_percent, $card_difference_percent );
}

/**
 * Checkout display handler for surcharge and card difference.
 *
 * Handles visual display and total calculation for additional fees.
 */
class Bmspay_Checkout_Display {

	/**
	 * Check if plugin is active and enabled.
	 *
	 * @return bool
	 */
	public static function is_plugin_active(): bool {
		if ( ! class_exists( 'WC_Payment_Gateways' ) ) {
			return false;
		}

		$gateways = WC_Payment_Gateways::instance()->payment_gateways();

		return isset( $gateways['bmspay_blackstone_payment'] )
			&& $gateways['bmspay_blackstone_payment']->enabled === 'yes';
	}

	/**
	 * Get the selected payment method at checkout.
	 *
	 * During AJAX order review updates, WC sends form data as a serialized string
	 * in $_POST['post_data'], so $_POST['payment_method'] is not directly available.
	 * WC updates the session before recalculating totals, so the session is reliable.
	 *
	 * @return string
	 */
	private static function get_checkout_payment_method(): string {
		if ( isset( $_POST['payment_method'] ) ) {
			return sanitize_text_field( wp_unslash( $_POST['payment_method'] ) );
		}

		if ( WC()->session ) {
			return (string) WC()->session->get( 'chosen_payment_method', '' );
		}

		return '';
	}

	/**
	 * Display surcharge and card difference in checkout.
	 *
	 * @return void
	 */
	public static function display_surcharge_in_checkout(): void {
		if ( ! self::is_plugin_active() ) {
			return;
		}

		if ( self::get_checkout_payment_method() !== 'bmspay_blackstone_payment' ) {
			return;
		}

		$gateway = new BMSPay_Blackstone_Payment();
		$breakdown = bmspay_get_cart_charge_breakdown();

		if ( $breakdown['surcharge_amount'] > 0 ) {
			echo '<tr class="order-total bmspay-surcharge">';
			echo '<th>' . esc_html( $gateway->get_label_surcharge() ) . ' (' . number_format( $breakdown['surcharge_percent'], 2 ) . '%)</th>';
			echo '<td>' . wc_price( $breakdown['surcharge_amount'] ) . '</td>';
			echo '</tr>';
		}

		if ( $breakdown['card_difference_amount'] > 0 ) {
			echo '<tr class="order-total bmspay-card-difference">';
			echo '<th>' . esc_html( $gateway->get_label_card_difference() ) . ' (' . number_format( $breakdown['card_difference_percent'], 2 ) . '%)</th>';
			echo '<td>' . wc_price( $breakdown['card_difference_amount'] ) . '</td>';
			echo '</tr>';
		}
	}

	/**
	 * Add surcharge and card difference to calculated total.
	 *
	 * @param float $total Calculated total.
	 * @return float
	 */
	public static function adjust_calculated_total( float $total ): float {
		if ( ! self::is_plugin_active() || ! WC()->session ) {
			return $total;
		}

		if ( self::get_checkout_payment_method() !== 'bmspay_blackstone_payment' ) {
			return $total;
		}

		$gateway = new BMSPay_Blackstone_Payment();
		$breakdown = bmspay_get_cart_charge_breakdown();

		if ( $breakdown['surcharge_amount'] > 0 ) {
			WC()->session->set( 'bmspay_surcharge_amount', $breakdown['surcharge_amount'] );
			WC()->session->set( 'bmspay_surcharge_percent', $breakdown['surcharge_percent'] );
			$total += $breakdown['surcharge_amount'];
		} else {
			WC()->session->set( 'bmspay_surcharge_amount', null );
			WC()->session->set( 'bmspay_surcharge_percent', null );
		}

		if ( $breakdown['card_difference_amount'] > 0 ) {
			WC()->session->set( 'bmspay_card_difference_amount', $breakdown['card_difference_amount'] );
			WC()->session->set( 'bmspay_card_difference_percent', $breakdown['card_difference_percent'] );
			$total += $breakdown['card_difference_amount'];
		} else {
			WC()->session->set( 'bmspay_card_difference_amount', null );
			WC()->session->set( 'bmspay_card_difference_percent', null );
		}

		return $total;
	}

	/**
	 * Save surcharge and card difference metadata to order.
	 *
	 * @param int   $order_id Order ID.
	 * @param array $data     Checkout data.
	 * @return void
	 */
	public static function save_order_meta( int $order_id, array $data ): void {
		if ( ! self::is_plugin_active() || ! WC()->session ) {
			return;
		}

		$payment_method = isset( $data['payment_method'] )
			? sanitize_text_field( wp_unslash( $data['payment_method'] ) )
			: '';

		if ( $payment_method !== 'bmspay_blackstone_payment' ) {
			return;
		}

		$gateway = new BMSPay_Blackstone_Payment();
		$breakdown = bmspay_get_cart_charge_breakdown();

		$order = wc_get_order( $order_id );

		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( $breakdown['surcharge_amount'] > 0 ) {
			$order->update_meta_data( '_bmspay_surcharge_amount', bmspay_format_decimal_amount( $breakdown['surcharge_amount'] ) );
			$order->update_meta_data( '_bmspay_surcharge_percent', $breakdown['surcharge_percent'] );
		}

		if ( $breakdown['card_difference_amount'] > 0 ) {
			$order->update_meta_data( '_bmspay_card_difference_amount', bmspay_format_decimal_amount( $breakdown['card_difference_amount'] ) );
			$order->update_meta_data( '_bmspay_card_difference_percent', $breakdown['card_difference_percent'] );
		}

		// The woocommerce_calculated_total filter already added the fee to the cart total,
		// so $order->get_total() already includes it. No set_total() needed here.
		$order->save();
	}

	/**
	 * Display surcharge and card difference in order totals (Order Received, emails).
	 *
	 * @param array    $totals      Order totals array.
	 * @param WC_Order $order       Order object.
	 * @param string   $tax_display Tax display mode.
	 * @return array
	 */
	public static function display_order_item_totals( array $totals, $order, string $tax_display ): array {
		if ( ! self::is_plugin_active() ) {
			return $totals;
		}

		if ( ! $order instanceof WC_Order ) {
			return $totals;
		}

		if ( $order->get_payment_method() !== 'bmspay_blackstone_payment' ) {
			return $totals;
		}

		$surcharge_amount        = (float) ( $order->get_meta( '_bmspay_surcharge_amount', true ) ?: 0 );
		$surcharge_percent       = (float) ( $order->get_meta( '_bmspay_surcharge_percent', true ) ?: 0 );

		$card_difference_amount  = (float) ( $order->get_meta( '_bmspay_card_difference_amount', true ) ?: 0 );
		$card_difference_percent = (float) ( $order->get_meta( '_bmspay_card_difference_percent', true ) ?: 0 );

		if ( $surcharge_amount <= 0 && $card_difference_amount <= 0 ) {
			return $totals;
		}

		$gateway = new BMSPay_Blackstone_Payment();
		$new_totals = array();

		foreach ( $totals as $key => $total ) {
			if ( $key === 'order_total' ) {
				if ( $surcharge_amount ) {
					$new_totals['bmspay_surcharge'] = array(
						'label' => $gateway->get_label_surcharge() . ' (' . number_format( (float) $surcharge_percent, 2 ) . '%)',
						'value' => wc_price( (float) $surcharge_amount, array( 'currency' => $order->get_currency() ) ),
					);
				}

				if ( $card_difference_amount ) {
					$new_totals['bmspay_card_difference'] = array(
						'label' => $gateway->get_label_card_difference() . ' (' . number_format( (float) $card_difference_percent, 2 ) . '%)',
						'value' => wc_price( (float) $card_difference_amount, array( 'currency' => $order->get_currency() ) ),
					);
				}
			}

			$new_totals[ $key ] = $total;
		}

		return $new_totals;
	}

	/**
	 * Display surcharge and card difference in admin order totals.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public static function display_admin_order_totals( int $order_id ): void {
		if ( ! self::is_plugin_active() ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( $order->get_payment_method() !== 'bmspay_blackstone_payment' ) {
			return;
		}

		$surcharge_amount        = $order->get_meta( '_bmspay_surcharge_amount', true );
		$surcharge_percent       = $order->get_meta( '_bmspay_surcharge_percent', true );

		$card_difference_amount  = $order->get_meta( '_bmspay_card_difference_amount', true );
		$card_difference_percent = $order->get_meta( '_bmspay_card_difference_percent', true );

		if ( ! $surcharge_amount && ! $card_difference_amount ) {
			return;
		}

		$gateway = new BMSPay_Blackstone_Payment();
		?>

		<?php if ( $surcharge_amount ) : ?>
		<tr>
			<td class="label"><?php echo esc_html( $gateway->get_label_surcharge() ); ?>:</td>
			<td width="1%"></td>
			<td class="total">
				<span class="woocommerce-Price-amount amount">
					<?php echo wc_price( $surcharge_amount ); ?>
					<?php if ( $surcharge_percent ) : ?>
						<span class="bmspay-percent"> (<?php echo esc_html( number_format( (float) $surcharge_percent, 2 ) ); ?>%)</span>
					<?php endif; ?>
				</span>
			</td>
		</tr>
		<?php endif; ?>

		<?php if ( $card_difference_amount ) : ?>
		<tr>
			<td class="label"><?php echo esc_html( $gateway->get_label_card_difference() ); ?>:</td>
			<td width="1%"></td>
			<td class="total">
				<span class="woocommerce-Price-amount amount">
					<?php echo wc_price( $card_difference_amount ); ?>
					<?php if ( $card_difference_percent ) : ?>
						<span class="bmspay-percent"> (<?php echo esc_html( number_format( (float) $card_difference_percent, 2 ) ); ?>%)</span>
					<?php endif; ?>
				</span>
			</td>
		</tr>
		<?php endif; ?>

		<?php
	}

	/**
	 * Recalculate order total with surcharge when status changes.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public static function recalculate_with_fees( int $order_id ): void {
		if ( ! self::is_plugin_active() ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( $order->get_payment_method() !== 'bmspay_blackstone_payment' ) {
			return;
		}

		$overrides = bmspay_get_charge_overrides_from_order_meta( $order_id );

		$charge_breakdown = bmspay_get_order_charge_breakdown( $order, null, $overrides );

		$order->set_total( $charge_breakdown['total'] );

		$order->update_meta_data( '_bmspay_surcharge_amount', bmspay_format_decimal_amount( $charge_breakdown['surcharge_amount'] ) );
		$order->update_meta_data( '_bmspay_card_difference_amount', bmspay_format_decimal_amount( $charge_breakdown['card_difference_amount'] ) );

		$order->save();
	}

	/**
	 * Adjust order totals when WooCommerce recalculates.
	 *
	 * @param bool     $and_taxes Whether to recalculate taxes.
	 * @param WC_Order $order     Order object.
	 * @return void
	 */
	public static function adjust_order_totals( bool $and_taxes, $order ): void {
		if ( ! self::is_plugin_active() ) {
			return;
		}

		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( $order instanceof WC_Order_Refund ) {
			return;
		}

		if ( $order->get_payment_method() !== 'bmspay_blackstone_payment' ) {
			return;
		}

		$order_id  = $order->get_id();
		$overrides = bmspay_get_charge_overrides_from_order_meta( $order_id );

		// No meta saved yet — order is being created for the first time. WooCommerce
		// already has the correct total from the cart (adjust_calculated_total ran earlier).
		// Touching the total here would overwrite it with a zero-fee recalculation.
		if ( empty( $overrides ) ) {
			return;
		}

		$charge_breakdown = bmspay_get_order_charge_breakdown( $order, null, $overrides );

		$order->set_total( $charge_breakdown['total'] );

		$order->update_meta_data( '_bmspay_surcharge_amount', bmspay_format_decimal_amount( $charge_breakdown['surcharge_amount'] ) );
		$order->update_meta_data( '_bmspay_card_difference_amount', bmspay_format_decimal_amount( $charge_breakdown['card_difference_amount'] ) );

		$order->save();
	}

	/**
	 * Display save card checkbox on checkout and order pay pages.
	 *
	 * @return void
	 */
	public static function display_save_card_option(): void {
		if ( ! self::is_plugin_active() ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			return;
		}

		$payment_method = '';

		if ( function_exists( 'is_order_pay_page' ) && is_order_pay_page() ) {
			global $wp;
			if ( isset( $wp->query_vars['order-pay'] ) ) {
				$order_id = absint( $wp->query_vars['order-pay'] );
				$order    = wc_get_order( $order_id );
				if ( $order ) {
					$payment_method = $order->get_payment_method();
				}
			}
		} else {
			$payment_method = isset( $_POST['payment_method'] )
				? sanitize_text_field( wp_unslash( $_POST['payment_method'] ) )
				: '';
		}

		if ( $payment_method !== 'bmspay_blackstone_payment' ) {
			return;
		}

		echo '<p class="form-row woocommerce-SavedPaymentMethods-saveNew">';
		woocommerce_form_field(
			'save_card',
			array(
				'type'  => 'checkbox',
				'class' => array( 'form-row-wide' ),
				'label' => __( 'Save card for future purchases', 'blackstone-online-gateway' ),
			),
			false
		);
		echo '</p>';
	}

	/**
	 * Add hidden field for 3DS response.
	 *
	 * @param object $checkout Checkout object.
	 * @return void
	 */
	public static function add_threeds_hidden_field( $checkout ): void {
		if ( ! self::is_plugin_active() ) {
			return;
		}

		echo '<input type="hidden" name="threeds_response" id="threeds_response" value="">';
	}

	/**
	 * Conditionally load SweetAlert2 - only load if 3DS is enabled.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_sweetalert2(): void {
		if ( ! self::is_plugin_active() ) {
			return;
		}

		if ( ! is_checkout() && ( ! function_exists( 'is_order_pay_page' ) || ! is_order_pay_page() ) ) {
			return;
		}

		$gateway = new BMSPay_Blackstone_Payment();
		$surcharge_data = $gateway->get_cached_surcharge_data();
		$threeds_enabled = ! empty( $surcharge_data['response_ThreeDSecureEnabled'] );

		if ( ! $threeds_enabled ) {
			return;
		}

		wp_enqueue_script(
			'sweetalert2',
			plugins_url( 'assets/js/sweetalert2_11.js', __FILE__ ),
			array( 'jquery' ),
			'11.0.0',
			true
		);
	}

	/**
	 * Reorder payment methods menu item in My Account.
	 *
	 * @param array $items Menu items.
	 * @return array
	 */
	public static function reorder_payment_methods_menu( array $items ): array {
		if ( ! self::is_plugin_active() ) {
			return $items;
		}

		if ( isset( $items['payment-methods'] ) ) {
			unset( $items['payment-methods'] );
		}

		$logout = isset( $items['customer-logout'] ) ? $items['customer-logout'] : '';
		if ( $logout ) {
			unset( $items['customer-logout'] );
		}

		$items['payment-methods'] = __( 'Payment methods', 'blackstone-online-gateway' );

		if ( $logout ) {
			$items['customer-logout'] = $logout;
		}

		return $items;
	}

	/**
	 * Force order total recalculation when the customer loads the pay-for-order page.
	 *
	 * Runs early on template_redirect — before wp_enqueue_scripts — so the 3DS
	 * authentication and the rendered totals all use the correct amount even when
	 * the admin modified items without clicking "Recalculate".
	 *
	 * @return void
	 */
	public static function ensure_pay_page_total_consistency_on_load(): void {
		if ( ! self::is_plugin_active() ) {
			return;
		}

		if ( ! function_exists( 'is_wc_endpoint_url' ) || ! is_wc_endpoint_url( 'order-pay' ) ) {
			return;
		}

		global $wp;
		$order_id = isset( $wp->query_vars['order-pay'] ) ? absint( $wp->query_vars['order-pay'] ) : 0;
		if ( ! $order_id ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( $order->get_payment_method() !== 'bmspay_blackstone_payment' ) {
			return;
		}

		bmspay_ensure_order_total_consistency( $order );
	}
}

add_action( 'woocommerce_review_order_before_order_total', array( 'Bmspay_Checkout_Display', 'display_surcharge_in_checkout' ) );
add_filter( 'woocommerce_calculated_total', array( 'Bmspay_Checkout_Display', 'adjust_calculated_total' ), 20 );
add_action( 'woocommerce_checkout_update_order_meta', array( 'Bmspay_Checkout_Display', 'save_order_meta' ), 10, 2 );
add_filter( 'woocommerce_get_order_item_totals', array( 'Bmspay_Checkout_Display', 'display_order_item_totals' ), 10, 3 );
add_action( 'woocommerce_admin_order_totals_after_tax', array( 'Bmspay_Checkout_Display', 'display_admin_order_totals' ) );
add_action( 'woocommerce_order_status_processing_to_pending', array( 'Bmspay_Checkout_Display', 'recalculate_with_fees' ), 10, 1 );
add_action( 'woocommerce_order_after_calculate_totals', array( 'Bmspay_Checkout_Display', 'adjust_order_totals' ), 10, 2 );

add_action( 'woocommerce_after_order_notes', array( 'Bmspay_Checkout_Display', 'add_threeds_hidden_field' ) );
add_filter( 'woocommerce_account_menu_items', array( 'Bmspay_Checkout_Display', 'reorder_payment_methods_menu' ) );
add_action( 'template_redirect', array( 'Bmspay_Checkout_Display', 'ensure_pay_page_total_consistency_on_load' ), 5 );

/**
 * AJAX handler for client-side 3DS log events.
 * Receives sanitized level/message from the browser and writes to the gateway log.
 */
function bmspay_handle_3ds_client_log() {
	if ( ! check_ajax_referer( 'bmspay_3ds_client_log', 'nonce', false ) ) {
		wp_die( 0 );
	}

	$level   = isset( $_POST['level'] ) ? sanitize_key( $_POST['level'] ) : 'debug';
	$message = isset( $_POST['message'] ) ? substr( sanitize_text_field( wp_unslash( $_POST['message'] ) ), 0, 500 ) : '';

	if ( empty( $message ) ) {
		wp_die( 0 );
	}

	$allowed_levels = array( 'debug', 'info', 'warning', 'error' );
	if ( ! in_array( $level, $allowed_levels, true ) ) {
		$level = 'debug';
	}

	Bmspay_Logger::$level( '[JS] ' . $message, 'bmspay-gateway' );

	wp_send_json_success();
}
add_action( 'wp_ajax_bmspay_3ds_client_log', 'bmspay_handle_3ds_client_log' );
add_action( 'wp_ajax_nopriv_bmspay_3ds_client_log', 'bmspay_handle_3ds_client_log' );

/**
 * AJAX handler to force-refresh 3DS credentials when the JS SDK gets a 401.
 * Returns fresh apiKey + token so the client can retry the verify() call.
 */
function bmspay_handle_3ds_token_refresh() {
	if ( ! check_ajax_referer( 'bmspay_3ds_refresh_token', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => 'Invalid nonce' ), 403 );
	}

	$rate_key = 'bmspay_3ds_refresh_' . md5( session_id() ?: ( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown' ) );
	if ( get_transient( $rate_key ) ) {
		wp_send_json_error( array( 'message' => 'Too many refresh requests. Please wait before retrying.' ), 429 );
	}
	set_transient( $rate_key, 1, 60 );

	$gateways = WC()->payment_gateways()->payment_gateways();
	if ( ! isset( $gateways['bmspay_blackstone_payment'] ) ) {
		wp_send_json_error( array( 'message' => 'Gateway not available' ), 500 );
	}

	$gateway = $gateways['bmspay_blackstone_payment'];
	$result  = $gateway->refresh_3ds_token();

	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => $result->get_error_message() ), 502 );
	}

	wp_send_json_success( $result );
}
add_action( 'wp_ajax_bmspay_3ds_refresh_token', 'bmspay_handle_3ds_token_refresh' );
add_action( 'wp_ajax_nopriv_bmspay_3ds_refresh_token', 'bmspay_handle_3ds_token_refresh' );
