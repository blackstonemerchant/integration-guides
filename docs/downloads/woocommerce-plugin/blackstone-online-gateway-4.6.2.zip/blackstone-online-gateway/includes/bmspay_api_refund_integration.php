<?php
if (!defined('ABSPATH')) {
    exit;
}

class BMSPAY_API_Refund_Integration
{
    public function __construct()
    {
        add_action('admin_print_footer_scripts', [$this, 'add_api_refund_button']);
        add_action('wp_ajax_process_api_refund', [$this, 'bmspay_process_api_refund']);
        add_action('woocommerce_order_refunded', [$this, 'clear_cache_on_refund'], 10, 2);
    }
    public function clear_cache_on_refund($order_id, $refund_id)
    {
        clean_post_cache($order_id);
        wp_cache_delete($order_id, 'posts');
        wp_cache_delete($order_id, 'post_meta');
        wc_delete_shop_order_transients($order_id);
    }

    public function add_api_refund_button()
    {
        $order_id = null;
        if (isset($_GET['post']) && get_post_type(sanitize_text_field(wp_unslash($_GET['post']))) === 'shop_order') {
            $order_id = absint($_GET['post']);
        }

        if (isset($_GET['page'], $_GET['id']) && $_GET['page'] === 'wc-orders') {
            $order_id = absint($_GET['id']);
        }

        if (!$order_id) {
            return;
        }

        $order = wc_get_order($order_id);

        if (!$order || !is_a($order, 'WC_Order')) {
            return;
        }

        if (!$this->should_show_api_refund_button($order)) {
            return;
        }

        $order_id = $order->get_id();
        $buttonText = (get_locale() === 'es_ES') ? 'Reembolsar con Blackstone' : 'Blackstone Refund';

        
        // Enqueue SweetAlert2 if not already enqueued
        wp_enqueue_script('sweetalert2', plugins_url('../assets/js/sweetalert2_11.js', __FILE__), ['jquery'], '11.0.0', true);

        // Enqueue Admin Refund Script
        wp_enqueue_script('bmspay-admin-refund', plugins_url('../assets/js/bmspay-admin-refund.js', __FILE__), ['jquery', 'sweetalert2'], '1.0.0', true);

        // Localize Script
        wp_localize_script('bmspay-admin-refund', 'bmspay_refund_params', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'security' => wp_create_nonce("api-refund-nonce"),
            'order_id' => $order_id,
            'buttonText' => $buttonText
        ]);
    }

    private function should_show_api_refund_button($order)
    {
        if (!$order || !is_a($order, 'WC_Order')) {
            return false;
        }

        if ($order->get_payment_method() !== 'bmspay_blackstone_payment') {
            return false;
        }

        if ($this->is_refund_order($order)) {
            return false;
        }

        if ($this->get_remaining_balance($order) <= 0) {
            return false;
        }

        return true;
    }
    public function bmspay_process_api_refund()
    {
        check_ajax_referer('api-refund-nonce', 'security');
        $order_id = isset($_POST['order_id']) ? sanitize_text_field(wp_unslash($_POST['order_id'])) : '';
        $order_id = absint($order_id);
        $order = wc_get_order($order_id);

        if (!$order || !is_a($order, 'WC_Order')) {
            wp_send_json_error(['message' => 'Pedido no encontrado']);
        }

        $data = $this->parse_refund_items($_POST, $order);

        $api_result = $this->process_in_blackstone_api($order, $data);

        if ($api_result['success']) {
            wp_send_json_success(['message' => $api_result['message']]);
        } else {
            wp_send_json_error(['message' => $api_result['message']]);
        }
    }

    private function process_in_blackstone_api($order, $data)
    {
        try {
            $api_response = $this->process_refund_request($order, $data['amount'], $data['restock'] ?? false, $data['items']);

            if (!$api_response['success']) {
                return ['success' => false, 'message' => $api_response['message']];
            } else {
                return ['success' => true, 'message' => $api_response['message']];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    protected function parse_refund_items($post_data, $order)
    {
        $refund_data = [
            'amount' => wc_format_decimal($post_data['refund_amount']),
            'reason' => sanitize_text_field($post_data['refund_reason']),
            'restock_items' => isset($post_data['restock_items']) && $post_data['restock_items'] == 1,
            'items' => []
        ];

        if (!empty($post_data['line_items'])) {
            $line_items = json_decode(stripslashes($post_data['line_items']), true);

            foreach ($line_items as $item) {
                $refund_data['items'][$item['id']] = [
                    'qty' => absint($item['qty']),
                    'refund_total' => wc_format_decimal($item['total'] ?? 0),
                    'refund_tax' => !empty($item['tax']) ? array_map('wc_format_decimal', (array)$item['tax']) : []
                ];
            }
        }
        if (empty($refund_data['items'])) {
            foreach ($order->get_items() as $item_id => $item) {
                $qty_purchased = $item->get_quantity();
                $qty_already_refunded = $order->get_qty_refunded_for_item($item_id);
                $qty_to_refund = $qty_purchased - $qty_already_refunded;
                if ($qty_to_refund > 0) {
                    $refund_total = wc_format_decimal(
                        $item->get_total() - $order->get_total_refunded_for_item($item_id)
                    );
                    $refund_tax = array_map(
                        'wc_format_decimal',
                        $item->get_taxes()['total'] ?? []
                    );
                    $refund_data['items'][$item_id] = [
                        'qty'          => $qty_to_refund,
                        'refund_total' => $refund_total,
                        'refund_tax'   => $refund_tax,
                    ];
                }
            }
        }
        return $refund_data;
    }

    private function is_refund_order($order)
    {
        if (is_numeric($order)) {
            $order = wc_get_order($order);
        }
        if (!$order || !is_a($order, 'WC_Order')) {
            return false;
        }

        return $this->get_remaining_balance($order) == 0;
    }

    public function get_remaining_balance($order)
    {
        if (is_numeric($order)) {
            $order = wc_get_order($order);
        }
        if (!$order || !is_a($order, 'WC_Order')) {
            return 0;
        }

        return $order->get_total() - $order->get_total_refunded();
    }

    public function process_refund_request($order, $refund_amount = null, $restock = false, $items = [])
    {
        if (empty($items)) {
            return [
                "success" => false,
                'message' => 'El pedido no tiene artículos que puedan ser reembolsados.'
            ];
        }
        if (is_numeric($order)) {
            $order = wc_get_order($order);
        }

        if (!$order || !is_a($order, 'WC_Order')) {
            return ["success" => false, 'message' => 'Invalid order object'];
        }

        if ($this->is_refund_order($order)) {
            return ["success" => false, 'message' => 'Order already refunded'];
        }

        $payment_gateways = WC_Payment_Gateways::instance()->payment_gateways();
        $blackstone_gateway = $payment_gateways['bmspay_blackstone_payment'];
        $service_reference_number = $order->get_meta('_bmspay_service_reference_number');

        $environment_url = 'https://services.bmspay.com/api/Transactions/DoRefund';

        $data = [
            'Amount' => $refund_amount ?? $order->get_total(),
            'TrackData' => '',
            'UserTransactionNumber' => md5(uniqid($service_reference_number . $environment_url, true)),
            'ServiceTransactionNumber' => $service_reference_number,
            'SURI' => '',
            'AppKey' => $blackstone_gateway->environment == 'yes' ? "12345" : $blackstone_gateway->app_key,
            'AppType' => $blackstone_gateway->environment == 'yes' ? "1" : $blackstone_gateway->app_type,
            'mid' => $blackstone_gateway->environment == 'yes' ? "76074" : $blackstone_gateway->api_mid,
            'cid' => $blackstone_gateway->environment == 'yes' ? "260" : $blackstone_gateway->api_cid,
            'UserName' => $blackstone_gateway->environment == 'yes' ? "nicolas" : $blackstone_gateway->api_username,
            'Password' => $blackstone_gateway->environment == 'yes' ? "password1" : $blackstone_gateway->api_password,
            'IpAddress' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '',
            'IsTest' => $blackstone_gateway->environment == 'yes' ? "True" : "False",
        ];

        $response = wp_remote_post($environment_url, [
            'method' => 'POST',
            'headers' => ['Content-Type' => 'application/json'],
            'body' => json_encode($data),
        ]);

        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        if (isset($response_data['ResponseCode']) && $response_data['ResponseCode'] == "200") {

            if (is_numeric($order)) {
                $order = wc_get_order($order);
            }

            if (!$order || !is_a($order, 'WC_Order')) {
                return [
                    "success" => false,
                    'message' => 'No se pudo cargar el pedido para el reembolso.'
                ];
            }

            if (empty($items)) {
                return [
                    "success" => false,
                    'message' => 'El pedido no tiene artículos que puedan ser reembolsados.'
                ];
            }

            if (isset($response_data['ServiceReferenceNumber'])) {
                $ServiceReferenceNumber = $response_data['ServiceReferenceNumber'];
                $order->update_meta_data('_bmspay_service_reference_number', $ServiceReferenceNumber);
                $order->add_order_note(__('Transaction ID: ', 'blackstone-online-gateway') . $ServiceReferenceNumber);
            }

            if (isset($data['UserTransactionNumber'])) {
                $UserTransactionNumber = $data['UserTransactionNumber'];
                $order->update_meta_data('_bmspay_transaction_number', $UserTransactionNumber);
                $order->add_order_note(__('User Transaction Number: ', 'blackstone-online-gateway') . $UserTransactionNumber);
            }

            $refund = wc_create_refund([
                'amount' => $refund_amount ?? $order->get_total(),
                'reason' => (get_locale() === 'es_ES') ? 'Reembolso procesado vía API.' : 'Refund processed via API.',
                'order_id' => $order->get_id(),
                'refund_payment' => false,
                'restock_items' => $restock,
                'line_items'     => $items,
            ]);

            if (is_wp_error($refund)) {
                return ["success" => false, 'message' => 'Error al crear el reembolso: ' . $refund->get_error_message()];
            }

            if (!$refund || !is_a($refund, 'WC_Order_Refund')) {
                return ["success" => false, 'message' => 'No se pudo crear un objeto de reembolso válido.'];
            }

            if ($restock) {
                $note = (get_locale() === 'es_ES')
                    ? 'Artículos reembolsados repuestos automáticamente en inventario.'
                    : 'Refunded items were restocked automatically.';
                $order->add_order_note($note);
            }

            if ($refund_amount < $order->get_total()) {
                /* translators: %s: refunded amount */
                $order->add_order_note(sprintf(__('Partial refund of %s via API', 'blackstone-online-gateway'), wc_price($refund_amount)));
            } else {
                /* translators: %s: refunded amount */
                $order->add_order_note(sprintf(__('Total refund of %s via API', 'blackstone-online-gateway'), wc_price($refund_amount)));
                $order->update_status('refunded');
            }

            if (isset($refund) && is_a($refund, 'WC_Order_Refund') && isset($order) && is_a($order, 'WC_Order')) {

                if (
                    is_object($refund) && $refund instanceof WC_Order_Refund &&
                    is_object($order) && $order instanceof WC_Order
                ) {
                    // set IDs
                    $order_id = $order->get_id();
                    $refund_id = $refund->get_id();

                    // Limpieza de caché y transients
                    delete_transient('wc_order_data_' . $order_id);
                    wc_delete_shop_order_transients($order_id);

                    // Limpia caché de post y post_meta por si Object Cache Pro los mantiene en memoria
                    clean_post_cache($order_id);
                    wp_cache_delete($order_id, 'posts');
                    wp_cache_delete($order_id, 'post_meta');

                    // También puedes eliminar caché del refund si es necesario
                    clean_post_cache($refund_id);
                    wp_cache_delete($refund_id, 'posts');
                    wp_cache_delete($refund_id, 'post_meta');

                    $order->save();
                }
            }
            $order->save();

            $msg = __('Refund completed successfully', 'blackstone-online-gateway');
            return [
                "success" => true,
                'message' => "$msg, Ref: $service_reference_number"
            ];
        } else {
            return [
                "success" => false,
                'message' => $this->get_message_error($response_data) . ", Ref: $service_reference_number"
            ];
        }
    }

    public function get_message_error($response_data)
    {
        $msg = __('No message provided', 'blackstone-online-gateway');

        if (isset($response_data['Msg']) && is_array($response_data['Msg'])) {
            $msg = implode(', ', $response_data['Msg']);
        }
        return $msg;
    }
}
add_action('admin_init', 'fix_wc_order_object_error');
function fix_wc_order_object_error()
{
    if (is_admin() && isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
        $order_id = absint($_GET['id']);
        $order = wc_get_order($order_id);

        if (is_numeric($order) || !is_a($order, 'WC_Order')) {
            clean_post_cache($order_id);
            wp_cache_delete($order_id, 'posts');
            wp_cache_delete($order_id, 'post_meta');
            $order = wc_get_order($order_id);
        }
    }
}
add_action('woocommerce_order_refunded', 'clear_cache_refund', 10, 2);

function clear_cache_refund($order_id, $refund_id)
{
    $order = wc_get_order($order_id);
    $refund = wc_get_order($refund_id);

    if (
        is_a($order, 'WC_Order') &&
        is_a($refund, 'WC_Order_Refund')
    ) {
        // error_log('Iniciando limpieza de caché...');
        // error_log('Order ID: ' . $order_id);
        // error_log('Refund ID: ' . $refund_id);
        // Limpieza de transients y caché
        delete_transient('wc_order_data_' . $order_id);
        wc_delete_shop_order_transients($order_id);

        clean_post_cache($order_id);
        wp_cache_delete($order_id, 'posts');
        wp_cache_delete($order_id, 'post_meta');

        clean_post_cache($refund_id);
        wp_cache_delete($refund_id, 'posts');
        wp_cache_delete($refund_id, 'post_meta');

        $order->save();

        //error_log("Cache limpiada para la orden $order_id y reembolso $refund_id");
    }
}


new BMSPAY_API_Refund_Integration();
