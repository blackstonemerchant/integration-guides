jQuery(document).ready(function($) {
    var canSubmitForm = false;

    // Determinar si es página de pago de pedido
    var isPayForOrder = window.location.href.indexOf('order-pay') !== -1;

    // Seleccionar el formulario correcto
    var $form = isPayForOrder ? $('#order_review') : $('form.checkout');

    function getSubmitButton() {
        if (isPayForOrder) {
            return $('#place_order');
        }

        var $btn = $('#place_order');
        if ($btn.length === 0) {
            $btn = $('button[name="woocommerce_checkout_place_order"]');
        }
        if ($btn.length === 0) {
            $btn = $('form.checkout').find('button[type="submit"]');
        }
        return $btn;
    }

    function enableSubmitButton() {
        var $submitBtn = getSubmitButton();
        if ($submitBtn.length) {
            $submitBtn.prop('disabled', false);
        }
        $('.woocommerce-ajax-loader').hide();
    }

    function disableSubmitButton() {
        var $submitBtn = getSubmitButton();
        if ($submitBtn.length) {
            $submitBtn.prop('disabled', true);
        }
        $('.woocommerce-ajax-loader').show();
    }

    function cleanup3DS() {
        $('iframe[id^="container-challenge-3ds"]').remove();
        $('#billing-form').remove();

        if (window.Swal && window.Swal.getPopup()) {
            window.Swal.close();
        }
        window.tds = undefined;
    }

    $form.on('submit', function(e) {
        if ($('input[name="payment_method"]:checked').val() === 'bmspay_blackstone_payment') {
                if (!canSubmitForm) {
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    disableSubmitButton();

                    var cardNumber = $('#bmspay_blackstone_payment-card-number').val().replace(/\s+/g, '');
                    var expiry = $('#bmspay_blackstone_payment-card-expiry').val().replace(/\s+/g, '');
                    var month = expiry.substring(0, 2);
                    var year = expiry.substring(3, 5);
                    var cvv = $('#bmspay_blackstone_payment-card-cvc').val();
                    var billingPostCode = $('#billing_postcode').val();
                    var cardHolderName = $('#billing_first_name').val() + ' ' + $('#billing_last_name').val();

                    
                    const $tempForm = $('<form id="billing-form" style="display:none;"></form>').appendTo('body');
                    $tempForm.append('<input type="text" id="billing-card-amount" name="billing-card-amount" value="' + bmspay_checkout_params.total + '" data-threeds="amount" />');
                    $tempForm.append('<input type="text" id="billing-card-pan" name="billing-card-pan" value="' + cardNumber + '" data-threeds="pan" />');
                    $tempForm.append('<input type="text" id="billing-card-month" name="billing-card-month" value="' + month + '" data-threeds="month"/>');
                    $tempForm.append('<input type="text" id="billing-card-year" name="billing-card-year" value="' + year + '" data-threeds="year"/>');
                    $tempForm.append('<input type="text" id="billing-card-cvv" name="billing-card-cvv" value="' + cvv + '" data-threeds="cvv"/>');
                    $tempForm.append('<input type="text" id="billing-card-billing-post-code" name="billing-card-billing-post-code" value="' + billingPostCode + '" data-threeds="billingPostCode"/>');
                    $tempForm.append('<input type="text" id="billing-card-holder-name" name="billing-card-holder-name" value="' + cardHolderName + '" data-threeds="cardHolderName"/>');

                function initialize3DS() {
                    const uniqueId = Date.now();
                    const iframeId = 'container-challenge-3ds-' + uniqueId;
                    const wrapperId = 'challenge-wrapper-' + uniqueId;
                    const loaderId = 'challenge-loader-' + uniqueId;

                    // Improved HTML structure matching original design
                    var html_3ds = `
                        <div class="threeds-modal-content">
                            <div style="width: 100%; height: 430px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9; position: relative; margin: 0 auto;">
                                <div id="${wrapperId}" class="threeds-loading" 
                                    style="width: 100%; height: 100%; position: relative;">
                                </div>
                                <div id="${loaderId}" class="threeds-loading" 
                                    style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
                                    <div class="spinner"></div>
                                    <p style="margin-top: 8px; color: #555;">Procesando verificación de seguridad...</p>
                                </div>
                            </div>
                            <p style="margin-top: 15px; font-size: 12px; color: #666; text-align: center;">
                                Por favor no cierre esta ventana.
                            </p>
                        </div>
                    `;

                     Swal.fire({
                        title: 'Verificación 3D Secure',
                        html: html_3ds,
                        showConfirmButton: false,
                        showCloseButton: false, // Original had false? The user code didn't explicitly show close button but 'allowOutsideClick' false. Code says `showCloseButton: true` in my previous edit but let's stick to what I see or safer defaults. User JS had: showCloseButton not listed, so false default. But wait, `showCloseButton` was not in user snippet. I'll stick to good UX - usually safer to NOT have it or have it if user gets stuck. User snippet: showConfirmButton: false. I will add showCloseButton: true for safety unless requested otherwise, but user snippet didn't have it.
                        // Actually, user snippet had `showConfirmButton: false`.
                        width: 500,
                        padding: '10px',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        customClass: {
                            container: 'threeds-modal',
                            popup: 'threeds-popup',
                            header: 'threeds-header'
                        },
                        didOpen: () => {
                            const wrapper = document.getElementById(wrapperId);
                            
                            const iframe = document.createElement('iframe');
                            iframe.id = iframeId;
                            iframe.name = iframeId;
                            // Inline styles to ensure overriding
                            iframe.style.cssText = `
                                width: 420px !important;
                                height: 420px !important;
                                min-width: 420px !important;
                                min-height: 420px !important;
                                max-width: 420px !important;
                                max-height: 420px !important;
                                border: none !important;
                                opacity: 0 !important;
                                display: block !important;
                                position: relative !important;
                                transition: opacity 0.3s ease !important;
                            `;
                            
                            if (wrapper) {
                                wrapper.appendChild(iframe);
                            }

                             var apiKey = bmspay_checkout_params.apiKey;
                             var token = bmspay_checkout_params.token;

                             // Initialize ThreeDS with the iframe ID
                             window.tds = new ThreeDS(
                                "billing-form",
                                apiKey,
                                token,
                                {
                                    endpoint: bmspay_checkout_params.endpoint,
                                    autoSubmit: false,
                                    showChallenge: true,
                                    popup: false,
                                    iframeId: iframeId, 
                                    forcedTimeOut: '10'
                                }
                            );
                            
                            // Handling iframe load event manually if needed, or relying on ThreeDS lib. 
                            // The original code appended the iframe and set `window.currentIframe`.
                            // Let's add the simple onload fade-in.
                            iframe.onload = () => {
                                const loader = document.getElementById(loaderId);
                                if (loader) loader.style.display = 'none';
                                iframe.style.opacity = '1';
                            };

                            window.tds.verify(
                                function(response) {
                                    // Success Handler
                                    var $tempForm = $('#billing-form');

                                    if (!response || (response.status !== 'Y' && response.status !== 'A')) {
                                        var errorMessage = '3D Secure Verification Failed';
                                        if (response && response.transStatusReasonDetail) {
                                            errorMessage += ': ' + response.transStatusReasonDetail;
                                        }
                                        $tempForm.remove();
                                        Swal.close(); 
                                        
                                        if (typeof Swal !== 'undefined') {
                                            Swal.fire('Error', errorMessage, 'error');
                                        } else {
                                            alert(errorMessage);
                                        }
                                        enableSubmitButton();
                                        return false;
                                    }

                                    const threeDsTransactionId = window.tds.threeDsTransactionId;

                                    if (threeDsTransactionId) {
                                        response.threeDsTransactionId = threeDsTransactionId;
                                    }

                                    $tempForm.remove();
                                    canSubmitForm = true;
                                    Swal.close();

                                    var $targetForm = isPayForOrder ? $('#order_review') : $('form.checkout');

                                    if (!$targetForm.find('input[name=threeds_response]').length) {
                                        $('<input>').attr({
                                            type: 'hidden',
                                            name: 'threeds_response',
                                            value: JSON.stringify(response)
                                        }).appendTo($targetForm);
                                    } else {
                                        $targetForm.find('input[name=threeds_response]').val(JSON.stringify(response));
                                    }

                                    cleanup3DS();
                                    $targetForm.submit();
                                    enableSubmitButton();
                                },
                                function(error) {
                                    // Error Handler
                                    let errorObj = error;
                                    if (typeof error === 'string') {
                                        try {
                                            errorObj = JSON.parse(error);
                                        } catch (e) {
                                            console.warn('El error no es un JSON válido', error);
                                        }
                                    }
                                    let errorMessage = errorObj.error || errorObj.message || 'An error occurred during payment verification. Please try again.';
                                    
                                     if (errorMessage !== 'No result found for transaction as yet. Please subscribe again') {
                                         Swal.close(); 
                                         Swal.fire('Error', errorMessage, 'error');
                                     } else {
                                         Swal.close();
                                         enableSubmitButton();
                                     }
                                    return false;
                                }, {
                                    amount: parseFloat(bmspay_checkout_params.total),
                                    currency: '840'
                                }
                            );
                        }
                    });
                }
                
                // Call the function
                initialize3DS();
            }
        }
    });
});
