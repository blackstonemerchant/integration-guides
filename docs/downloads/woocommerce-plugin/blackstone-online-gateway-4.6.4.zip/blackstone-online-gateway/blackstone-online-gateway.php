<?php
/*
Plugin Name: Blackstone Online Gateway
Plugin URI: http://www.blackstonemerchant.com/
Description: Blackstone Merchant custom payment gateway integration with Woocommerce.
Author: Blackstone
Author URI: https://blackstoneonline.com/
Version: 4.6.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: blackstone-online-gateway
Domain Path: /languages
*/

if ( !defined( 'ABSPATH' ) ) exit;

define('BMSPAY_REFUND_PLUGIN_PATH', plugin_dir_path(__FILE__));

include_once BMSPAY_REFUND_PLUGIN_PATH . 'includes/bmspay_api_refund_integration.php';

add_action('plugins_loaded', 'bmspay_blackstone_init', 0);

function bmspay_blackstone_init()
{
  if (! class_exists('WC_Payment_Gateway')) return;
  include_once('bmspay-blackstone-payment.php');

  add_filter('woocommerce_payment_gateways', 'bmspay_add_blackstone_gateway');
  function bmspay_add_blackstone_gateway($methods)
  {
    $methods[] = 'bmspay_Blackstone_Payment';
    return $methods;
  }
}

function bmspay_refund_plugin_init()
{
  new BMSPAY_API_Refund_Integration();
}

add_action('plugins_loaded', 'bmspay_refund_plugin_init');
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'bmspay_blackstone_action_links');

function bmspay_blackstone_action_links($links)
{
  $plugin_links = array(
    '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout') . '">' . __('Settings', 'blackstone-online-gateway') . '</a>',
  );
  return array_merge($plugin_links, $links);
}
/**
 * Enqueue scripts for refund form input mask
 */
function bmspay_enqueue_refund_scripts()
{
  if (!is_admin() && is_checkout()) {
    wp_enqueue_script(
      'inputmask',
      plugins_url('assets/js/jquery.inputmask.min.js', __FILE__),
      array('jquery'),
      '5.0.7',
      true
    );

    $inline_script = "jQuery(document).ready(function($){
            $(\"input[name='refund_card_number']\").inputmask('9999 9999 9999 9999');
        });";

    wp_add_inline_script('inputmask', $inline_script);
  }
}
add_action('wp_enqueue_scripts', 'bmspay_enqueue_refund_scripts');
