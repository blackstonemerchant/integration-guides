jQuery(function ($) {

    function handlePaymentMethodChange() {
        $(document.body).trigger('update_checkout');
    }

    handlePaymentMethodChange();
    $(document.body).on('payment_method_selected', handlePaymentMethodChange);

});
