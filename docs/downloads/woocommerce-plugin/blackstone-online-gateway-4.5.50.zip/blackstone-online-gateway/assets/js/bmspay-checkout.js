jQuery(document).ready(function($) {
    var canSubmitForm = false;

    // Determinar si es página de pago de pedido
    var isPayForOrder = window.location.href.indexOf('order-pay') !== -1;

    // Seleccionar el formulario correcto
    var $form = isPayForOrder ? $('#order_review') : $('form.checkout');

    function getSubmitButton() {
        if (isPayForOrder) {
            return $('#place_order');
        }

        var $btn = $('#place_order');
        if ($btn.length === 0) {
            $btn = $('button[name="woocommerce_checkout_place_order"]');
        }
        if ($btn.length === 0) {
            $btn = $('form.checkout').find('button[type="submit"]');
        }
        return $btn;
    }

    function enableSubmitButton() {
        var $submitBtn = getSubmitButton();
        if ($submitBtn.length) {
            $submitBtn.prop('disabled', false);
        }
        $('.woocommerce-ajax-loader').hide();
    }

    function disableSubmitButton() {
        var $submitBtn = getSubmitButton();
        if ($submitBtn.length) {
            $submitBtn.prop('disabled', true);
        }
        $('.woocommerce-ajax-loader').show();
    }

    function cleanup3DS() {
        $('iframe[id^="container-challenge-3ds"]').remove();
        $('#billing-form').remove();

        if (window.Swal && window.Swal.getPopup()) {
            window.Swal.close();
        }
        window.tds = undefined;
    }

    $form.on('submit', function(e) {
        if ($('input[name="payment_method"]:checked').val() === 'bmspay_blackstone_payment') {
                if (!canSubmitForm) {
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    disableSubmitButton();

                    var cardNumber = $('#bmspay_blackstone_payment-card-number').val().replace(/\s+/g, '');
                    var expiry = $('#bmspay_blackstone_payment-card-expiry').val().replace(/\s+/g, '');
                    var parts = expiry.split('/');
                    var month = parts[0];
                    var year = parts.length > 1 ? parts[1] : '';
                    
                    // Handle 4-digit year
                    if (year.length === 4) {
                        year = year.substring(2);
                    }
                    var cvv = $('#bmspay_blackstone_payment-card-cvc').val();
                    var billingPostCode = $('#billing_postcode').val();
                    var cardHolderName = $('#billing_first_name').val() + ' ' + $('#billing_last_name').val();

                    
                    
                    // Advanced Validation
                    var errorMsg = '';
                    var currentYear = new Date().getFullYear().toString().substr(-2);
                    var currentMonth = new Date().getMonth() + 1;

                    // 1. Basic Empty Check
                    if (!cardNumber || !expiry || !cvv) {
                        errorMsg = 'Por favor, ingrese todos los datos de la tarjeta (Número, Fecha de Expiración y CVC).';
                    } 
                    // 2. Card Length Check (Standard is 13-19 digits)
                    else if (cardNumber.length < 13 || cardNumber.length > 19 || !/^\d+$/.test(cardNumber)) {
                        errorMsg = 'El número de tarjeta no es válido. Debe tener entre 13 y 19 dígitos.';
                    }
                    // 3. Expiry Date Check
                    else if (!/^\d{2}\/(\d{2}|\d{4})$/.test(expiry)) {
                         errorMsg = 'El formato de fecha debe ser MM/AA o MM/AAAA.';
                    }
                    else if (parseInt(month) < 1 || parseInt(month) > 12) {
                         errorMsg = 'El mes de expiración no es válido.';
                    }
                    else {
                        // Check if expired
                        var expMonth = parseInt(month, 10);
                        var expYear = parseInt(year, 10);
                        var curMonth = parseInt(currentMonth, 10);
                        var curYear = parseInt(currentYear, 10);

                        if (expYear < curYear || (expYear === curYear && expMonth < curMonth)) {
                             errorMsg = 'La tarjeta ha expirado.';
                        }
                    }
                    
                    // 4. CVV Check (3 or 4 digits)
                    if (!errorMsg && (!/^\d{3,4}$/.test(cvv))) {
                         errorMsg = 'El código de seguridad (CVC) debe tener 3 o 4 dígitos.';
                    }

                    if (errorMsg) {
                        enableSubmitButton();
                        Swal.fire({
                            icon: 'warning',
                            title: 'Datos Inválidos',
                            text: errorMsg,
                            confirmButtonText: 'Corregir'
                        });
                        return false;
                    }


                    const $tempForm = $('<form id="billing-form" style="display:none;"></form>').appendTo('body');
                    $tempForm.append('<input type="text" id="billing-card-amount" name="billing-card-amount" value="' + bmspay_checkout_params.total + '" data-threeds="amount" />');
                    $tempForm.append('<input type="text" id="billing-card-pan" name="billing-card-pan" value="' + cardNumber + '" data-threeds="pan" />');
                    $tempForm.append('<input type="text" id="billing-card-month" name="billing-card-month" value="' + month + '" data-threeds="month"/>');
                    $tempForm.append('<input type="text" id="billing-card-year" name="billing-card-year" value="' + year + '" data-threeds="year"/>');
                    $tempForm.append('<input type="text" id="billing-card-cvv" name="billing-card-cvv" value="' + cvv + '" data-threeds="cvv"/>');
                    $tempForm.append('<input type="text" id="billing-card-billing-post-code" name="billing-card-billing-post-code" value="' + billingPostCode + '" data-threeds="billingPostCode"/>');
                    $tempForm.append('<input type="text" id="billing-card-holder-name" name="billing-card-holder-name" value="' + cardHolderName + '" data-threeds="cardHolderName"/>');

                    // Log Data 3DS (Masked)
                    var maskedCardNumber = cardNumber.slice(-4).padStart(cardNumber.length, '*');
                    var maskedCvv = cvv.replace(/./g, '*');

                    var logData = {
                        amount: bmspay_checkout_params.total,
                        pan: maskedCardNumber,
                        month: month,
                        year: year,
                        cvv: maskedCvv,
                        billingPostCode: billingPostCode,
                        cardHolderName: cardHolderName
                    };
                    
                    if (bmspay_checkout_params.ajax_url) {
                        console.log('AJAX URL:', bmspay_checkout_params.ajax_url);
                        $.post(bmspay_checkout_params.ajax_url, {
                            action: 'bmspay_3ds_log',
                            data: logData
                        }).done(function(response) {
                            console.info('3DS Log Success:', response);
                        }).fail(function(xhr, status, error) {
                            console.info('3DS Log Failed:', status, error, xhr.responseText);
                        });
                    } else {
                        console.info('AJAX URL not found in bmspay_checkout_params');
                    }


                function initialize3DS() {
                    const uniqueId = Date.now();
                    const iframeId = 'container-challenge-3ds-' + uniqueId;
                    const wrapperId = 'challenge-wrapper-' + uniqueId;
                    const loaderId = 'challenge-loader-' + uniqueId;

                    // Improved HTML structure matching original design
                    var html_3ds = `
                        <div class="threeds-modal-content">
                            <div style="width: 100%; height: 430px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9; position: relative; margin: 0 auto;">
                                <div id="${wrapperId}" class="threeds-loading" 
                                    style="width: 100%; height: 100%; position: relative;">
                                </div>
                                <div id="${loaderId}" class="threeds-loading" 
                                    style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
                                    <div class="spinner"></div>
                                    <p style="margin-top: 8px; color: #555;">Procesando verificación de seguridad...</p>
                                </div>
                            </div>
                            <p style="margin-top: 15px; font-size: 12px; color: #666; text-align: center;">
                                Por favor no cierre esta ventana.
                            </p>
                        </div>
                    `;

                     window.Swal.fire({
                        title: 'Verificación 3D Secure',
                        html: html_3ds,
                        showConfirmButton: false,
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        width: 500,
                        padding: '10px',
                        customClass: {
                            container: 'threeds-modal',
                            popup: 'threeds-popup',
                            header: 'threeds-header'
                        },
                        didOpen: () => {
                            const wrapper = document.getElementById(wrapperId);
                            
                            const iframe = document.createElement('iframe');
                            iframe.id = iframeId;
                            iframe.style.cssText = `
                                width: 420px !important;
                                height: 420px !important;
                                min-width: 420px !important;
                                min-height: 420px !important;
                                max-width: 420px !important;
                                max-height: 420px !important;
                                border: none !important;
                                opacity: 0 !important;
                                display: block !important;
                                position: relative !important;
                                transition: opacity 0.3s ease !important;
                            `;
                            
                            if (wrapper) {
                                wrapper.appendChild(iframe);
                            }

                             var apiKey = bmspay_checkout_params.apiKey;
                             var token = bmspay_checkout_params.token;

                             // Initialize ThreeDS with the iframe ID
                             window.tds = new ThreeDS(
                                "billing-form",
                                apiKey,
                                token,
                                {
                                    endpoint: bmspay_checkout_params.endpoint,
                                    autoSubmit: false,
                                    showChallenge: true,
                                    popup: false,
                                    iframeId: iframeId, 
                                    forcedTimeOut: '10'
                                }
                            );
                            
                            // Handling iframe load event manually if needed, or relying on ThreeDS lib. 
                            // The original code appended the iframe and set `window.currentIframe`.
                            // Let's add the simple onload fade-in.
                            iframe.onload = () => {
                                const loader = document.getElementById(loaderId);
                                if (loader) loader.style.display = 'none';
                                iframe.style.opacity = '1';
                                iframe.style.width = '420px';
                                iframe.style.height = '430px';
                                iframe.style.minWidth = '420px';
                                iframe.style.minHeight = '430px';
                                iframe.style.maxWidth = '420px';
                                iframe.style.maxHeight = '430px';
                                iframe.style.display = 'block';
                                iframe.style.borderRadius = '8px';
                                iframe.style.overflow = 'hidden';
                            };

                            window.tds.verify(
                                function(response) {
                                    // Success Handler
                                    var $tempForm = $('#billing-form');

                                    if (!response || (response.status !== 'Y' && response.status !== 'A')) {
                                        var errorMessage = '3D Secure Verification Failed';
                                        if (response && response.transStatusReasonDetail) {
                                            errorMessage += ': ' + response.transStatusReasonDetail;
                                        }
                                        $tempForm.remove();
                                        Swal.close(); 
                                        
                                        if (typeof Swal !== 'undefined') {
                                            Swal.fire('Error', errorMessage, 'error');
                                        } else {
                                            alert(errorMessage);
                                        }
                                        enableSubmitButton();
                                        return false;
                                    }

                                    const threeDsTransactionId = window.tds.threeDsTransactionId;

                                    if (threeDsTransactionId) {
                                        response.threeDsTransactionId = threeDsTransactionId;
                                    }

                                    $tempForm.remove();
                                    canSubmitForm = true;
                                    Swal.close();

                                    var $targetForm = isPayForOrder ? $('#order_review') : $('form.checkout');

                                    if (!$targetForm.find('input[name=threeds_response]').length) {
                                        $('<input>').attr({
                                            type: 'hidden',
                                            name: 'threeds_response',
                                            value: JSON.stringify(response)
                                        }).appendTo($targetForm);
                                    } else {
                                        $targetForm.find('input[name=threeds_response]').val(JSON.stringify(response));
                                    }

                                    cleanup3DS();
                                    $targetForm.submit();
                                    enableSubmitButton();
                                },
                                function(error) {
                                    // Error Handler
                                    let errorObj = error;
                                    if (typeof error === 'string') {
                                        try {
                                            errorObj = JSON.parse(error);
                                        } catch (e) {
                                            console.warn('El error no es un JSON válido', error);
                                        }
                                    }
                                    let errorMessage = errorObj.error || errorObj.message || 'An error occurred during payment verification. Please try again.';
                                    
                                     if (errorMessage !== 'No result found for transaction as yet. Please subscribe again') {
                                         Swal.close(); 
                                         Swal.fire('Error', errorMessage, 'error');
                                     } else {
                                         Swal.close();
                                         enableSubmitButton();
                                     }
                                    return false;
                                }, {
                                    amount: parseFloat(bmspay_checkout_params.total),
                                    currency: '840'
                                }
                            );
                        },
                        willClose: () => {
                            if (window.currentIframe && window.currentIframe.parentNode) {
                                window.currentIframe.parentNode.removeChild(window.currentIframe);
                                window.currentIframe = null;
                            }
                        }
                    });
                }
                
                // Call the function
                initialize3DS();
            }
        }
    });
});
