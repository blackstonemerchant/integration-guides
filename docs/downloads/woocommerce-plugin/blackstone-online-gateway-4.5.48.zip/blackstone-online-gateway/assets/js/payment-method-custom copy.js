jQuery(function ($) {

    var initialLoadDone = false;

    function handlePaymentMethodChange() {
        var paymentMethod = $('input[name="payment_method"]:checked').val();
        var reviewSection = $('.woocommerce-checkout-review-order-table')
            .closest('.woocommerce-checkout-review-order');

        if ($.blockUI && reviewSection.block) {
            reviewSection.block({
                message: null,
                overlayCSS: {
                    background: '#fff',
                    opacity: 0.6
                }
            });
        }

        $.ajax({
            type: 'POST',
            url: wc_checkout_params.ajax_url,
            data: {
                action: 'update_fees_based_on_payment_method',
                payment_method: paymentMethod,
                security: wc_checkout_params.update_order_review_nonce
            },
            success: function (response) {
                if (response.success) {
                    if (response.fragments) {
                        $.each(response.fragments, function (key, value) {
                            $(key).replaceWith(value);
                        });
                    }

                    $(document.body).trigger('update_checkout');
                }
            },
            complete: function () {
                if (reviewSection.unblock) {
                    reviewSection.unblock();
                }
            },
            error: function () {
                reviewSection.prepend('<div class="woocommerce-error">Error al actualizar los cargos. Por favor recarga la página.</div>');
            }
        });
    }

    // Ejecutar una vez después de que WooCommerce checkout esté inicializado
    $(document.body).on('updated_checkout', function () {
        if (!initialLoadDone) {
            initialLoadDone = true;
            handlePaymentMethodChange();
        }
    });

    // Ejecutar cuando el usuario cambie de método de pago
    $(document.body).on('payment_method_selected', handlePaymentMethodChange);

});
