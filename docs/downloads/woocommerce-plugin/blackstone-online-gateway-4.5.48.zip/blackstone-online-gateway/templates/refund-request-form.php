<?php
if (!defined('ABSPATH')) {
    exit;
}

$order = wc_get_order($order_id);

if ($order) : ?>
    <h2><?php esc_html_e('Refund Request', 'blackstone-online-gateway'); ?></h2>
    <form method="post">
        <p>
            <label for="refund_card_number"><?php esc_html_e('Enter Credit Card Number:', 'blackstone-online-gateway'); ?></label>
            <input type="text" name="refund_card_number" required />
        </p>
        <p>
            <input type="submit" name="submit_refund_request" value="<?php esc_html_e('Request Refund', 'blackstone-online-gateway'); ?>" />
        </p>
    </form>
<?php else : ?>
    <p><?php esc_html_e('Invalid order ID.', 'blackstone-online-gateway'); ?></p>
<?php endif; ?>
