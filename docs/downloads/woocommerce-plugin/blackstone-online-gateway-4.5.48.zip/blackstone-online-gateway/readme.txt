=== Blackstone Online Gateway ===
Contributors: carlosraul7
Donate link: https://blackstoneonline.com/
Tags: woocommerce, payment, gateway, blackstone, credit card
Requires at least: 5.8
Tested up to: 6.8
Stable tag: 4.5.48
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Custom payment gateway integration for WooCommerce using Blackstone Merchant. Secure, fast and reliable payments for your online store.

== Description ==

**Blackstone Online Gateway** is a custom payment integration for WooCommerce that allows merchants to process payments through the Blackstone Merchant platform.  
It provides a seamless Payments experience, secure communication with the API, and supports refund handling directly via WooCommerce.

### Main Features

* Full integration with WooCommerce.
* Secure API connection to Blackstone Merchant.
* Supports payment authorization, capture and refund.
* Refund processing via API with stock management.
* Admin settings page for easy configuration.
* Compatible with the latest versions of WooCommerce and WordPress.

This plugin requires an active merchant account with [Blackstone Merchant](https://www.blackstonemerchant.com/).

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install it directly from the WordPress Plugin Directory.
2. Activate the plugin through the *Plugins* menu in WordPress.
3. Go to **WooCommerce → Settings → Payments → Blackstone Merchant**.
4. Enable the gateway and enter your merchant credentials (API keys, merchant ID, etc.).
5. Save changes and test the Payments process.

== Frequently Asked Questions ==

= Do I need a Blackstone Merchant account? =  
Yes. You must have an approved merchant account from [Blackstone Merchant](https://www.blackstonemerchant.com/) to process transactions.

= Does this plugin support refunds? =  
Yes. Refunds can be processed directly from the WooCommerce order screen. The plugin sends refund requests securely to the Blackstone API.

= Is it compatible with WooCommerce Subscriptions or Bookings? =  
Currently, it supports standard one-time payments. Future versions may include support for recurring billing.

= Does it store credit card information? =  
No. The plugin does **not** store or log any sensitive card data. All transactions are handled securely through the Blackstone Merchant gateway.

== Screenshots ==

1. Payment gateway settings 1 — Configuration screen under WooCommerce → Settings → Payments → Blackstone Merchant.
2. Payment gateway settings 1 — Configuration screen under WooCommerce → Settings → Payments → Blackstone Merchant.
3. Checkout page — The Blackstone Merchant option displayed at Payments for customers.

== Changelog ==

= 4.5.43 =
* Added compatibility with WooCommerce 9.x.
* Improved refund API handling and error responses.
* Minor performance and security updates.
* Improved text translation.
* Added data to refund notes for better traceability.
* Standardized file and folder names.

= 4.5.0 =
* Initial public release.
* Added support for payment authorization and capture.
* Introduced refund integration via API.

== Upgrade Notice ==

= 4.5.48 =
* Fixed: JavaScript conflict on checkout page (undefined 'defaults' error) by restricting script loading.
* Improved: Script loading logic to prevent conflicts with other plugins.

== License ==

This plugin is licensed under the GPLv2 or later license.  
You are free to modify and redistribute it under the same license.  
See https://www.gnu.org/licenses/gpl-2.0.html for details.

== Credits ==

Developed and maintained by **Blackstone**  
Website: [https://blackstoneonline.com/](https://blackstoneonline.com/)  
Blackstone Merchant official site: [https://www.blackstonemerchant.com/](https://www.blackstonemerchant.com/)
