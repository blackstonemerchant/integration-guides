<?php
if (!defined('ABSPATH')) {
    exit;
}

class WC_API_Refund_Integration
{
    public function __construct()
    {
        add_action('admin_print_footer_scripts', [$this, 'add_api_refund_button']);
        add_action('wp_ajax_process_api_refund', [$this, 'process_api_refund']);
        add_action('woocommerce_order_refunded', [$this, 'clear_cache_on_refund'], 10, 2);
    }
    public function clear_cache_on_refund($order_id, $refund_id)
    {
        clean_post_cache($order_id);
        wp_cache_delete($order_id, 'posts');
        wp_cache_delete($order_id, 'post_meta');
        wc_delete_shop_order_transients($order_id);
    }

    public function add_api_refund_button()
    {
        $order_id = null;

        if (isset($_GET['post']) && get_post_type($_GET['post']) === 'shop_order') {
            $order_id = absint($_GET['post']);
        }

        if (isset($_GET['page'], $_GET['id']) && $_GET['page'] === 'wc-orders') {
            $order_id = absint($_GET['id']);
        }

        if (!$order_id) {
            return;
        }

        $order = wc_get_order($order_id);

        if (!$order || !is_a($order, 'WC_Order')) {
            return;
        }

        if (!$this->should_show_api_refund_button($order)) {
            return;
        }

        $order_id = $order->get_id();
        $buttonText = (get_locale() === 'es_ES') ? 'Reembolsar con Blackstone' : 'Blackstone Refund';

        wp_enqueue_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11', [], '11.0.0', true);
?>
        <script type="text/javascript">
            (function($) {
                const waitForRefundSection = setInterval(() => {
                    const $refundSection = $('.refund-actions');
                    const $confirmBtn = $('.do-manual-refund');

                    if ($refundSection.length && $confirmBtn.length && !$('.wc-api-confirm-btn').length) {
                        clearInterval(waitForRefundSection);

                        const $apiBtn = $('<button type="button" class="button button-primary wc-api-confirm-btn"><?php echo $buttonText; ?></button>');
                        $apiBtn.css({
                            'margin-left': '10px'
                        });
                        $confirmBtn.after($apiBtn);

                        $apiBtn.on('click', function() {
                            const refundAmount = parseFloat($('#refund_amount').val()) || 0;
                            const reason = $('#refund_reason').val() || '';
                            const order_id = <?php echo (int) $order_id; ?>;

                            const lineItems = {};

                            $('tr.item', '.woocommerce_order_items').each(function() {
                                const itemId = $(this).data('order_item_id');
                                const qtyInput = $(this).find('input.refund_order_item_qty');
                                const totalInput = $(this).find('input.refund_line_total');
                                const productName = $(this).find('.wc-order-item-name').text().trim();

                                if (qtyInput.length) {
                                    const qty = parseFloat(qtyInput.val()) || 0;
                                    if (qty > 0) {
                                        lineItems[itemId] = {
                                            id: itemId,
                                            name: productName,
                                            qty: qty,
                                            total: parseFloat(totalInput.val()) || 0
                                        };
                                    }
                                }
                            });

                            if (refundAmount <= 0) {
                                Swal.fire('Error', 'El monto del reembolso debe ser mayor a 0.', 'error');
                                return;
                            }

                            Swal.fire({
                                title: '¿Está seguro?',
                                text: '¿Desea procesar este reembolso por $' + refundAmount.toFixed(2) + '?',
                                icon: 'warning',
                                showCancelButton: true,
                                cancelButtonText: 'Cancelar',
                                confirmButtonText: 'Sí, reembolsar',
                                showLoaderOnConfirm: true,
                                preConfirm: () => {
                                    return new Promise((resolve, reject) => {
                                        $.post(ajaxurl, {
                                            action: 'process_api_refund',
                                            security: '<?php echo wp_create_nonce("api-refund-nonce"); ?>',
                                            order_id: order_id,
                                            refund_amount: refundAmount,
                                            refund_reason: reason,
                                            restock_items: $('#restock_refunded_items').is(':checked') ? 1 : 0,
                                            line_items: JSON.stringify(lineItems)
                                        }, function(response) {
                                            if (response.success) {
                                                resolve(response.data.message);
                                            } else {
                                                reject(response.data.message || 'Ocurrió un error al procesar el reembolso.');
                                            }
                                        });
                                    });
                                },
                                allowOutsideClick: () => !Swal.isLoading()
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    Swal.fire('¡Completado!', result.value, 'success').then(() => {
                                        location.reload();
                                    });
                                }
                            }).catch((error) => {
                                Swal.fire('Error', error, 'error');
                            });
                        });
                    }
                }, 300);
            })(jQuery);
        </script>
<?php
    }

    private function should_show_api_refund_button($order)
    {
        if (!$order || !is_a($order, 'WC_Order')) {
            return false;
        }

        if ($order->get_payment_method() !== 'bmspay_blackstone_payment') {
            return false;
        }

        if ($this->is_refund_order($order)) {
            return false;
        }

        if ($this->get_remaining_balance($order) <= 0) {
            return false;
        }

        return true;
    }
    public function process_api_refund()
    {
        check_ajax_referer('api-refund-nonce', 'security');

        $order_id = absint($_POST['order_id']);
        $order = wc_get_order($order_id);

        if (!$order || !is_a($order, 'WC_Order')) {
            wp_send_json_error(['message' => 'Pedido no encontrado']);
        }

        $data = $this->parse_refund_items($_POST, $order);

        $api_result = $this->process_in_blackstone_api($order, $data);

        if ($api_result['success']) {
            wp_send_json_success(['message' => $api_result['message']]);
        } else {
            wp_send_json_error(['message' => $api_result['message']]);
        }
    }

    private function process_in_blackstone_api($order, $data)
    {
        try {
            $api_response = $this->process_refund_request($order, $data['amount'], $data['restock'] ?? false, $data['items']);

            if (!$api_response['success']) {
                return ['success' => false, 'message' => $api_response['message']];
            } else {
                return ['success' => true, 'message' => $api_response['message']];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    protected function parse_refund_items($post_data, $order)
    {
        $refund_data = [
            'amount' => wc_format_decimal($post_data['refund_amount']),
            'reason' => sanitize_text_field($post_data['refund_reason']),
            'restock_items' => isset($post_data['restock_items']) && $post_data['restock_items'] == 1,
            'items' => []
        ];

        if (!empty($post_data['line_items'])) {
            $line_items = json_decode(stripslashes($post_data['line_items']), true);

            foreach ($line_items as $item) {
                $refund_data['items'][$item['id']] = [
                    'qty' => absint($item['qty']),
                    'refund_total' => wc_format_decimal($item['total'] ?? 0),
                    'refund_tax' => !empty($item['tax']) ? array_map('wc_format_decimal', (array)$item['tax']) : []
                ];
            }
        }
        if (empty($refund_data['items'])) {
            foreach ($order->get_items() as $item_id => $item) {
                $qty_purchased = $item->get_quantity();
                $qty_already_refunded = $order->get_qty_refunded_for_item($item_id);
                $qty_to_refund = $qty_purchased - $qty_already_refunded;
                if ($qty_to_refund > 0) {
                    $refund_total = wc_format_decimal(
                        $item->get_total() - $order->get_total_refunded_for_item($item_id)
                    );
                    $refund_tax = array_map(
                        'wc_format_decimal',
                        $item->get_taxes()['total'] ?? []
                    );
                    $refund_data['items'][$item_id] = [
                        'qty'          => $qty_to_refund,
                        'refund_total' => $refund_total,
                        'refund_tax'   => $refund_tax,
                    ];
                }
            }
        }
        return $refund_data;
    }

    private function is_refund_order($order)
    {
        if (is_numeric($order)) {
            $order = wc_get_order($order);
        }
        if (!$order || !is_a($order, 'WC_Order')) {
            return false;
        }

        return $this->get_remaining_balance($order) == 0;
    }

    public function get_remaining_balance($order)
    {
        if (is_numeric($order)) {
            $order = wc_get_order($order);
        }
        if (!$order || !is_a($order, 'WC_Order')) {
            return 0;
        }

        return $order->get_total() - $order->get_total_refunded();
    }

    public function process_refund_request($order, $refund_amount = null, $restock = false, $items = [])
    {
        if (empty($items)) {
            return [
                "success" => false,
                'message' => 'El pedido no tiene artículos que puedan ser reembolsados.'
            ];
        }
        if (is_numeric($order)) {
            $order = wc_get_order($order);
        }

        if (!$order || !is_a($order, 'WC_Order')) {
            return ["success" => false, 'message' => 'Invalid order object'];
        }

        if ($this->is_refund_order($order)) {
            return ["success" => false, 'message' => 'Order already refunded'];
        }

        $payment_gateways = WC_Payment_Gateways::instance()->payment_gateways();
        $blackstone_gateway = $payment_gateways['bmspay_blackstone_payment'];
        $service_reference_number = $order->get_meta('_bmspay_service_reference_number');

        $environment_url = 'https://services.bmspay.com/api/Transactions/DoRefund';

        $data = [
            'Amount' => $refund_amount ?? $order->get_total(),
            'TrackData' => '',
            'UserTransactionNumber' => md5(uniqid($service_reference_number . $environment_url, true)),
            'ServiceTransactionNumber' => $service_reference_number,
            'SURI' => '',
            'AppKey' => $blackstone_gateway->environment == 'yes' ? "12345" : $blackstone_gateway->app_key,
            'AppType' => $blackstone_gateway->environment == 'yes' ? "1" : $blackstone_gateway->app_type,
            'mid' => $blackstone_gateway->environment == 'yes' ? "76074" : $blackstone_gateway->api_mid,
            'cid' => $blackstone_gateway->environment == 'yes' ? "260" : $blackstone_gateway->api_cid,
            'UserName' => $blackstone_gateway->environment == 'yes' ? "nicolas" : $blackstone_gateway->api_username,
            'Password' => $blackstone_gateway->environment == 'yes' ? "password1" : $blackstone_gateway->api_password,
            'IpAddress' => $_SERVER['REMOTE_ADDR'],
            'IsTest' => $blackstone_gateway->environment == 'yes' ? "True" : "False",
        ];

        $response = wp_remote_post($environment_url, [
            'method' => 'POST',
            'headers' => ['Content-Type' => 'application/json'],
            'body' => json_encode($data),
        ]);

        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        if (isset($response_data['ResponseCode']) && $response_data['ResponseCode'] == "200") {

            if (is_numeric($order)) {
                $order = wc_get_order($order);
            }

            if (!$order || !is_a($order, 'WC_Order')) {
                return [
                    "success" => false,
                    'message' => 'No se pudo cargar el pedido para el reembolso.'
                ];
            }

            if (empty($items)) {
                return [
                    "success" => false,
                    'message' => 'El pedido no tiene artículos que puedan ser reembolsados.'
                ];
            }

            $refund = wc_create_refund([
                'amount' => $refund_amount ?? $order->get_total(),
                'reason' => (get_locale() === 'es_ES') ? 'Reembolso procesado vía API.' : 'Refund processed via API.',
                'order_id' => $order->get_id(),
                'refund_payment' => false,
                'restock_items' => $restock,
                'line_items'     => $items,
            ]);

            if (is_wp_error($refund)) {
                return ["success" => false, 'message' => 'Error al crear el reembolso: ' . $refund->get_error_message()];
            }

            if (!$refund || !is_a($refund, 'WC_Order_Refund')) {
                return ["success" => false, 'message' => 'No se pudo crear un objeto de reembolso válido.'];
            }

            if ($restock) {
                $note = (get_locale() === 'es_ES')
                    ? 'Artículos reembolsados repuestos automáticamente en inventario.'
                    : 'Refunded items were restocked automatically.';
                $order->add_order_note($note);
            }

            if ($refund_amount < $order->get_total()) {
                $label = (get_locale() === 'es_ES') ? 'Reembolso parcial de %s vía API' : 'Partial refund of %s via API';
                $order->add_order_note(sprintf(__($label, 'your-textdomain'), wc_price($refund_amount)));
            } else {
                $label = (get_locale() === 'es_ES') ? 'Reembolso total de %s vía API' : 'Total refund of %s via API';
                $order->add_order_note(sprintf(__($label, 'your-textdomain'), wc_price($refund_amount)));
                $order->update_status('refunded');
            }

            if (isset($refund) && is_a($refund, 'WC_Order_Refund') && isset($order) && is_a($order, 'WC_Order')) {

                if (
                    is_object($refund) && $refund instanceof WC_Order_Refund &&
                    is_object($order) && $order instanceof WC_Order
                ) {
                    // set IDs
                    $order_id = $order->get_id();
                    $refund_id = $refund->get_id();

                    // Limpieza de caché y transients
                    delete_transient('wc_order_data_' . $order_id);
                    wc_delete_shop_order_transients($order_id);

                    // Limpia caché de post y post_meta por si Object Cache Pro los mantiene en memoria
                    clean_post_cache($order_id);
                    wp_cache_delete($order_id, 'posts');
                    wp_cache_delete($order_id, 'post_meta');

                    // También puedes eliminar caché del refund si es necesario
                    clean_post_cache($refund_id);
                    wp_cache_delete($refund_id, 'posts');
                    wp_cache_delete($refund_id, 'post_meta');

                    $order->save();
                }
            }
            $order->save();

            $msg = (get_locale() === 'es_ES') ? 'Reembolso completado correctamente' : 'Refund completed successfully';
            return [
                "success" => true,
                'message' => __("$msg, Ref: $service_reference_number", 'your-textdomain')
            ];
        } else {
            return [
                "success" => false,
                'message' => __($this->get_message_error($response_data) . ", Ref: $service_reference_number", 'your-textdomain')
            ];
        }
    }

    public function get_message_error($response_data)
    {
        $msg = __('No message provided', 'bmspay-blackstone-payment');

        if (isset($response_data['Msg']) && is_array($response_data['Msg'])) {
            $msg = implode(', ', $response_data['Msg']);
        }
        return $msg;
    }
}
add_action('admin_init', 'fix_wc_order_object_error');
function fix_wc_order_object_error()
{
    if (is_admin() && isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
        $order_id = absint($_GET['id']);
        $order = wc_get_order($order_id);

        if (is_numeric($order) || !is_a($order, 'WC_Order')) {
            clean_post_cache($order_id);
            wp_cache_delete($order_id, 'posts');
            wp_cache_delete($order_id, 'post_meta');
            $order = wc_get_order($order_id);
        }
    }
}
add_action('woocommerce_order_refunded', 'clear_cache_refund', 10, 2);

function clear_cache_refund($order_id, $refund_id)
{
    $order = wc_get_order($order_id);
    $refund = wc_get_order($refund_id);

    if (
        is_a($order, 'WC_Order') &&
        is_a($refund, 'WC_Order_Refund')
    ) {
        error_log('Iniciando limpieza de caché...');
        error_log('Order ID: ' . $order_id);
        error_log('Refund ID: ' . $refund_id);
        // Limpieza de transients y caché
        delete_transient('wc_order_data_' . $order_id);
        wc_delete_shop_order_transients($order_id);

        clean_post_cache($order_id);
        wp_cache_delete($order_id, 'posts');
        wp_cache_delete($order_id, 'post_meta');

        clean_post_cache($refund_id);
        wp_cache_delete($refund_id, 'posts');
        wp_cache_delete($refund_id, 'post_meta');

        $order->save();

        error_log("Cache limpiada para la orden $order_id y reembolso $refund_id");
    }
}


new WC_API_Refund_Integration();
