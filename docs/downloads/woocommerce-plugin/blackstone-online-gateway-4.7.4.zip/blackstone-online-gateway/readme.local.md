# Local WordPress Environment

This repository includes a local Docker-based WordPress and WooCommerce stack for manual plugin testing.

## Requirements

- Docker Desktop or Docker Engine with Compose v2
- GNU `make`

## First-time setup

1. Copy the environment file:

```sh
cp .env.example .env
```

2. Bootstrap the local stack and seed the demo store:

```sh
make setup
```

## Local URLs

- Storefront: `http://bpayd.localhost:8080`
- WordPress admin: `http://bpayd.localhost:8080/wp-admin`
- phpMyAdmin: `http://localhost:8081`

Default admin credentials come from `.env`:

- User: `admin`
- Password: `admin`

Default demo customer credentials:

- User: `customer`
- Password: `customer`

The stack uses `bpayd.localhost` instead of plain `localhost` to avoid cookie collisions with other local apps. Modern browsers resolve `*.localhost` locally without editing `/etc/hosts`.

## Useful commands

```sh
make up
make down
make setup
make seed
make reset
make open
make logs
make ps
make status
make restart
make shell
make db-shell
make wp plugin list
```

You can run arbitrary WP-CLI commands through the `wp` target. Example:

```sh
make wp option get home
```

## Notes

- The plugin is mounted directly from the current repository into `wp-content/plugins/blackstone-online-gateway`.
- You do not need to build or upload a ZIP to test local changes.
- `make setup` installs WordPress, WooCommerce, the Blackstone plugin, a flat-rate shipping zone, two product categories, four simple demo products, and a demo customer account.
- Guest checkout stays enabled, and the Blackstone gateway is preconfigured in test mode.
- 3D Secure test mode is intentionally left disabled by default for local stability. You can enable it later from WooCommerce payment settings if you want to validate that flow.
- `make reset` removes the local database and WordPress volumes, so the next `make setup` starts from a clean environment.
