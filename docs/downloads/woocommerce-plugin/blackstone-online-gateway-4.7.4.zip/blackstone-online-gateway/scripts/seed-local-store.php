<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit( 1 );
}

if ( ! class_exists( 'WooCommerce' ) ) {
	fwrite( STDERR, "WooCommerce must be active before seeding the local store.\n" );
	exit( 1 );
}

$demo_customer_user     = $args[0] ?? 'customer';
$demo_customer_password = $args[1] ?? 'customer';
$demo_customer_email    = $args[2] ?? 'customer@example.com';

if ( class_exists( 'WC_Install' ) ) {
	WC_Install::create_pages();
}

function bmspay_local_ensure_wc_page_content( string $page_option, string $expected_content ): void {
	$page_id = (int) get_option( $page_option );

	if ( ! $page_id ) {
		return;
	}

	$page = get_post( $page_id );

	if ( ! $page instanceof WP_Post ) {
		return;
	}

	if ( trim( (string) $page->post_content ) === trim( $expected_content ) ) {
		return;
	}

	wp_update_post(
		array(
			'ID'           => $page_id,
			'post_content' => $expected_content,
		)
	);
}

function bmspay_local_ensure_page( string $slug, string $title, string $content, string $status = 'publish' ): int {
	$page = get_page_by_path( $slug, OBJECT, 'page' );

	if ( ! $page ) {
		$page_id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_title'   => $title,
				'post_name'    => $slug,
				'post_status'  => $status,
				'post_content' => $content,
			)
		);

		if ( is_wp_error( $page_id ) ) {
			throw new RuntimeException( $page_id->get_error_message() );
		}

		return (int) $page_id;
	}

	wp_update_post(
		array(
			'ID'           => $page->ID,
			'post_title'   => $title,
			'post_status'  => $status,
			'post_content' => $content,
		)
	);

	return (int) $page->ID;
}

function bmspay_local_trash_page_by_slug( string $slug ): void {
	$page = get_page_by_path( $slug, OBJECT, 'page' );

	if ( ! $page || 'trash' === $page->post_status ) {
		return;
	}

	wp_trash_post( $page->ID );
}

update_option( 'woocommerce_currency', 'USD' );
update_option( 'woocommerce_default_country', 'US:FL' );
update_option( 'woocommerce_allowed_countries', 'all' );
update_option( 'woocommerce_ship_to_countries', 'all' );
update_option( 'woocommerce_default_customer_address', 'base' );
update_option( 'woocommerce_calc_taxes', 'no' );
update_option( 'woocommerce_enable_guest_checkout', 'yes' );
update_option( 'woocommerce_enable_signup_and_login_from_checkout', 'yes' );
update_option( 'woocommerce_enable_myaccount_registration', 'yes' );
update_option( 'woocommerce_enable_myaccount_registration_generated_password', 'no' );
update_option( 'woocommerce_store_address', '123 Demo Street' );
update_option( 'woocommerce_store_city', 'Miami' );
update_option( 'woocommerce_default_city', 'Miami' );
update_option( 'woocommerce_store_postcode', '33101' );

bmspay_local_ensure_wc_page_content( 'woocommerce_cart_page_id', '[woocommerce_cart]' );
bmspay_local_ensure_wc_page_content( 'woocommerce_checkout_page_id', '[woocommerce_checkout]' );
bmspay_local_ensure_wc_page_content( 'woocommerce_myaccount_page_id', '[woocommerce_my_account]' );

function bmspay_local_ensure_term( string $taxonomy, string $slug, string $name ): int {
	$term = get_term_by( 'slug', $slug, $taxonomy );

	if ( ! $term || is_wp_error( $term ) ) {
		$result = wp_insert_term(
			$name,
			$taxonomy,
			array(
				'slug' => $slug,
			)
		);

		if ( is_wp_error( $result ) ) {
			throw new RuntimeException( $result->get_error_message() );
		}

		return (int) $result['term_id'];
	}

	wp_update_term(
		$term->term_id,
		$taxonomy,
		array(
			'name' => $name,
			'slug' => $slug,
		)
	);

	return (int) $term->term_id;
}

function bmspay_local_ensure_simple_product( array $product_data ): int {
	$product_id = wc_get_product_id_by_sku( $product_data['sku'] );

	if ( ! $product_id ) {
		$existing_post = get_page_by_path( $product_data['slug'], OBJECT, 'product' );
		if ( $existing_post ) {
			$product_id = (int) $existing_post->ID;
		}
	}

	$product = $product_id ? wc_get_product( $product_id ) : new WC_Product_Simple();

	if ( ! $product instanceof WC_Product ) {
		$product = new WC_Product_Simple();
	}

	$product->set_name( $product_data['name'] );
	$product->set_slug( $product_data['slug'] );
	$product->set_status( 'publish' );
	$product->set_catalog_visibility( 'visible' );
	$product->set_description( $product_data['description'] );
	$product->set_short_description( $product_data['short_description'] );
	$product->set_regular_price( $product_data['price'] );
	$product->set_manage_stock( true );
	$product->set_stock_quantity( $product_data['stock_quantity'] );
	$product->set_stock_status( $product_data['stock_quantity'] > 0 ? 'instock' : 'outofstock' );
	$product->set_backorders( 'no' );
	$product->set_virtual( true );
	$product->set_downloadable( false );
	$product->set_sku( $product_data['sku'] );
	$product->set_category_ids( $product_data['category_ids'] );
	$product->save();

	return $product->get_id();
}

function bmspay_local_delete_shipping_zones(): void {
	$zones = WC_Shipping_Zones::get_zones();

	foreach ( $zones as $zone ) {
		if ( empty( $zone['id'] ) ) {
			continue;
		}

		$shipping_zone = new WC_Shipping_Zone( (int) $zone['id'] );
		$shipping_zone->delete();
	}

	update_option( 'woocommerce_ship_to_destination', 'billing_only' );
	update_option( 'woocommerce_enable_shipping_calc', 'no' );
	update_option( 'woocommerce_shipping_debug_mode', 'no' );

	if ( class_exists( 'WC_Cache_Helper' ) ) {
		WC_Cache_Helper::get_transient_version( 'shipping', true );
	}
}

function bmspay_local_ensure_customer( string $username, string $password, string $email ): void {
	$user = get_user_by( 'login', $username );
	$is_new_user = false;

	if ( ! $user ) {
		$user = get_user_by( 'email', $email );
	}

	if ( ! $user ) {
		$user_id = wp_create_user( $username, $password, $email );
		if ( is_wp_error( $user_id ) ) {
			throw new RuntimeException( $user_id->get_error_message() );
		}

		$user = get_user_by( 'id', $user_id );
		$is_new_user = true;
	}

	$user_update = array(
		'ID'           => $user->ID,
		'user_email'   => $email,
		'display_name' => 'Demo Customer',
		'first_name'   => 'Demo',
		'last_name'    => 'Customer',
		'role'         => 'customer',
	);

	if ( $is_new_user ) {
		$user_update['user_pass'] = $password;
	}

	wp_update_user( $user_update );

	$customer_meta = array(
		'billing_first_name'  => 'Demo',
		'billing_last_name'   => 'Customer',
		'billing_address_1'   => '500 Example Ave',
		'billing_city'        => 'Miami',
		'billing_state'       => 'FL',
		'billing_postcode'    => '33101',
		'billing_country'     => 'US',
		'billing_phone'       => '3055550101',
		'billing_email'       => $email,
		'shipping_first_name' => 'Demo',
		'shipping_last_name'  => 'Customer',
		'shipping_address_1'  => '500 Example Ave',
		'shipping_city'       => 'Miami',
		'shipping_state'      => 'FL',
		'shipping_postcode'   => '33101',
		'shipping_country'    => 'US',
	);

	foreach ( $customer_meta as $meta_key => $meta_value ) {
		update_user_meta( $user->ID, $meta_key, $meta_value );
	}
}

function bmspay_local_ensure_footer_template_part(): void {
	$theme_slug = get_stylesheet();

	bmspay_local_ensure_term( 'wp_theme', $theme_slug, $theme_slug );
	bmspay_local_ensure_term( 'wp_template_part_area', 'footer', 'Footer' );

	$template_part = get_page_by_path( 'footer', OBJECT, 'wp_template_part' );
	$content       = '<!-- wp:group {"style":{"spacing":{"padding":{"top":"24px","bottom":"24px"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group" style="padding-top:24px;padding-bottom:24px"><!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Blackstone Local</p><!-- /wp:paragraph --></div><!-- /wp:group -->';

	if ( ! $template_part ) {
		$template_part_id = wp_insert_post(
			array(
				'post_type'    => 'wp_template_part',
				'post_title'   => 'Footer',
				'post_name'    => 'footer',
				'post_status'  => 'publish',
				'post_content' => $content,
			)
		);

		if ( is_wp_error( $template_part_id ) ) {
			throw new RuntimeException( $template_part_id->get_error_message() );
		}

		$template_part = get_post( $template_part_id );
	} else {
		wp_update_post(
			array(
				'ID'           => $template_part->ID,
				'post_title'   => 'Footer',
				'post_status'  => 'publish',
				'post_content' => $content,
			)
		);
	}

	wp_set_object_terms( $template_part->ID, array( $theme_slug ), 'wp_theme', false );
	wp_set_object_terms( $template_part->ID, array( 'footer' ), 'wp_template_part_area', false );
}

function bmspay_local_ensure_header_template_part(): void {
	$theme_slug = get_stylesheet();
	$cart_url     = get_permalink( (int) get_option( 'woocommerce_cart_page_id' ) );
	$checkout_url = get_permalink( (int) get_option( 'woocommerce_checkout_page_id' ) );
	$account_url  = get_permalink( (int) get_option( 'woocommerce_myaccount_page_id' ) );

	bmspay_local_ensure_term( 'wp_theme', $theme_slug, $theme_slug );
	bmspay_local_ensure_term( 'wp_template_part_area', 'header', 'Header' );

	$template_part = get_page_by_path( 'header', OBJECT, 'wp_template_part' );
	$content       = '<!-- wp:group {"align":"full","className":"site-header-shell","style":{"spacing":{"padding":{"top":"24px","bottom":"24px","left":"32px","right":"32px"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group alignfull site-header-shell" style="padding-top:24px;padding-right:32px;padding-bottom:24px;padding-left:32px"><!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} --><div class="wp-block-group alignwide"><!-- wp:site-title {"level":0} /--><!-- wp:paragraph {"className":"site-header-nav"} --><p class="site-header-nav"><a href="' . esc_url_raw( (string) $cart_url ) . '">Cart</a><a href="' . esc_url_raw( (string) $checkout_url ) . '">Checkout</a><a href="' . esc_url_raw( (string) $account_url ) . '">My account</a></p><!-- /wp:paragraph --></div><!-- /wp:group --></div><!-- /wp:group -->';

	if ( ! $template_part ) {
		$template_part_id = wp_insert_post(
			array(
				'post_type'    => 'wp_template_part',
				'post_title'   => 'Header',
				'post_name'    => 'header',
				'post_status'  => 'publish',
				'post_content' => $content,
			)
		);

		if ( is_wp_error( $template_part_id ) ) {
			throw new RuntimeException( $template_part_id->get_error_message() );
		}

		$template_part = get_post( $template_part_id );
	} else {
		wp_update_post(
			array(
				'ID'           => $template_part->ID,
				'post_title'   => 'Header',
				'post_status'  => 'publish',
				'post_content' => $content,
			)
		);
	}

	wp_set_object_terms( $template_part->ID, array( $theme_slug ), 'wp_theme', false );
	wp_set_object_terms( $template_part->ID, array( 'header' ), 'wp_template_part_area', false );
}

function bmspay_local_ensure_checkout_header_template_part(): void {
	$theme_slug   = 'woocommerce/woocommerce';
	$cart_url     = get_permalink( (int) get_option( 'woocommerce_cart_page_id' ) );
	$checkout_url = get_permalink( (int) get_option( 'woocommerce_checkout_page_id' ) );
	$account_url  = get_permalink( (int) get_option( 'woocommerce_myaccount_page_id' ) );

	bmspay_local_ensure_term( 'wp_theme', $theme_slug, $theme_slug );
	bmspay_local_ensure_term( 'wp_template_part_area', 'header', 'Header' );

	$template_part = get_page_by_path( 'checkout-header', OBJECT, 'wp_template_part' );
	$content       = '<!-- wp:group {"align":"full","className":"site-header-shell","style":{"spacing":{"padding":{"top":"24px","bottom":"24px","left":"32px","right":"32px"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group alignfull site-header-shell" style="padding-top:24px;padding-right:32px;padding-bottom:24px;padding-left:32px"><!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} --><div class="wp-block-group alignwide"><!-- wp:site-title {"level":0} /--><!-- wp:paragraph {"className":"site-header-nav"} --><p class="site-header-nav"><a href="' . esc_url_raw( (string) $cart_url ) . '">Cart</a><a href="' . esc_url_raw( (string) $checkout_url ) . '">Checkout</a><a href="' . esc_url_raw( (string) $account_url ) . '">My account</a></p><!-- /wp:paragraph --></div><!-- /wp:group --></div><!-- /wp:group -->';

	if ( ! $template_part ) {
		$template_part_id = wp_insert_post(
			array(
				'post_type'    => 'wp_template_part',
				'post_title'   => 'Checkout Header',
				'post_name'    => 'checkout-header',
				'post_status'  => 'publish',
				'post_content' => $content,
			)
		);

		if ( is_wp_error( $template_part_id ) ) {
			throw new RuntimeException( $template_part_id->get_error_message() );
		}

		$template_part = get_post( $template_part_id );
	} else {
		wp_update_post(
			array(
				'ID'           => $template_part->ID,
				'post_title'   => 'Checkout Header',
				'post_status'  => 'publish',
				'post_content' => $content,
			)
		);
	}

	wp_set_object_terms( $template_part->ID, array( $theme_slug ), 'wp_theme', false );
	wp_set_object_terms( $template_part->ID, array( 'header' ), 'wp_template_part_area', false );
}

function bmspay_local_ensure_custom_css(): void {
	$css = <<<'CSS'
body.home .wp-site-blocks,
body.woocommerce-cart .wp-site-blocks,
body.woocommerce-checkout .wp-site-blocks,
body.woocommerce-account .wp-site-blocks {
  --wp--style--global--content-size: 1280px;
  --wp--style--global--wide-size: 1600px;
  max-width: 100%;
  overflow-x: clip;
}

body.home .site-header-shell,
body.woocommerce-cart .site-header-shell,
body.woocommerce-checkout .site-header-shell,
body.woocommerce-account .site-header-shell {
  border-bottom: 1px solid rgba(0, 0, 0, 0.06);
  box-sizing: border-box;
  max-width: 100%;
  overflow-x: clip;
}

body.home .site-header-nav,
body.woocommerce-cart .site-header-nav,
body.woocommerce-checkout .site-header-nav,
body.woocommerce-account .site-header-nav {
  display: flex !important;
  align-items: center;
  flex-wrap: wrap;
  gap: 28px;
  margin: 0;
  font-size: 1rem;
  white-space: nowrap;
}

body.home .site-header-nav a,
body.woocommerce-cart .site-header-nav a,
body.woocommerce-checkout .site-header-nav a,
body.woocommerce-account .site-header-nav a {
  text-decoration: none;
  display: inline-flex;
}

body.home main,
body.woocommerce-cart main,
body.woocommerce-checkout main,
body.woocommerce-account main {
  padding-left: 32px;
  padding-right: 32px;
}

body.home main {
  margin-top: 0 !important;
}

body.home .wp-block-post-title,
body.woocommerce-cart .wp-block-post-title,
body.woocommerce-checkout .wp-block-post-title {
  display: none !important;
}

body.home .entry-content.alignfull {
  max-width: 1600px !important;
  width: 100%;
  margin-left: auto !important;
  margin-right: auto !important;
}

body.woocommerce-cart .entry-content.alignwide,
body.woocommerce-checkout .entry-content.alignwide,
body.woocommerce-account .entry-content.alignwide {
  max-width: none !important;
  width: 100%;
  margin-left: 0 !important;
  margin-right: 0 !important;
}

body.woocommerce-cart .entry-content > .woocommerce,
body.woocommerce-checkout .entry-content > .woocommerce,
body.woocommerce-account .entry-content > .woocommerce,
body.woocommerce-checkout .wc-block-store-notices,
body.woocommerce-checkout .woocommerce-form-coupon-toggle,
body.woocommerce-checkout .woocommerce-form-login-toggle {
  width: 100% !important;
  max-width: none !important;
  margin-left: 0 !important;
  margin-right: 0 !important;
}

body.home .entry-content,
body.home .entry-content > .wp-block-group {
  max-width: 100%;
  overflow-x: clip;
}

body.home .entry-content > .wp-block-group {
  padding-top: 0 !important;
  padding-bottom: 40px !important;
}

body.home ul.products {
  display: grid !important;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 28px;
  width: 100%;
  margin: 0 !important;
  max-width: none !important;
}

body.home ul.products::before,
body.home ul.products::after {
  display: none !important;
  content: none !important;
}

body.home ul.products li.product {
  float: none !important;
  clear: none !important;
  width: 100% !important;
  margin: 0 !important;
  padding: 24px;
  border: 1px solid rgba(0, 0, 0, 0.08);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  min-height: 220px;
  box-sizing: border-box;
}

body.home ul.products li.product .woocommerce-LoopProduct-link {
  display: flex;
  flex-direction: column;
  gap: 12px;
  text-decoration: none;
}

body.home ul.products li.product .button {
  align-self: flex-start;
  margin-top: 20px;
}

body.home ul.products li.product .price {
  margin-top: 0;
}

body.home ul.products li.product img,
body.home ul.products li.product .woocommerce-loop-product__link img,
body.home ul.products li.product .attachment-woocommerce_thumbnail {
  display: none !important;
}

body.home .site-main,
body.woocommerce-cart .site-main,
body.woocommerce-checkout .site-main,
body.woocommerce-account .site-main {
  max-width: none;
}

body.woocommerce-cart form.woocommerce-cart-form,
body.woocommerce-checkout form.checkout,
body.woocommerce-checkout #order_review,
body.woocommerce-checkout .col2-set,
body.woocommerce-cart .woocommerce,
body.woocommerce-checkout form.checkout {
  max-width: none !important;
  width: 100%;
}

body.woocommerce-cart .woocommerce {
  display: grid;
  grid-template-columns: minmax(0, 1.7fr) minmax(320px, 0.9fr);
  gap: 40px;
  align-items: start;
}

body.woocommerce-cart .woocommerce-cart-form {
  grid-column: 1;
  margin: 0;
}

body.woocommerce-cart .cart-collaterals {
  grid-column: 2;
  width: 100%;
  margin: 0;
  float: none;
  position: sticky;
  top: 110px;
}

body.woocommerce-cart .cart-collaterals .cart_totals {
  width: 100%;
  float: none;
  margin: 0;
  padding: 24px;
  border: 1px solid rgba(0, 0, 0, 0.08);
  border-radius: 16px;
  box-sizing: border-box;
  background: #fff;
}

body.woocommerce-cart .wc-proceed-to-checkout {
  margin: 20px 0 0;
}

body.woocommerce-cart .wc-proceed-to-checkout .button {
  display: block;
  width: 100%;
  max-width: 100%;
  box-sizing: border-box;
  text-align: center;
}

body.woocommerce-checkout form.checkout {
  display: grid;
  width: 100% !important;
  min-width: 0;
  grid-template-columns: minmax(0, 0.88fr) minmax(520px, 1.12fr);
  gap: 28px;
  align-items: start;
  margin: 0;
}

body.woocommerce-checkout .col2-set {
  grid-column: 1;
  width: 100%;
  margin: 0;
}

body.woocommerce-checkout .col2-set .col-1,
body.woocommerce-checkout .col2-set .col-2 {
  float: none;
  width: 100%;
  margin: 0;
}

body.woocommerce-checkout .col2-set .col-2 {
  margin-top: 24px;
}

body.woocommerce-checkout #order_review_heading {
  grid-column: 2;
  display: none;
  margin: 0;
  align-self: start;
}

body.woocommerce-checkout #order_review {
  grid-column: 2;
  position: sticky;
  top: 110px;
  width: 100%;
  max-width: 100%;
  justify-self: stretch;
  margin: 0;
  padding: 24px;
  border: 1px solid rgba(0, 0, 0, 0.08);
  border-radius: 16px;
  background: #fff;
  box-sizing: border-box;
}

body.woocommerce-checkout #order_review::before {
  content: "Your order";
  display: block;
  margin-bottom: 20px;
  font-size: 2rem;
  line-height: 1.1;
  font-weight: 600;
}

body.woocommerce-checkout #payment {
  margin-top: 20px;
}

body.woocommerce-checkout .entry-content > .woocommerce {
  padding-bottom: 56px;
  box-sizing: border-box;
}

body.woocommerce-checkout #payment .place-order {
  margin-top: 24px;
  padding-top: 24px;
  padding-bottom: 24px;
}

body.woocommerce-checkout .woocommerce-form-login-toggle,
body.woocommerce-checkout .woocommerce-form-coupon-toggle,
body.woocommerce-checkout .checkout_coupon,
body.woocommerce-checkout .woocommerce-form-login {
  max-width: 1600px;
  margin-left: auto;
  margin-right: auto;
}

body.woocommerce-checkout .woocommerce-shipping-fields {
  display: none !important;
}

body.woocommerce-checkout .woocommerce-additional-fields {
  margin-top: 0;
}

body.woocommerce-account .entry-content > .woocommerce {
  max-width: 1600px !important;
  margin-left: auto !important;
  margin-right: auto !important;
  padding-bottom: 48px;
  box-sizing: border-box;
}

body.woocommerce-account #customer_login,
body.woocommerce-account .u-columns {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 40px;
  width: 100%;
  max-width: none !important;
  align-items: start;
}

body.woocommerce-account #customer_login > .u-column1,
body.woocommerce-account #customer_login > .u-column2,
body.woocommerce-account .u-column1,
body.woocommerce-account .u-column2 {
  float: none;
  width: 100% !important;
  max-width: none !important;
  justify-self: stretch;
  align-self: start;
  margin: 0;
}

body.woocommerce-account #customer_login > .u-column1 {
  grid-column: 1;
}

body.woocommerce-account #customer_login > .u-column2 {
  grid-column: 2;
}

body.woocommerce-account .woocommerce-form-login,
body.woocommerce-account .woocommerce-form-register {
  width: 100%;
  max-width: none;
  box-sizing: border-box;
  min-height: 100%;
}

@media (max-width: 900px) {
  body.home ul.products {
    grid-template-columns: 1fr;
  }

  body.home main,
  body.woocommerce-cart main,
  body.woocommerce-checkout main,
  body.woocommerce-account main {
    padding-left: 16px;
    padding-right: 16px;
  }

  body.woocommerce-cart .woocommerce,
  body.woocommerce-checkout form.checkout,
  body.woocommerce-account #customer_login,
  body.woocommerce-account .u-columns {
    display: block;
    width: 100% !important;
  }

  body.woocommerce-cart .cart-collaterals,
  body.woocommerce-checkout #order_review {
    position: static;
    margin-top: 24px;
  }

  body.woocommerce-checkout #order_review_heading {
    margin-top: 32px;
  }
}
CSS;

	wp_update_custom_css_post( $css );
}

$home_essentials_id   = bmspay_local_ensure_term( 'product_cat', 'home-essentials', 'Home Essentials' );
$everyday_faves_id    = bmspay_local_ensure_term( 'product_cat', 'everyday-favorites', 'Everyday Favorites' );

$products = array(
	array(
		'name'              => 'Demo Coffee Mug',
		'slug'              => 'demo-coffee-mug',
		'sku'               => 'DEMO-MUG',
		'price'             => '0.01',
		'stock_quantity'    => 24,
		'description'       => 'A simple product for cart, checkout and refund testing.',
		'short_description' => 'Simple test product.',
		'category_ids'      => array( $home_essentials_id ),
	),
	array(
		'name'              => 'Desk Organizer Tray',
		'slug'              => 'desk-organizer-tray',
		'sku'               => 'DEMO-TRAY',
		'price'             => '0.10',
		'stock_quantity'    => 18,
		'description'       => 'Mid-price product for checkout combinations and shipping validation.',
		'short_description' => 'Mid-price demo item.',
		'category_ids'      => array( $home_essentials_id ),
	),
	array(
		'name'              => 'Sparkling Citrus Pack',
		'slug'              => 'sparkling-citrus-pack',
		'sku'               => 'DEMO-CITRUS',
		'price'             => '1.00',
		'stock_quantity'    => 8,
		'description'       => 'Low-stock product to test inventory depletion and restocking after refunds.',
		'short_description' => 'Low-stock demo item.',
		'category_ids'      => array( $everyday_faves_id ),
	),
	array(
		'name'              => 'Notebook Set',
		'slug'              => 'notebook-set',
		'sku'               => 'DEMO-NOTEBOOK',
		'price'             => '3.00',
		'stock_quantity'    => 4,
		'description'       => 'Limited-quantity product for manual refund and stock restoration checks.',
		'short_description' => 'Limited-stock demo item.',
		'category_ids'      => array( $everyday_faves_id ),
	),
);

foreach ( $products as $product_data ) {
	bmspay_local_ensure_simple_product( $product_data );
}

bmspay_local_delete_shipping_zones();
bmspay_local_ensure_customer( $demo_customer_user, $demo_customer_password, $demo_customer_email );
bmspay_local_ensure_header_template_part();
bmspay_local_ensure_checkout_header_template_part();
bmspay_local_ensure_footer_template_part();
bmspay_local_ensure_custom_css();

$home_page_id = bmspay_local_ensure_page(
	'home',
	'Home',
	'<!-- wp:group {"layout":{"type":"constrained"}} --><div class="wp-block-group"><!-- wp:heading {"level":1,"align":"wide"} --><h1 class="wp-block-heading alignwide">Digital products demo</h1><!-- /wp:heading --><!-- wp:paragraph {"align":"wide"} --><p class="alignwide">Simple local catalog to test add to cart, checkout and payments with Blackstone.</p><!-- /wp:paragraph --><!-- wp:shortcode -->[products limit="8" columns="2" orderby="date" order="DESC"]<!-- /wp:shortcode --></div><!-- /wp:group -->'
);

update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $home_page_id );
update_option( 'page_for_posts', 0 );
update_option( 'woocommerce_shop_page_id', 0 );

bmspay_local_trash_page_by_slug( 'shop' );
bmspay_local_trash_page_by_slug( 'sample-page' );

$gateway_settings = get_option( 'woocommerce_bmspay_blackstone_payment_settings', array() );

if ( ! is_array( $gateway_settings ) ) {
	$gateway_settings = array();
}

$gateway_settings = array_merge(
	$gateway_settings,
	array(
		'enabled'               => 'yes',
		'title'                 => 'Blackstone',
		'description'           => 'Pay with the Blackstone gateway in local sandbox mode.',
		'environment'           => 'yes',
		'environment_3ds'       => 'no',
		'label_surcharge'       => 'Surcharge',
		'label_card_difference' => 'Dual pricing',
	)
);

update_option( 'woocommerce_bmspay_blackstone_payment_settings', $gateway_settings );

fwrite( STDOUT, "Local WooCommerce store seed applied.\n" );
