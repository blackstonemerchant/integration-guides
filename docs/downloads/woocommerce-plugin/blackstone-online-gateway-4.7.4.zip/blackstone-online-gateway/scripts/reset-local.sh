#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "Stopping containers and removing local volumes..."
docker compose down -v --remove-orphans

echo "Local environment removed. Run ./scripts/setup-local.sh to recreate it."
