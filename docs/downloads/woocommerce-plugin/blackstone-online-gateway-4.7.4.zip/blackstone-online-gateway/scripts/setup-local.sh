#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

MODE="${1:-setup}"
IS_SEED_ONLY=0
JUST_INSTALLED=0

if [[ "${MODE}" == "--seed-only" || "${MODE}" == "seed" ]]; then
  IS_SEED_ONLY=1
fi

if [[ ! -f .env ]]; then
  echo "Missing .env. Copy .env.example to .env and adjust values if needed."
  exit 1
fi

get_env_value() {
  local key="$1"
  local value

  value="$(grep -E "^${key}=" .env | tail -n 1 | cut -d'=' -f2-)"
  value="${value%\"}"
  value="${value#\"}"
  value="${value%\'}"
  value="${value#\'}"
  printf '%s' "$value"
}

WORDPRESS_PORT="$(get_env_value WORDPRESS_PORT)"
PHPMYADMIN_PORT="$(get_env_value PHPMYADMIN_PORT)"
MYSQL_DATABASE="$(get_env_value MYSQL_DATABASE)"
MYSQL_USER="$(get_env_value MYSQL_USER)"
MYSQL_PASSWORD="$(get_env_value MYSQL_PASSWORD)"
MYSQL_ROOT_PASSWORD="$(get_env_value MYSQL_ROOT_PASSWORD)"
WP_HOME="$(get_env_value WP_HOME)"
WP_SITE_TITLE="$(get_env_value WP_SITE_TITLE)"
WP_ADMIN_USER="$(get_env_value WP_ADMIN_USER)"
WP_ADMIN_PASSWORD="$(get_env_value WP_ADMIN_PASSWORD)"
WP_ADMIN_EMAIL="$(get_env_value WP_ADMIN_EMAIL)"
DEMO_CUSTOMER_USER="$(get_env_value DEMO_CUSTOMER_USER)"
DEMO_CUSTOMER_PASSWORD="$(get_env_value DEMO_CUSTOMER_PASSWORD)"
DEMO_CUSTOMER_EMAIL="$(get_env_value DEMO_CUSTOMER_EMAIL)"
WOOCOMMERCE_VERSION="$(get_env_value WOOCOMMERCE_VERSION)"

DEMO_CUSTOMER_USER="${DEMO_CUSTOMER_USER:-customer}"
DEMO_CUSTOMER_PASSWORD="${DEMO_CUSTOMER_PASSWORD:-customer}"
DEMO_CUSTOMER_EMAIL="${DEMO_CUSTOMER_EMAIL:-customer@example.com}"

compose() {
  docker compose "$@"
}

wp() {
  compose run --rm wpcli wp "$@"
}

echo "Starting local services..."
compose up -d db wordpress phpmyadmin

echo "Waiting for MariaDB..."
until compose exec -T db mariadb-admin ping -h 127.0.0.1 -uroot -p"${MYSQL_ROOT_PASSWORD}" --silent >/dev/null 2>&1; do
  sleep 2
done

echo "Waiting for WP-CLI..."
until wp --info >/dev/null 2>&1; do
  sleep 2
done

echo "Waiting for WordPress configuration..."
until compose exec -T wordpress test -f /var/www/html/wp-config.php >/dev/null 2>&1; do
  sleep 2
done

echo "Ensuring writable WordPress runtime directories..."
compose exec -T wordpress sh -lc "mkdir -p /var/www/html/wp-content/uploads /var/www/html/wp-content/languages /var/www/html/wp-content/upgrade /var/www/html/wp-content/plugins && chmod 777 /var/www/html/wp-content/uploads /var/www/html/wp-content/languages /var/www/html/wp-content/upgrade /var/www/html/wp-content/plugins"

if ! wp core is-installed --allow-root >/dev/null 2>&1; then
  echo "Installing WordPress..."
  wp core install \
    --url="${WP_HOME}" \
    --title="${WP_SITE_TITLE}" \
    --admin_user="${WP_ADMIN_USER}" \
    --admin_password="${WP_ADMIN_PASSWORD}" \
    --admin_email="${WP_ADMIN_EMAIL}" \
    --skip-email \
    --allow-root
  JUST_INSTALLED=1
fi

CURRENT_HOME="$(wp option get home --allow-root 2>/dev/null || true)"
CURRENT_SITEURL="$(wp option get siteurl --allow-root 2>/dev/null || true)"

if [[ -n "${CURRENT_HOME}" && "${CURRENT_HOME}" != "${WP_HOME}" ]]; then
  echo "Updating site URL from ${CURRENT_HOME} to ${WP_HOME}..."
  wp option update home "${WP_HOME}" --allow-root >/dev/null
  wp option update siteurl "${WP_HOME}" --allow-root >/dev/null
  wp search-replace "${CURRENT_HOME}" "${WP_HOME}" --skip-columns=guid --all-tables --allow-root
elif [[ -n "${CURRENT_SITEURL}" && "${CURRENT_SITEURL}" != "${WP_HOME}" ]]; then
  echo "Updating site URL from ${CURRENT_SITEURL} to ${WP_HOME}..."
  wp option update home "${WP_HOME}" --allow-root >/dev/null
  wp option update siteurl "${WP_HOME}" --allow-root >/dev/null
  wp search-replace "${CURRENT_SITEURL}" "${WP_HOME}" --skip-columns=guid --all-tables --allow-root
fi

if [[ "${IS_SEED_ONLY}" -eq 0 || "${JUST_INSTALLED}" -eq 1 ]]; then
  echo "Installing and activating es_ES..."
  WP_CORE_VERSION="$(wp core version --allow-root)"
  wp eval "
require_once ABSPATH . 'wp-admin/includes/file.php';
WP_Filesystem();
\$url = 'https://downloads.wordpress.org/translation/core/${WP_CORE_VERSION}/es_ES.zip';
\$tmp = download_url( \$url );
if ( is_wp_error( \$tmp ) ) {
	fwrite( STDERR, \$tmp->get_error_message() . PHP_EOL );
	exit( 1 );
}
\$result = unzip_file( \$tmp, WP_CONTENT_DIR . '/languages' );
@unlink( \$tmp );
if ( is_wp_error( \$result ) ) {
	fwrite( STDERR, \$result->get_error_message() . PHP_EOL );
	exit( 1 );
}
" --allow-root
fi
wp option update WPLANG es_ES --allow-root >/dev/null
wp site switch-language es_ES --allow-root || true

if ! wp plugin is-installed woocommerce --allow-root >/dev/null 2>&1; then
  echo "Installing WooCommerce ${WOOCOMMERCE_VERSION}..."
  wp plugin install woocommerce --version="${WOOCOMMERCE_VERSION}" --force --activate --allow-root
else
  echo "Ensuring WooCommerce is active..."
  wp plugin activate woocommerce --allow-root >/dev/null || true
fi

echo "Activating Blackstone gateway plugin..."
wp plugin activate blackstone-online-gateway --allow-root >/dev/null || true

echo "Seeding local WooCommerce store..."
wp eval-file /var/www/html/wp-content/plugins/blackstone-online-gateway/scripts/seed-local-store.php \
  "${DEMO_CUSTOMER_USER}" \
  "${DEMO_CUSTOMER_PASSWORD}" \
  "${DEMO_CUSTOMER_EMAIL}" \
  --allow-root

echo "Setting permalink structure..."
wp rewrite structure '/%postname%/' --hard --allow-root
wp rewrite flush --hard --allow-root

echo
if [[ "${MODE}" == "--seed-only" || "${MODE}" == "seed" ]]; then
  echo "Local store seed refreshed."
else
  echo "Local environment ready."
fi
echo "Site: ${WP_HOME}"
echo "Admin: ${WP_HOME}/wp-admin"
echo "phpMyAdmin: http://localhost:${PHPMYADMIN_PORT}"
echo "Admin user: ${WP_ADMIN_USER}"
echo "Admin password: ${WP_ADMIN_PASSWORD}"
echo "Demo customer: ${DEMO_CUSTOMER_USER}"
echo "Demo customer password: ${DEMO_CUSTOMER_PASSWORD}"
