<?php
if ( !defined( 'ABSPATH' ) ) exit;
class bmspay_Blackstone_Payment extends WC_Payment_Gateway_CC
{
  public $environment;
  public $environment_3ds;
  public $app_key;
  public $api_username;
  public $api_password;
  public $api_mid;
  public $api_cid;
  public $app_type;
  public $label_surcharge;
  public $label_card_difference;

  function __construct()
  {
    $this->id = "bmspay_blackstone_payment";
    $this->method_title = __("Blackstone", 'blackstone-online-gateway');
    $this->method_description = __("Blackstone Online Gateway Plug-in for WooCommerce", 'blackstone-online-gateway');
    $this->title = __("Blackstone", 'blackstone-online-gateway');
    $this->icon = null;
    $this->has_fields = true;
    $this->supports = array('default_credit_card_form');
    $this->init_form_fields();
    $this->init_settings();

    foreach ($this->settings as $setting_key => $value) {
      $this->$setting_key = $value;
    }

    add_action('admin_notices', array($this,  'do_ssl_check'));
    remove_action('woocommerce_review_order_after_submit', 'woocommerce_order_submit_button', 10);
    
    add_action('wp_enqueue_scripts', array($this, 'enqueue_checkout_assets'));

    if (is_admin()) {
      add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }
  }

  public function enqueue_checkout_assets() {
    if (is_checkout() || is_order_pay_page()) {
      if ($this->enabled !== 'yes') return;

      // Enqueue Styles
      wp_enqueue_style(
        'bmspay-payment-form',
        plugins_url('assets/css/bmspay-payment-form.css', __FILE__),
        array(),
        '1.0.0'
      );

      // Enqueue Scripts
      wp_enqueue_script(
        'bmspay-payment-form',
        plugins_url('assets/js/bmspay-payment-form.js', __FILE__),
        array('jquery'),
        '1.0.0',
        true
      );

      // Enqueue SweetAlert2 if not already enqueued
      wp_enqueue_script(
        'sweetalert2',
        plugins_url('assets/js/sweetalert2_11.js', __FILE__),
        array('jquery'),
        '11.0.0',
        true
      );

      // 3D Secure Logic
      $surcharge_data = $this->get_cached_surcharge_data();
      $threeds_enabled = $surcharge_data['response_ThreeDSecureEnabled'];

      if ($threeds_enabled) {
          $threed_secure_data = $this->get_merchant_tokenthreeds();
          $apiKey = $threed_secure_data['response_ApiKey'];
          $token = $threed_secure_data['response_Token'];

          if (!empty($apiKey) && !empty($token)) {
             WC()->session->set('threed_secure_apikey', $apiKey);
             WC()->session->set('threed_secure_token', $token);

             $environment = $this->getEnvironment3DS();
             $endpoint = $environment == 'yes'
               ? 'https://api-sandbox.3dsintegrator.com/v2.2'
               : 'https://api.3dsintegrator.com/v2.2';
            
             // Enqueue 3DS Library
             // Use CDN as per documentation to avoid 401 on API endpoint
             wp_enqueue_script(
                 'bmspay-3ds',
                  'https://cdn.3dsintegrator.com/threeds.2.2.20231219.min.js', 
                 array(),
                 null,
                 true
             );

             wp_enqueue_script(
                'bmspay-checkout',
                plugins_url('assets/js/bmspay-checkout.js', __FILE__),
                array('jquery', 'sweetalert2', 'bmspay-3ds'), // Depends on 3DS lib
                '1.0.0',
                true
             );

             wp_localize_script('bmspay-checkout', 'bmspay_checkout_params', array(
                 'apiKey' => $apiKey,
                 'token' => $token,
                 'total' => getTotalAmount(),
                 'endpoint' => $endpoint
             ));
          }
      }
    }
  }

  public function init_form_fields()
  {
    $this->form_fields = array(
      'enabled'      => array(
        'title'        => __('Enable / Disable', 'blackstone-online-gateway'),
        'label'        => __('Enable this payment gateway', 'blackstone-online-gateway'),
        'type'         => 'checkbox',
        'default'      => 'no',
      ),
      'title'        => array(
        'title'        => __('Title', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('Payment title of checkout process.', 'blackstone-online-gateway'),
        'default'      => __('Credit card', 'blackstone-online-gateway'),
      ),
      'description'  => array(
        'title'        => __('Description', 'blackstone-online-gateway'),
        'type'         => 'textarea',
        'desc_tip'     => __('Payment title of checkout process.', 'blackstone-online-gateway'),
        'default'      => __('Successfully payment through credit card.', 'blackstone-online-gateway'),
        'css'          => 'max-width:450px;'
      ),
      'api_username' => array(
        'title'        => __('Username', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the username provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'api_password' => array(
        'title'        => __('Password', 'blackstone-online-gateway'),
        'type'         => 'password',
        'desc_tip'     => __('This is the password provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'api_mid'      => array(
        'title'        => __('MID', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the MID code provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'api_cid'      => array(
        'title'        => __('CID', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the CID code provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'app_type'     => array(
        'title'        => __('App Type', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the App Type provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'app_key'      => array(
        'title'        => __('App Key', 'blackstone-online-gateway'),
        'type'         => 'password',
        'desc_tip'     => __('This is the App Key provided by Blackstone when you signed up for an account.', 'blackstone-online-gateway'),
      ),
      'environment'  => array(
        'title'        => __('Test Mode', 'blackstone-online-gateway'),
        'label'        => __('Enable Test Mode', 'blackstone-online-gateway'),
        'type'         => 'checkbox',
        'desc_tip'     => __('This is the sandbox of the gateway.', 'blackstone-online-gateway'),
        'default'      => 'no',
      ),
      'environment_3ds'  => array(
        'title'        => __('3D Secure Test Mode', 'blackstone-online-gateway'),
        'label'        => __('Enable 3D Secure Test Mode', 'blackstone-online-gateway'),
        'type'         => 'checkbox',
        'desc_tip'  => __('This is the sandbox of 3D Secure.', 'blackstone-online-gateway'),
        'default'      => 'no',
      ),
      'label_surcharge' => array(
        'title'        => __('Surcharge Label', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the name that will be shown to your customers wherever a surcharge is applied (for example, in the order summary or invoice).', 'blackstone-online-gateway'),
        'default'      => 'Surcharge',
      ),
      'label_card_difference' => array(
        'title'        => __('Dual Pricing Label', 'blackstone-online-gateway'),
        'type'         => 'text',
        'desc_tip'     => __('This is the name that will be shown to your customers wherever the card difference (dual pricing) is applied. For example, in the order summary or invoice.', 'blackstone-online-gateway'),
        'default'      => 'Dual pricing',
      ),
    );
  }

  public function payment_fields()
  {
    if ($this->enabled !== 'yes') {
      return;
    }
    $user_id = get_current_user_id();
    $saved_methods = WC_Payment_Tokens::get_customer_tokens($user_id);

    echo '<div id="saved-payment-methods" class="payment-methods-container">';

    if ($saved_methods) {
      echo '<p class="payment-methods-title">' . esc_html(__('Select a saved card:', 'blackstone-online-gateway')) . '</p>';
      echo '<ul class="wc-saved-payment-methods">';

      foreach ($saved_methods as $token) {
        /** @var WC_Payment_Token_CC $token */
        $last4 = $token->get_last4();
        $token_id = $token->get_id();

        echo '<li class="payment-option">';
        echo '<input type="radio" id="token-' . esc_attr($token_id) . '" name="wc-saved-payment-token" value="' . esc_attr($token_id) . '" />';
        echo '<label for="token-' . esc_attr($token_id) . '" class="payment-label">';
        echo '<span class="card-icon">💳</span> ';
        echo esc_html(__('Card ending in:', 'blackstone-online-gateway')) . ' ' . esc_html($last4);
        echo '</label>';
        echo '</li>';
      }

      echo '</ul>';
    } else {
      echo '<p class="no-saved-methods">' . esc_html__('You do not have saved payment methods', 'blackstone-online-gateway') . '</p>';
    }

    echo '<ul class="wc-saved-payment-methods">';
    echo '<li class="payment-option">';
    echo '<input type="radio" id="token-new" name="wc-saved-payment-token" value="new" checked />';
    echo '<label for="token-new" class="payment-label">';
    echo '<span class="card-icon"></span> ' . esc_html__('Use a new payment method', 'blackstone-online-gateway');
    echo '</label>';
    echo '</li>';
    echo '</ul>';
    echo '</div>';
    echo '<div id="new-payment-method" class="new-payment-method-section">';
    echo '<p class="new-payment-title">' . esc_html__('Enter your card details:', 'blackstone-online-gateway') . '</p>';
    $this->form();
    echo '</div>';

?>

    <?php
  }

  public function otherAmount($total)
  {
    if ($this->enabled !== 'yes') {
      return (object)[
        'total_surcharge' => 0,
        'total_card_difference' => 0,
        'total' => bmspay_format_decimal_amount($total),
      ];
    }

    $breakdown = bmspay_get_current_charge_breakdown($this);

    return (object)[
      'total_surcharge' => bmspay_format_decimal_amount($breakdown['surcharge_amount']),
      'total_card_difference' => bmspay_format_decimal_amount($breakdown['card_difference_amount']),
      'total' => bmspay_format_decimal_amount($breakdown['charge_amount']),
    ];
  }

  public function get_cached_surcharge_data()
  {
    if ($this->enabled !== 'yes') {
      return array(
        'response_SurchargeEnabled' => false,
        'response_SurchargePercent' => 0,
        'response_CardDifferenceEnabled' => false,
        'response_CardDifferencePercent' => 0,
        'response_ThreeDSecureEnabled' => false
      );
    }
    $surcharge_cache_key = 'bmspay_surcharge_data_' . get_current_user_id();
    $surcharge_data = get_transient($surcharge_cache_key);
    delete_transient($surcharge_cache_key);

    if ($surcharge_data === false) {
      $surcharge_data = $this->get_merchant_setting();
      delete_transient($surcharge_cache_key);
      set_transient($surcharge_cache_key, $surcharge_data, MINUTE_IN_SECONDS);
    }
    return $surcharge_data;
  }
  public function get_merchant_setting()
  {
    $data = $this->prepare_credential_data(true);

    $environment_url = $this->get_basic_url('BusinessSettings', false);

    $response = wp_remote_post($environment_url, array(
      'method' => 'POST',
      'body' => http_build_query($data),
      'timeout' => 45,
      'headers' => array(),
    ));

    $surcharge_percent = 0;
    $surcharge_enabled = 0;
    $card_difference_percent = 0;
    $card_difference_enabled = 0;
    $threed_secure_enabled = 0;
    //$threed_secure_enabled = true; // Eliminar

    if (is_wp_error($response)) {
      wc_add_notice(__('Merchant setting error:', 'blackstone-online-gateway') . ' ' . $response->get_error_message(), 'error');
      return;
    } else {
      $response_body = wp_remote_retrieve_body($response);
      $response_data = json_decode($response_body, true);


      if (isset($response_data['SurchargeEnabled']) && $response_data['SurchargeEnabled'] === true) {
        $surcharge_percent = $response_data['SurchargePercent'];
        $surcharge_enabled = true;
      }
      if (isset($response_data['CardDifferenceEnabled']) && $response_data['CardDifferenceEnabled'] === true) {
        $card_difference_percent = $response_data['CardDifferencePercent'];
        $card_difference_enabled = true;
      }
      if (isset($response_data['ThreeDSecureEnabled']) && $response_data['ThreeDSecureEnabled'] === true) {
        $threed_secure_enabled = true;
      }
    }
    $array = array(
      'response_SurchargeEnabled' => $surcharge_enabled,
      'response_SurchargePercent' => $surcharge_percent,
      'response_CardDifferenceEnabled' => $card_difference_enabled,
      'response_CardDifferencePercent' => $card_difference_percent,
      'response_ThreeDSecureEnabled' => $threed_secure_enabled
    );
    return $array;
  }
  public function get_merchant_tokenthreeds()
  {
    $data = (array)$this->prepare_credential_data(true);

    $environment_url = $this->get_basic_url('Auth/TokenThreeDS', false);

    $response = wp_remote_post($environment_url, array(
      'method' => 'POST',
      'body' => http_build_query($data),
      'timeout' => 45,
      'headers' => array(),
    ));

    return $this->process_threeds_response($response);
  }

  private function prepare_credential_data($threeds = false)
  {
    $remote_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';

    if ($threeds && $this->environment_3ds == 'yes') {
      return array(
        "mid" => "98208",
        "UserName" =>  "617D46A6-3A1A-4A67-850A-89F7E4F48049",
        "Password" =>  "CYC-4, LLC",
        "AppType" =>  "11200",
        "AppKey" =>  "563C17A4-A4E3-4A6F-BBF6-FC8B8B8E7F9F",
        "cid" =>  "6310",
        "IpAddress" => $remote_ip,
        "Source" => "ApiClient",
        "UserTest" => "True"
      );
    }
    return array(
      "mid" => $this->environment == 'yes' ? "76074" : $this->api_mid,
      "UserName" => $this->environment == 'yes' ? "nicolas" : $this->api_username,
      "Password" => $this->environment == 'yes' ? "password1" : $this->api_password,
      "AppType" => $this->environment == 'yes' ? "1" : $this->app_type,
      "AppKey" => $this->environment == 'yes' ? "12345" : $this->app_key,
      "cid" => $this->environment == 'yes' ? "260" : $this->api_cid,
      "IpAddress" => $remote_ip,
      "Source" => "ApiClient",
      "UserTest" => $this->environment == 'yes' ? "True" : "False"
    );
  }

  private function get_basic_url($endpoint, $is_test = false)
  {
    $base_url = 'https://services.bmspay.com/';
    $path = $is_test ? 'testing/api/' : 'api/';
    return ($this->environment == 'yes') ? $base_url . $path . $endpoint : $base_url . 'api/' . $endpoint;
  }

  private function process_threeds_response($response)
  {
    if (is_wp_error($response)) {
      wc_add_notice(__('Token threeDS error:', 'blackstone-online-gateway') . ' ' . $response->get_error_message(), 'error');
      return array('response_ApiKey' => '', 'response_Token' => '');
    }

    $response_body = wp_remote_retrieve_body($response);
    $response_data = json_decode($response_body, true);
    WC()->session->__unset('threed_secure_apikey');
    WC()->session->__unset('threed_secure_token');
    WC()->session->set('threed_secure_apikey', isset($response_data['ApiKey']) ? $response_data['ApiKey'] : '');
    WC()->session->set('threed_secure_token', isset($response_data['Token']) ? $response_data['Token'] : '');

    return array(
      'response_ApiKey' => isset($response_data['ApiKey']) ? $response_data['ApiKey'] : '',
      'response_Token' => isset($response_data['Token']) ? $response_data['Token'] : '',
    );
  }
  function evaluarResultado3DS($data)
  {
    $status = $data['status'] ?? null;

    switch ($status) {
      case 'Y':
        return [
          'success' => true,
          'message' => 'Autenticación 3D Secure exitosa (Status: Y)',
        ];
      case 'A':
        return [
          'success' => true,
          'message' => 'Autenticación 3DS fue realizada por el emisor pero no fue friccional (Status: A)',
        ];
      case 'N':
        $reason = $data['transStatusReasonDetail'] ?? 'Transacción no autenticada';
        return [
          'success' => false,
          'message' => "Autenticación fallida (Status: N). Motivo: {$reason}",
        ];
      case 'C':
        $reason = $data['transStatusReasonDetail'] ?? 'Desafío requerido; Se necesita autenticación adicional';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: C). Motivo: {$reason}",
        ];
      case 'R':
        $reason = $data['transStatusReasonDetail'] ?? 'Autenticación / Verificación de cuenta rechazada; El emisor está rechazando la autenticación/verificación y solicita que no se intente la autorización.';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: R). Motivo: {$reason}",
        ];
      case 'U':
        $reason = $data['transStatusReasonDetail'] ?? 'Fallo técnico o no disponible';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: U). Motivo: {$reason}",
        ];
      case 'I':
        $reason = $data['transStatusReasonDetail'] ?? 'Fallo técnico o no disponible';
        return [
          'success' => false,
          'message' => "No fue posible completar la autenticación (Status: U). Motivo: {$reason}",
        ];
      default:
        $message = (get_locale() === 'es_ES') ? 'No se pudo completar la verificación de su método de pago. Intente nuevamente o use otro método' : 'The verification of your payment method could not be completed. Please try again or use a different method.';
        if (WC()->session->get('threed_secure_enabled')) {
          return [
            'success' => false,
            'message' => $message,
          ];
        } else {
          return [
            'success' => false,
            'message' => $message,
          ];
        }
    }
  }

  public function process_payment($order_id)
  {

    $SecureData = '';
    $SecureTransactionId = '';
    if (isset($_POST['threeds_response'])) {
      try {
        $raw_threeds_response = isset($_POST['threeds_response']) ? sanitize_text_field(wp_unslash($_POST['threeds_response'])) : '';
        $sanitized_json = sanitize_textarea_field($raw_threeds_response); // mejor que sanitize_text_field para JSON

        $threedsData = json_decode($sanitized_json, true);

        if (json_last_error() !== JSON_ERROR_NONE || ! is_array($threedsData)) {
          throw new Exception(__('Invalid 3DS response data.', 'blackstone-online-gateway'));
        }

        $resultado = $this->evaluarResultado3DS($threedsData);
      } catch (Exception $e) {
        error_log('Error procesando 3DS: ' . $e->getMessage());
        wc_add_notice(
          __('Authentication could not be completed: ', 'blackstone-online-gateway') . esc_html($e->getMessage()),
          'error'
        );
        wp_die();
      }

      if (! empty($resultado['success'])) {
        $SecureData = sanitize_text_field($threedsData['authenticationValue'] ?? '');
        $SecureTransactionId = sanitize_text_field($threedsData['threeDsTransactionId'] ?? '');
      } else {
        wc_add_notice(esc_html($resultado['message']), 'error');
        return;
      }
    }

    global $woocommerce;
    $Source = "BPaydPlugin";
    $remote_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';

    $credentials = $this->prepare_credential_data(true);
    $is_test = $credentials['UserTest'];
    $customer_order = new WC_Order($order_id);

    if (isset($_POST['wc-saved-payment-token']) && $_POST['wc-saved-payment-token'] !== 'new') {

      $token_id = sanitize_text_field(wp_unslash($_POST['wc-saved-payment-token']));
      $token = WC_Payment_Tokens::get($token_id);

      if ($token && $token->get_user_id() === get_current_user_id()) {

        /** @var WC_Payment_Token_CC $token */
        $last4 = $token->get_last4();
        $expiry_month = $token->get_expiry_month();
        $expiry_year = $token->get_expiry_year();
        $token_string = $token->get_token();

        $environment_url = $this->get_basic_url('Transactions/SaleWithToken', false);

        $full_name = ($customer_order->get_billing_first_name() . ' ' . $customer_order->get_billing_last_name());

        $charge_breakdown = bmspay_get_order_charge_breakdown(
          $customer_order,
          $this,
          bmspay_get_charge_overrides($order_id)
        );

        $userTransactionNumber = (md5(uniqid($customer_order->get_order_number(), true)));

        $payload = array(
          "Token"                 => $token_string,
          "UserName"              => $credentials['UserName'],
          "Password"              => $credentials['Password'],
          "mid"                   => $credentials['mid'],
          "cid"                   => $credentials['cid'],
          "AppKey"                => $credentials['AppKey'],
          "AppType"               => $credentials['AppType'],
          "Amount"                => bmspay_format_decimal_amount($charge_breakdown['base_amount']),
          "TaxAmount"             => 0,
          "TipAmount"             => 0,
          "SurchargeAmount"       => bmspay_format_decimal_amount($charge_breakdown['surcharge_amount']),
          "CardDifferenceAmount"  => bmspay_format_decimal_amount($charge_breakdown['card_difference_amount']),
          "TransactionType"       => 2,
          "Track2"                => "",
          "ZipCode"               => $customer_order->get_billing_postcode(),
          "ExpDate"               => ($expiry_month . substr($expiry_year, 2, 2)),
          "NameOnCard"            => $full_name,
          "UserTransactionNumber" => $userTransactionNumber,
          "Source"                => $Source,
          "SecureData"           => $SecureData,
          "PosCode"              => "Moto",
          "SecureTransactionId"  => $SecureTransactionId,

          "x_first_name"          => $customer_order->get_billing_first_name(),
          "x_last_name"           => $customer_order->get_billing_last_name(),
          "x_address"             => $customer_order->get_billing_address_1(),
          "x_city"                => $customer_order->get_billing_city(),
          "x_state"               => $customer_order->get_billing_state(),
          "x_zip"                 => $customer_order->get_billing_postcode(),
          "x_country"             => $customer_order->get_billing_country(),
          "x_phone"               => $customer_order->get_billing_phone(),
          "x_email"               => $customer_order->get_billing_email(),

          // Customer fields
          "SaveCustomer"           => 'True',
          "IsTest"                 => $is_test,
          "CustomerId"             => $order_id,
          "CustomerPhone"          => $customer_order->get_billing_phone(),
          "CustomerEmail"          => $customer_order->get_billing_email(),
          "CustomerCountry"        => $customer_order->get_billing_country(),
          "CustomerState"          => $customer_order->get_billing_state(),
          "CustomerCity"           => $customer_order->get_billing_city(),
          "CustomerAddress"        => $customer_order->get_billing_address_1(),
          "OrderReference"         => $order_id,

          "x_ship_to_first_name"   => $customer_order->get_shipping_first_name(),
          "x_ship_to_last_name"    => $customer_order->get_shipping_last_name(),
          "x_ship_to_company"      => $customer_order->get_shipping_company(),
          "x_ship_to_address"      => $customer_order->get_shipping_address_1(),
          "x_ship_to_city"         => $customer_order->get_shipping_city(),
          "x_ship_to_country"      => $customer_order->get_shipping_country(),
          "x_ship_to_state"        => $customer_order->get_shipping_state(),
          "x_ship_to_zip"          => $customer_order->get_shipping_postcode(),
          "x_cust_id"              => $customer_order->get_user_id(),
          "x_customer_ip"          => $remote_ip,
        );

        $response = wp_remote_post($environment_url, array(
          'method'               => 'POST',
          'headers'              => array('Content-Type' => 'application/x-www-form-urlencoded'),
          'body'                 => http_build_query($payload),
          'timeout'              => 90,
          'sslverify'            => false,
        ));

        if (is_wp_error($response))
          throw new Exception(esc_html__('There is issue for connectin payment gateway. Sorry for the inconvenience.', 'blackstone-online-gateway'));
        if (empty($response['body']))
          throw new Exception(esc_html__('Blackstone\'s Response was not get any data.', 'blackstone-online-gateway'));

        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        error_log(print_r($environment_url, true));
        error_log(print_r($payload, true));
        error_log(print_r($response_data, true));

        if (isset($response_data['ResponseCode']) && $response_data['ResponseCode'] == "200") {

          $customer_order->add_order_note(__('Blackstone complete payment.', 'blackstone-online-gateway'));

          if (isset($response_data['ServiceReferenceNumber'])) {
            $ServiceReferenceNumber = $response_data['ServiceReferenceNumber'];
            $customer_order->update_meta_data('_bmspay_service_reference_number', $ServiceReferenceNumber);
            $customer_order->add_order_note(__('Transaction ID: ', 'blackstone-online-gateway') . $ServiceReferenceNumber);
          }
          if (isset($payload['UserTransactionNumber'])) {
            $UserTransactionNumber = $payload['UserTransactionNumber'];
            $customer_order->update_meta_data('_bmspay_transaction_number', $UserTransactionNumber);
            $customer_order->add_order_note(__('User Transaction Number: ', 'blackstone-online-gateway') . $UserTransactionNumber);
          }
          $customer_order->payment_complete();
          $woocommerce->cart->empty_cart();

          $customer_order->save();

          return array(
            'result'   => 'success',
            'redirect' => $this->get_return_url($customer_order),
          );
        } else {
          $msg = $this->get_message_error($response_data);
          wc_add_notice($msg, 'error');
          $msg = $this->get_message_error_full($response_data, $userTransactionNumber);
          $customer_order->add_order_note('Error: ' . $msg);
        }
      } else {
        wc_add_notice(__('Invalid payment method selected.', 'blackstone-online-gateway'), 'error');
        return;
      }
    } else {
      $environment_url = $this->get_basic_url('Transactions/Sale', false);

      $full_name = ($customer_order->get_billing_first_name() . ' ' . $customer_order->get_billing_last_name());

      $charge_breakdown = bmspay_get_order_charge_breakdown(
        $customer_order,
        $this,
        bmspay_get_charge_overrides($order_id)
      );

      $userTransactionNumber = (md5(uniqid($customer_order->get_order_number(), true)));

      $payload = array(
        "UserName"              => $credentials['UserName'],
        "Password"              => $credentials['Password'],
        "mid"                   => $credentials['mid'],
        "cid"                   => $credentials['cid'],
        "AppKey"                => $credentials['AppKey'],
        "AppType"               => $credentials['AppType'],
        "Amount"                => bmspay_format_decimal_amount($charge_breakdown['base_amount']),
        "TaxAmount"             => 0,
        "TipAmount"             => 0,
        "SurchargeAmount"       => bmspay_format_decimal_amount($charge_breakdown['surcharge_amount']),
        "CardDifferenceAmount"  => bmspay_format_decimal_amount($charge_breakdown['card_difference_amount']),
        "TransactionType"       => 1,
        "Track2"                => "",
        "ZipCode"               => $this->environment == 'yes' ? "12345" : $customer_order->get_billing_postcode(),
        "ExpDate"               => isset($_POST['bmspay_blackstone_payment-card-expiry']) ? str_replace(array('/', ' '), '',  sanitize_text_field(wp_unslash($_POST['bmspay_blackstone_payment-card-expiry']))) : '',
        "CardNumber"            => isset($_POST['bmspay_blackstone_payment-card-number']) ? str_replace(array(' ', '-'), '',  sanitize_text_field(wp_unslash($_POST['bmspay_blackstone_payment-card-number']))) : '',
        "CVN"                   => isset($_POST['bmspay_blackstone_payment-card-cvc']) ? sanitize_text_field(wp_unslash($_POST['bmspay_blackstone_payment-card-cvc'])) : '',
        "NameOnCard"            => $full_name,

        "UserTransactionNumber" => $userTransactionNumber,
        "Source"                => $Source,
        "SecureData"            => $SecureData,
        "PosCode"               => "Moto",
        "SecureTransactionId"   => $SecureTransactionId,
        "SaveToken"             => "True",

        "x_first_name"          => $customer_order->get_billing_first_name(),
        "x_last_name"           => $customer_order->get_billing_last_name(),
        "x_address"             => $customer_order->get_billing_address_1(),
        "x_city"                => $customer_order->get_billing_city(),
        "x_state"               => $customer_order->get_billing_state(),
        "x_zip"                 => $customer_order->get_billing_postcode(),
        "x_country"             => $customer_order->get_billing_country(),
        "x_phone"               => $customer_order->get_billing_phone(),
        "x_email"               => $customer_order->get_billing_email(),

        // Customer fields
        "SaveCustomer"           => 'True',
        "IsTest"                 => $is_test,
        "CustomerId"             => $order_id,
        "CustomerPhone"          => $customer_order->get_billing_phone(),
        "CustomerEmail"          => $customer_order->get_billing_email(),
        "CustomerCountry"        => $customer_order->get_billing_country(),
        "CustomerState"          => $customer_order->get_billing_state(),
        "CustomerCity"           => $customer_order->get_billing_city(),
        "CustomerAddress"        => $customer_order->get_billing_address_1(),
        "OrderReference"         => $order_id,

        "x_ship_to_first_name"  => $customer_order->get_shipping_first_name(),
        "x_ship_to_last_name"   => $customer_order->get_shipping_last_name(),
        "x_ship_to_company"     => $customer_order->get_shipping_company(),
        "x_ship_to_address"     => $customer_order->get_shipping_address_1(),
        "x_ship_to_city"        => $customer_order->get_shipping_city(),
        "x_ship_to_country"     => $customer_order->get_shipping_country(),
        "x_ship_to_state"       => $customer_order->get_shipping_state(),
        "x_ship_to_zip"         => $customer_order->get_shipping_postcode(),
        "x_cust_id"             => $customer_order->get_user_id(),
        "x_customer_ip"         => $remote_ip,
      );

      $response = wp_remote_post($environment_url, array(
        'method'               => 'POST',
        'headers'              => array('Content-Type' => 'application/x-www-form-urlencoded'),
        'body'                 => http_build_query($payload),
        'timeout'              => 90,
        'sslverify'            => false,
      ));

      if (is_wp_error($response))
        throw new Exception(esc_html__('There is issue for connectin payment gateway. Sorry for the inconvenience.', 'blackstone-online-gateway'));
      if (empty($response['body']))
        throw new Exception(esc_html__('Blackstone\'s Response was not get any data.', 'blackstone-online-gateway'));

      $response_body = wp_remote_retrieve_body($response);
      $resp = json_decode($response_body, true);

      error_log(print_r($environment_url, true));
      error_log(print_r($payload, true));
      error_log(print_r($resp, true));

      if (isset($resp['ResponseCode']) && $resp['ResponseCode'] == "200") {

        $customer_order->add_order_note(__('Blackstone complete payment.', 'blackstone-online-gateway'));

        if (isset($resp['ServiceReferenceNumber'])) {
          $ServiceReferenceNumber = $resp['ServiceReferenceNumber'];
          $customer_order->update_meta_data('_bmspay_service_reference_number', $ServiceReferenceNumber);
          $customer_order->add_order_note(__('Transaction ID: ', 'blackstone-online-gateway') . $ServiceReferenceNumber);
        }
        if (isset($payload['UserTransactionNumber'])) {
          $UserTransactionNumber = $payload['UserTransactionNumber'];
          $customer_order->update_meta_data('_bmspay_transaction_number',  $UserTransactionNumber);
          $customer_order->add_order_note(__('User Transaction Number: ', 'blackstone-online-gateway') . $UserTransactionNumber);
        }
        $customer_order->payment_complete();
        $woocommerce->cart->empty_cart();

        $customer_order->save();


        if (isset($resp['Token'])) {

          $user_id = $customer_order->get_user_id();

          $last4 = sanitize_text_field($resp['LastFour']);
          $card_type = sanitize_text_field($resp['CardType']);
          $expiry_month = substr(sanitize_text_field($payload['ExpDate']), 0, 2);
          $expiry_year = "20" . substr(sanitize_text_field($payload['ExpDate']), 2, 2);

          $existing_tokens = WC_Payment_Tokens::get_tokens(['user_id' => $user_id, 'type' => 'CC']);

          $existing_token_match = null;

          foreach ($existing_tokens as $existing_token) {
            /** @var WC_Payment_Token_CC $existing_token */
            if (
              $existing_token->get_last4() === $last4 &&
              $existing_token->get_expiry_month() === $expiry_month &&
              $existing_token->get_expiry_year() === $expiry_year &&
              $existing_token->get_card_type() === $card_type
            ) {
              $existing_token_match = $existing_token;
              break;
            }
          }
          if (isset($_POST['save_card']) && $_POST['save_card'] == '1') {
            if ($existing_token_match && $existing_token_match->get_gateway_id() === $this->id) {
              $existing_token_match->set_token($resp['Token']);
              $existing_token_match->save();
            } else {
              $token = new WC_Payment_Token_CC();
              $token->set_token($resp['Token']);
              $token->set_gateway_id($this->id);
              $token->set_user_id($user_id);
              $token->set_last4($last4);
              $token->set_card_type($card_type);
              $token->set_expiry_month($expiry_month);
              $token->set_expiry_year($expiry_year);

              $token->save();
            }
          }
        }

        return array(
          'result'   => 'success',
          'redirect' => $this->get_return_url($customer_order),
        );
      } else {
        $msg = $this->get_message_error($resp);
        wc_add_notice($msg, 'error');
        $msg = $this->get_message_error_full($resp, $userTransactionNumber);
        $customer_order->add_order_note('Error: ' . $msg);
      }
    }
  }

  public function get_message_error($response_data)
  {
    $msg = $response_data['Msg'][0] ?? __('No message provided', 'blackstone-online-gateway');
    $verbiage = $response_data['verbiage'] ?? __('No verbiage provided', 'blackstone-online-gateway');
    $avs = $response_data['avs'] ?? __('No AVS response', 'blackstone-online-gateway');
    $cv = $response_data['cv'] ?? __('No CV response', 'blackstone-online-gateway');
    error_log("$msg . More details: $verbiage. Extra validation: Zip ($avs), CVV ($cv)");
    return "$msg . More details: $verbiage.";
  }
  public function get_message_error_full($response_data, $userTransactionNumber)
  {
    $msg = $response_data['Msg'][0] ?? __('No message provided', 'blackstone-online-gateway');
    $verbiage = $response_data['verbiage'] ?? __('No verbiage provided', 'blackstone-online-gateway');
    $avs = $response_data['avs'] ?? __('No AVS response', 'blackstone-online-gateway');
    $cv = $response_data['cv'] ?? __('No CV response', 'blackstone-online-gateway');
    return "$msg . More details: $verbiage. Extra validation: Zip ($avs), CVV ($cv), UserTransactionNumber: $userTransactionNumber";
  }

  public function validate_fields()
  {
    return true;
  }
  public function do_ssl_check()
  {
    if ($this->enabled == "yes") {
      if (get_option('woocommerce_force_ssl_checkout') == "no") {
        // echo "<div class=\"error\"><p>" . sprintf(__("<strong>%s</strong> is enabled and WooCommerce is not forcing the SSL certificate on your checkout page. Please ensure that you have a valid SSL certificate and that you are <a href=\"%s\">forcing the checkout pages to be secured.</a>"), $this->method_title, admin_url('admin.php?page=wc-settings&tab=checkout')) . "</p></div>";
      }
    }
  }
  public function getEnvironment()
  {
    return $this->environment;
  }
  public function getEnvironment3DS()
  {
    return $this->environment_3ds;
  }
  public function isPluginActive()
  {
    return $this->enabled;
  }
  public function getLabelSurcharge()
  {
    return $this->label_surcharge;
  }
  public function getLabelCardDifference()
  {
    return $this->label_card_difference;
  }
}

function bmspay_round_amount($amount)
{
  return round((float) $amount, wc_get_price_decimals());
}

function bmspay_format_decimal_amount($amount)
{
  return wc_format_decimal(bmspay_round_amount($amount), wc_get_price_decimals());
}

function bmspay_build_charge_breakdown($base_amount, $surcharge_percent, $surcharge_enabled, $card_difference_percent, $card_difference_enabled)
{
  $base_amount = bmspay_round_amount($base_amount);
  $surcharge_percent = (float) $surcharge_percent;
  $card_difference_percent = (float) $card_difference_percent;

  $surcharge_amount = ($surcharge_enabled && $surcharge_percent > 0)
    ? bmspay_round_amount($base_amount * ($surcharge_percent / 100))
    : 0.0;

  $card_difference_amount = ($card_difference_enabled && $card_difference_percent > 0)
    ? bmspay_round_amount($base_amount * ($card_difference_percent / 100))
    : 0.0;

  return array(
    'base_amount' => $base_amount,
    'surcharge_percent' => $surcharge_percent,
    'card_difference_percent' => $card_difference_percent,
    'surcharge_amount' => $surcharge_amount,
    'card_difference_amount' => $card_difference_amount,
    'charge_amount' => bmspay_round_amount($base_amount + $surcharge_amount + $card_difference_amount),
  );
}

function bmspay_get_cart_base_amount()
{
  if (!WC()->cart) {
    return 0.0;
  }

  $base_amount = (float) WC()->cart->get_cart_contents_total()
    + (float) WC()->cart->get_fee_total()
    + (float) WC()->cart->get_shipping_total()
    + (float) WC()->cart->get_total_tax();

  return bmspay_round_amount($base_amount);
}

function bmspay_get_order_base_amount($order)
{
  if (!($order instanceof WC_Order)) {
    return 0.0;
  }

  $items_total = 0.0;
  foreach ($order->get_items('line_item') as $item) {
    $items_total += (float) $item->get_total();
  }

  $fees_total = 0.0;
  foreach ($order->get_fees() as $fee) {
    $fees_total += (float) $fee->get_total();
  }

  $base_amount = $items_total
    + $fees_total
    + (float) $order->get_shipping_total()
    + (float) $order->get_total_tax();

  return bmspay_round_amount($base_amount);
}

function bmspay_get_charge_overrides_from_session()
{
  if (!WC()->session) {
    return array();
  }

  $overrides = array();
  $surcharge_percent = WC()->session->get('surcharge_percent');
  $card_difference_percent = WC()->session->get('card_difference_percent');

  if ($surcharge_percent !== null && $surcharge_percent !== '') {
    $overrides['surcharge_percent'] = (float) $surcharge_percent;
    $overrides['surcharge_enabled'] = ((float) $surcharge_percent) > 0;
  }

  if ($card_difference_percent !== null && $card_difference_percent !== '') {
    $overrides['card_difference_percent'] = (float) $card_difference_percent;
    $overrides['card_difference_enabled'] = ((float) $card_difference_percent) > 0;
  }

  return $overrides;
}

function bmspay_get_charge_overrides_from_order_meta($order_id)
{
  if (!$order_id) {
    return array();
  }

  $overrides = array();
  $surcharge_percent = get_post_meta($order_id, '_surcharge_percent', true);
  $card_difference_percent = get_post_meta($order_id, '_card_difference_percent', true);

  if ($surcharge_percent !== '') {
    $overrides['surcharge_percent'] = (float) $surcharge_percent;
    $overrides['surcharge_enabled'] = ((float) $surcharge_percent) > 0;
  }

  if ($card_difference_percent !== '') {
    $overrides['card_difference_percent'] = (float) $card_difference_percent;
    $overrides['card_difference_enabled'] = ((float) $card_difference_percent) > 0;
  }

  return $overrides;
}

function bmspay_get_charge_overrides($order_id = 0)
{
  return array_merge(
    bmspay_get_charge_overrides_from_order_meta($order_id),
    bmspay_get_charge_overrides_from_session()
  );
}

function bmspay_get_cart_charge_breakdown($gateway = null)
{
  $gateway = $gateway ?: new bmspay_Blackstone_Payment();
  $surcharge_data = $gateway->get_cached_surcharge_data();

  return bmspay_build_charge_breakdown(
    bmspay_get_cart_base_amount(),
    $surcharge_data['response_SurchargePercent'],
    !empty($surcharge_data['response_SurchargeEnabled']),
    $surcharge_data['response_CardDifferencePercent'],
    !empty($surcharge_data['response_CardDifferenceEnabled'])
  );
}

function bmspay_get_order_charge_breakdown($order, $gateway = null, $overrides = array())
{
  $gateway = $gateway ?: new bmspay_Blackstone_Payment();
  $surcharge_data = $gateway->get_cached_surcharge_data();

  $surcharge_percent = array_key_exists('surcharge_percent', $overrides)
    ? (float) $overrides['surcharge_percent']
    : (float) $surcharge_data['response_SurchargePercent'];

  $card_difference_percent = array_key_exists('card_difference_percent', $overrides)
    ? (float) $overrides['card_difference_percent']
    : (float) $surcharge_data['response_CardDifferencePercent'];

  $surcharge_enabled = array_key_exists('surcharge_enabled', $overrides)
    ? (bool) $overrides['surcharge_enabled']
    : !empty($surcharge_data['response_SurchargeEnabled']);

  $card_difference_enabled = array_key_exists('card_difference_enabled', $overrides)
    ? (bool) $overrides['card_difference_enabled']
    : !empty($surcharge_data['response_CardDifferenceEnabled']);

  return bmspay_build_charge_breakdown(
    bmspay_get_order_base_amount($order),
    $surcharge_percent,
    $surcharge_enabled,
    $card_difference_percent,
    $card_difference_enabled
  );
}

function bmspay_get_current_charge_breakdown($gateway = null)
{
  global $wp;

  if (isset($wp->query_vars['order-pay'])) {
    $order_id = absint($wp->query_vars['order-pay']);
    $order = wc_get_order($order_id);

    if ($order) {
      return bmspay_get_order_charge_breakdown($order, $gateway, bmspay_get_charge_overrides($order_id));
    }
  }

  return bmspay_get_cart_charge_breakdown($gateway);
}

function bmspay_add_payment_gateway($gateways)
{
  $gateways[] = 'bmspay_Blackstone_Payment';
  return $gateways;
}

add_filter('woocommerce_payment_gateways', 'bmspay_add_payment_gateway');

add_action('woocommerce_review_order_before_order_total', function () {
  if (!getStatePlugin()) return;
  $gateway = new bmspay_Blackstone_Payment();
  $surcharge_data = $gateway->get_cached_surcharge_data();
  $threed_secure_enabled = $surcharge_data['response_ThreeDSecureEnabled'];

  if (WC()->session) {
    WC()->session->__unset('surcharge_amount');
    WC()->session->__unset('surcharge_percent');
    WC()->session->__unset('card_difference_amount');
    WC()->session->__unset('card_difference_percent');
    WC()->session->__unset('threed_secure_enabled');
    WC()->session->__unset('threed_secure_apikey');
    WC()->session->__unset('threed_secure_token');
    WC()->session->set('threed_secure_enabled', $threed_secure_enabled);
  }

  $charge_breakdown = bmspay_get_current_charge_breakdown($gateway);

  if (isset($_POST['payment_method'])) {
    $payment_method = isset($_POST['payment_method']) ? sanitize_text_field(wp_unslash($_POST['payment_method'])) : '';
    if ($payment_method === 'bmspay_blackstone_payment') {
      if ($charge_breakdown['surcharge_amount'] > 0) {
        if (WC()->session) {
          WC()->session->set('surcharge_amount', $charge_breakdown['surcharge_amount']);
          WC()->session->set('surcharge_percent', $charge_breakdown['surcharge_percent']);
        }
        echo '<tr class="order-total">
        <th>' . sprintf('%s (%s%%)', esc_html($gateway->getLabelSurcharge()), number_format($charge_breakdown['surcharge_percent'], 2)) . '</th>
        <td>' . wc_price($charge_breakdown['surcharge_amount']) . '</td>
        </tr>';
      }
      if ($charge_breakdown['card_difference_amount'] > 0) {
        if (WC()->session) {
          WC()->session->set('card_difference_amount', $charge_breakdown['card_difference_amount']);
          WC()->session->set('card_difference_percent', $charge_breakdown['card_difference_percent']);
        }
        echo '<tr class="order-total">
        <th>' . sprintf('%1$s (%2$s%%)', esc_html($gateway->getLabelCardDifference()), number_format($charge_breakdown['card_difference_percent'], 2)) . '</th>
        <td>' . wc_price($charge_breakdown['card_difference_amount']) . '</td>
        </tr>';
      }
    }
  }
});

add_action('woocommerce_review_order_after_order_total', function () {
  if (!getStatePlugin()) return;

  $charge_breakdown = bmspay_get_current_charge_breakdown();

  echo '<tr class="bmspay-charge-amount-row" style="display:none;">';
  echo '<td colspan="2"><input type="hidden" id="bmspay-charge-amount" value="' . esc_attr(bmspay_format_decimal_amount($charge_breakdown['charge_amount'])) . '"></td>';
  echo '</tr>';
});

add_filter('woocommerce_calculated_total', function ($total) {
  if (!getStatePlugin() || !WC()->session) return $total;
  $surcharge = WC()->session->get('surcharge_amount');
  $card_difference = WC()->session->get('card_difference_amount');
  if (isset($_POST['payment_method'])) {
    $payment_method = isset($_POST['payment_method']) ? sanitize_text_field(wp_unslash($_POST['payment_method'])) : '';
    if ($payment_method === 'bmspay_blackstone_payment') {
      if ($surcharge) {
        $total += $surcharge;
      }
      if ($card_difference) {
        $total += $card_difference;
      }
    }
  }
  return $total;
});
function getStatePlugin()
{
  static $should_apply_fees = null;

  if ($should_apply_fees === null) {
    $payment_gateways = WC()->payment_gateways->get_available_payment_gateways();
    $gateway_id = 'bmspay_blackstone_payment';

    $should_apply_fees = isset($payment_gateways[$gateway_id])
      && ($payment_gateways[$gateway_id]->enabled === 'yes');
  }

  return $should_apply_fees;
}
add_filter('woocommerce_get_order_item_totals', function ($totals, $order, $tax_display) {
  if (!getStatePlugin() || !WC()->session) return $totals;
  if (WC()->session) {
    $surcharge = WC()->session->get('surcharge_amount');
    $card_difference = WC()->session->get('card_difference_amount');
    $surcharge_percent = WC()->session->get('surcharge_percent');
    $card_difference_percent = WC()->session->get('card_difference_percent');

    if (($surcharge || $card_difference) && getStatePlugin()) {
      $new_totals = [];
      $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();

      foreach ($totals as $key => $total) {
        if ($key === 'order_total') {
          if ($surcharge) {
            $new_totals['surcharge'] = [
              'label' => $bmspay_Blackstone_Payment->getLabelSurcharge() . ' (' . number_format($surcharge_percent, 2) . '%)',
              'value' => wc_price($surcharge),
            ];
          }
          if ($card_difference) {
            $new_totals['card_difference'] = [
              'label' => $bmspay_Blackstone_Payment->getLabelCardDifference() . ' (' . number_format($card_difference_percent, 2) . '%)',
              'value' => wc_price($card_difference),
            ];
          }
        }
        $new_totals[$key] = $total;
      }

      return $new_totals;
    }
  }

  return $totals;
}, 10, 3);

add_action('woocommerce_checkout_update_order_meta', function ($order_id) {
  if (!getStatePlugin() || !WC()->session) return;
  if (WC()->session && getStatePlugin()) {
    $surcharge = WC()->session->get('surcharge_amount');
    $card_difference = WC()->session->get('card_difference_amount');
    $surcharge_percent = WC()->session->get('surcharge_percent');
    $card_difference_percent = WC()->session->get('card_difference_percent');

    if ($surcharge) {
      update_post_meta($order_id, '_surcharge_amount', bmspay_format_decimal_amount($surcharge));
      update_post_meta($order_id, '_surcharge_percent', $surcharge_percent);
    }
    if ($card_difference) {
      update_post_meta($order_id, '_card_difference_amount', bmspay_format_decimal_amount($card_difference));
      update_post_meta($order_id, '_card_difference_percent', $card_difference_percent);
    }
  }
});

function recalculate_order_total_with_fees($order_id)
{
  $order = wc_get_order($order_id);
  if (!$order) {
    return;
  }

  $charge_breakdown = bmspay_get_order_charge_breakdown(
    $order,
    null,
    bmspay_get_charge_overrides_from_order_meta($order_id)
  );

  $order->set_total($charge_breakdown['charge_amount']);

  update_post_meta($order_id, '_surcharge_amount', bmspay_format_decimal_amount($charge_breakdown['surcharge_amount']));
  update_post_meta($order_id, '_card_difference_amount', bmspay_format_decimal_amount($charge_breakdown['card_difference_amount']));

  $order->save();
}
add_action('woocommerce_order_status_processing_to_pending', 'handle_order_status_change_to_pending', 10, 1);

function handle_order_status_change_to_pending($order_id)
{
  if (!getStatePlugin()) return;
  // Verificar que es nuestro método de pago
  $order = wc_get_order($order_id);
  if ($order && $order->get_payment_method() === 'bmspay_blackstone_payment') {
    recalculate_order_total_with_fees($order_id);
  }
}
add_action('woocommerce_order_after_calculate_totals', 'custom_adjust_order_totals_with_meta', 10, 2);

function custom_adjust_order_totals_with_meta($and_taxes, $order)
{
  if (!getStatePlugin()) return;
  // Solo aplicarlo si es nuestro método de pago
  // Primero verifica si NO es un pedido válido o SI es un reembolso
  if (!($order instanceof WC_Order) || $order instanceof WC_Order_Refund) {
    return;
  }
  // Luego verifica el método de pago (sabemos que $order es WC_Order)
  if ($order->get_payment_method() !== 'bmspay_blackstone_payment') {
    return;
  }

  $order_id = $order->get_id();
  $charge_breakdown = bmspay_get_order_charge_breakdown(
    $order,
    null,
    bmspay_get_charge_overrides_from_order_meta($order_id)
  );

  $order->set_total($charge_breakdown['charge_amount']);

  update_post_meta($order_id, '_surcharge_amount', bmspay_format_decimal_amount($charge_breakdown['surcharge_amount']));
  update_post_meta($order_id, '_card_difference_amount', bmspay_format_decimal_amount($charge_breakdown['card_difference_amount']));
}


add_action('woocommerce_admin_order_totals_after_tax', function ($order_id) {
  if (!getStatePlugin()) return;
  $order = wc_get_order($order_id);
  $payment_method = $order->get_payment_method();
  $surcharge = get_post_meta($order_id, '_surcharge_amount', true);
  $surcharge_percent = floatval(get_post_meta($order_id, '_surcharge_percent', true)) ?? 0;

  $card_difference = get_post_meta($order_id, '_card_difference_amount', true);
  $card_difference_percent = floatval(get_post_meta($order_id, '_card_difference_percent', true)) ?? 0;

  if (($surcharge || $card_difference) && getStatePlugin() && $payment_method === 'bmspay_blackstone_payment') {
    $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();
    if ($surcharge && floatval($surcharge) > 0) {
      $label_surcharge = $bmspay_Blackstone_Payment->getLabelSurcharge();
      if ($surcharge_percent > 0) {
        $label = sprintf('%1$s (%2$s%%)', esc_html($label_surcharge), number_format($surcharge_percent ?? 0, 2));
      } else {
        $label = esc_html($label_surcharge);
      }
    ?>
      <tr>
        <td class="label"><?php echo esc_html($label); ?>:</td>
        <td width="1%"></td>
        <td class="total"><?php echo esc_html(wc_price($surcharge)); ?></td>
      </tr>
    <?php
    }
    if ($card_difference  && floatval($card_difference) > 0) {
      $label_card_difference = $bmspay_Blackstone_Payment->getLabelCardDifference();
      if ($card_difference_percent > 0) {
        $label = sprintf('%1$s (%2$s%%)', esc_html($label_card_difference), number_format($card_difference_percent, 2));
      } else {
        $label = esc_html($label_card_difference);
      }
    ?>
      <tr>
        <td class="label"><?php echo esc_html($label); ?>:</td>
        <td width="1%"></td>
        <td class="total"><?php echo esc_html(wc_price($card_difference)); ?></td>
      </tr>
      <?php }
  }
});
add_filter('woocommerce_account_menu_items', 'add_payment_methods_to_my_account');

function add_payment_methods_to_my_account($items)
{
  if (isset($items['payment-methods'])) {
    unset($items['payment-methods']);
  }
  $logout = $items['customer-logout'];
  unset($items['customer-logout']);
  $items['payment-methods'] = __('Payment methods', 'blackstone-online-gateway');
  $items['customer-logout'] = $logout;

  return $items;
}

add_action('woocommerce_review_order_before_submit', 'add_save_card_option');
add_action('woocommerce_pay_order_before_submit', 'add_save_card_option');

function add_save_card_option()
{
  if (!getStatePlugin()) return;
  // Verificar si es página de pago de pedido
  global $wp;
  $is_pay_for_order = isset($wp->query_vars['order-pay']);

  // Obtener el método de pago según el contexto
  $payment_method = '';

  if ($is_pay_for_order) {
    // Para página de pago de pedido
    if (isset($_POST['payment_method'])) {
      $payment_method = isset($_POST['payment_method']) ? sanitize_text_field(wp_unslash($_POST['payment_method'])) : '';
    } else {
      $order_id = absint($wp->query_vars['order-pay']);
      $order = wc_get_order($order_id);
      $payment_method = $order->get_payment_method();
    }
  } else {
    // Para checkout normal
    $payment_method = isset($_POST['payment_method']) ? sanitize_text_field(wp_unslash($_POST['payment_method'])) : '';
  }

  // Mostrar opción solo si el método de pago es el nuestro y el usuario está logueado
  if ($payment_method === 'bmspay_blackstone_payment' && is_user_logged_in()) {
    echo '<p class="form-row woocommerce-SavedPaymentMethods-saveNew">';
    woocommerce_form_field('save_card', [
      'type'  => 'checkbox',
      'class' => ['form-row-wide'],
      'label' => __('Save card for future purchases', 'blackstone-online-gateway'),
    ]);
    echo '</p>';
  }
}

function enqueue_threeds_script()
{
  if (!getStatePlugin()) return;
  if (is_checkout() || is_order_pay_page()) {
    wp_enqueue_script(
      'threeds-script',
      'https://cdn.3dsintegrator.com/threeds.2.2.20231219.min.js',
      array(),
      '2.2.20231219',
      true
    );
  }
}
add_action('wp_enqueue_scripts', 'enqueue_threeds_script');

add_action('wp_enqueue_scripts', 'change_sweetalert2', 20);
add_action('admin_enqueue_scripts', 'change_sweetalert2');
function change_sweetalert2()
{
  if (!getStatePlugin()) return;
  
  // Permitir en checkout solo si 3DS está habilitado
  if (is_checkout() || is_order_pay_page()) {
    $bmspay_Blackstone_Payment = new bmspay_Blackstone_Payment();
    $surcharge_data = $bmspay_Blackstone_Payment->get_cached_surcharge_data();
    $threeds_enabled = $surcharge_data['response_ThreeDSecureEnabled'];
    
    // Solo cargar si 3DS está activo
    if (!$threeds_enabled) {
      return;
    }
  }
  
  wp_enqueue_script(
    'sweetalert2',
    plugins_url('assets/js/sweetalert2_11.js', __FILE__),
    array('jquery'),
    '11.0.0',
    true
  );
}


add_action('woocommerce_after_order_notes', 'add_threeds_hidden_field');

function add_threeds_hidden_field($checkout)
{
  if (!getStatePlugin()) return;
  echo '<input type="hidden" name="threeds_response" id="threeds_response" value="">';
}
function getTotalAmount()
{
  global $wp;

  if (isset($wp->query_vars['order-pay'])) {
    $order_id = absint($wp->query_vars['order-pay']);
    $order = wc_get_order($order_id);

    if ($order) {
      $charge_breakdown = bmspay_get_order_charge_breakdown(
        $order,
        null,
        bmspay_get_charge_overrides_from_order_meta($order_id)
      );

      return bmspay_format_decimal_amount($charge_breakdown['charge_amount']);
    }
  }

  $charge_breakdown = bmspay_get_cart_charge_breakdown();

  return bmspay_format_decimal_amount($charge_breakdown['charge_amount']);
}

add_action('wp_enqueue_scripts', 'enqueue_payment_method_script', 20);
function enqueue_payment_method_script()
{
    if (!getStatePlugin() || !is_checkout()) {
        return;
    }

    wp_register_script(
        'payment-method-custom',
        plugins_url('/assets/js/payment-method-custom.js', __FILE__),
        ['jquery'],
        null,
        true
    );

    wp_enqueue_script('payment-method-custom');
}


function is_order_pay_page()
{
  global $wp;
  return isset($wp->query_vars['order-pay']);
}
