<?php

use SimplePie\Parse\Date;

if (!defined('ABSPATH')) {
    exit;
}

class WC_Refund_Request
{
    public function __construct()
    {
        add_action('admin_enqueue_scripts', [$this, 'remove_refund_button']);
        // add_action('wp_ajax_custom_refund_action', [$this, 'handle_custom_refund_action']);
    }

    public function remove_refund_button()
    {
        //if (isset($_GET['post']) && get_post_type($_GET['post']) === 'shop_order') {
        add_action('woocommerce_order_item_add_action_buttons', [$this, 'add_custom_button_to_order_page_modal'], 20);
        //}
    }

    public function handle_custom_refund_action()
    {
        if (!(isset($_POST['action']) && $_POST['action'] === 'custom_refund_action') || isset($_POST['save'])) {
            // wp_die();
            return;
        }
        if (isset($_POST['custom_refund_order_id']) && isset($_POST['custom_refund_nonce'])) {
            if (!wp_verify_nonce($_POST['custom_refund_nonce'], 'custom_refund_nonce')) {
                wc_add_notice('Invalid request.', 'error');
                return;
            }

            $order_id = intval($_POST['custom_refund_order_id']);
            if (!$order_id) {
                wc_add_notice('Invalid Order ID.', 'error');
                return;
            }

            $order = wc_get_order($order_id);
            if (!$order) {
                wc_add_notice('Order not found.', 'error');
                return;
            }

            try {
                $this->process_refund_request($order);

                $this->rediret_refund_order($order_id);
            } catch (Exception $e) {
                error_log(print_r('Error al procesar el reembolso: ' . $e->getMessage(), true));
            }
        }
    }

    public function process_refund_request($order, $refund_amount = null)
    {
        if ($this->is_refund_order($order)) {
            return;
        }
        $payment_gateways = WC_Payment_Gateways::instance()->payment_gateways();
        $blackstone_gateway = $payment_gateways['bmspay_blackstone_payment'];
        //Deprecate
        // $service_reference_number = get_post_meta($order->get_id(), '_bmspay_service_reference_number', true);
        $service_reference_number = $order->get_meta('_bmspay_service_reference_number');

        $environment_url = ($blackstone_gateway->environment == 'yes')
            ? 'https://services.bmspay.com/api/Transactions/DoRefund'
            : 'https://services.bmspay.com/api/Transactions/DoRefund';

        $data = array(
            'Amount' => $refund_amount ?? $order->get_total(),
            'TrackData' => '',
            'UserTransactionNumber' => md5(uniqid($service_reference_number . $environment_url, true)),
            'ServiceTransactionNumber' => $service_reference_number,
            'SURI' => '',
            'AppKey' => $blackstone_gateway->environment == 'yes' ? "12345" : $blackstone_gateway->app_key,
            'AppType' => $blackstone_gateway->environment == 'yes' ? "1" : $blackstone_gateway->app_type,
            'mid' => $blackstone_gateway->environment == 'yes' ? "76074" : $blackstone_gateway->api_mid,
            'cid' => $blackstone_gateway->environment == 'yes' ? "260" : $blackstone_gateway->api_cid,
            'UserName' => $blackstone_gateway->environment == 'yes' ? "nicolas" : $blackstone_gateway->api_username,
            'Password' => $blackstone_gateway->environment == 'yes' ? "password1" : $blackstone_gateway->api_password,
            'IpAddress' => $_SERVER['REMOTE_ADDR']
        );

        error_log(print_r('environment_url', true));
        error_log(print_r($environment_url, true));
        error_log(print_r('data enviada', true));
        error_log(print_r($data, true));

        $response = wp_remote_post($environment_url, array(
            'method' => 'POST',
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($data),
        ));

        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        error_log(print_r($response_data, true));

        if (isset($response_data['ResponseCode']) && $response_data['ResponseCode'] == "200") {

            wc_create_refund(array(
                'amount' => $refund_amount ?? $order->get_total(),
                'reason' => 'Refund processed via API.',
                'order_id' => $order->get_id(),
                'refund_payment' => false,
                'restock_items' => false
            ));

            if ($refund_amount < $order->get_total()) {
                $order->update_status('partially-refunded');
                $order->add_order_note(sprintf(__('Partial refund of %s processed via API', 'your-textdomain'), wc_price($refund_amount)));
            } else {
                $order->add_order_note('Order refunded via API.');
                $order->update_status('refunded');
            }

            return [
                "success" => true,
                'message' => __("Refund completed with reference: $service_reference_number", 'your-text-domain')
            ];
        } else {
            if (!function_exists('wc_add_notice')) {
                error_log(print_r('Refund request failed.', true));
                return;
            }
            $msg = $this->get_message_error($response_data);
            $order->add_order_note($msg);
            return [
                "success" => false,
                'message' => __($msg, 'your-textdomain')
            ];
        }
    }
    public function get_message_error($response_data)
    {
        $msg = __('No message provided', 'bmspay-blackstone-payment');

        if (isset($response_data['Msg']) && is_array($response_data['Msg'])) {
            $msg = implode(', ', $response_data['Msg']);
        }
        return "Refund request failed : $msg";
    }
    public function get_remaining_balance($order)
    {
        if (is_numeric($order)) {
            $order = wc_get_order($order);
        }

        if (!$order || !is_a($order, 'WC_Order')) {
            return 0;
        }

        return $order->get_total() - $order->get_total_refunded();
    }
    public function add_custom_button_to_order_page_modal($order)
    {
        if ($this->is_refund_order($order) || (!$this->is_blackstone_payment_method($order))) {
            return;
        }

        $order_total = $this->get_remaining_balance($order);
        $currency_symbol = get_woocommerce_currency_symbol();

        echo '<button type="button" id="custom-refund-button" class="button custom-refund-button">Blackstone Refund</button>';

        wp_enqueue_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11', [], '11.0.0', true);
?>
        <script>
            jQuery(document).ready(function($) {
                $('#custom-refund-button').on('click', function() {
                    Swal.fire({
                        title: 'Confirm Refund',
                        html: `
                    <p>Are you sure you want to process this refund?</p>
                    <div style="margin: 20px 0;">
                        <label for="refund-amount" style="display: block; margin-bottom: 5px; text-align: center;">
                            Refund Amount (<?php echo esc_js($currency_symbol); ?>)
                        </label>
                        <input 
                            type="number" 
                            id="refund-amount" 
                            class="swal2-input" 
                            value="<?php echo esc_js($order_total); ?>" 
                            min="0" 
                            max="<?php echo esc_js($order_total); ?>" 
                            step="0.01"
                            style="width: 50%; padding: 8px;"
                        >
                    </div>
                `,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#4CAF50',
                        cancelButtonColor: '#F44336',
                        confirmButtonText: 'Yes, refund it!',
                        cancelButtonText: 'Cancel',
                        reverseButtons: true,
                        showLoaderOnConfirm: true,
                        preConfirm: () => {
                            const refundAmount = parseFloat($('#refund-amount').val());
                            const maxAmount = parseFloat(<?php echo $order_total; ?>);

                            if (isNaN(refundAmount) || refundAmount <= 0) {
                                Swal.showValidationMessage('Please enter a valid amount');
                                return false;
                            }

                            if (refundAmount > maxAmount) {
                                Swal.showValidationMessage(`Amount cannot exceed ${maxAmount.toFixed(2)}`);
                                return false;
                            }

                            return new Promise((resolve, reject) => {
                                $.ajax({
                                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                                    type: 'POST',
                                    data: {
                                        action: 'custom_refund_action',
                                        custom_refund_order_id: '<?php echo esc_js($order->get_id()); ?>',
                                        custom_refund_nonce: '<?php echo wp_create_nonce('custom_refund_nonce'); ?>',
                                        refund_amount: refundAmount
                                    },
                                    success: function(response) {
                                        if (response.success) {
                                            resolve(response.message || 'Refund processed successfully.');
                                        } else {
                                            reject(response.message);
                                            reject(response.message || 'Refund request failed, please check order notes');
                                        }
                                    },
                                    error: function(jqXHR) {
                                        reject(`Request failed: ${jqXHR.responseJSON?.message || jqXHR.statusText}`);
                                    }
                                });
                            });
                        },
                        allowOutsideClick: () => !Swal.isLoading()
                    }).then((result) => {
                        if (result.isConfirmed) {
                            Swal.fire({
                                title: 'Completed!',
                                text: result.value,
                                icon: 'success',
                                confirmButtonText: 'OK',
                                willClose: () => {
                                    window.location.href = '<?php echo add_query_arg(array(
                                                                'post' => $order->get_id(),
                                                                'action' => 'edit'
                                                            ), admin_url('post.php')); ?>&nocache=' + Date.now();
                                }
                            });
                        }
                    }).catch(error => {
                        Swal.fire({
                            title: 'Error',
                            text: error,
                            icon: 'error',
                            confirmButtonText: 'OK',
                            willClose: () => {
                                window.location.href = '<?php echo add_query_arg(array(
                                                            'post' => $order->get_id(),
                                                            'action' => 'edit'
                                                        ), admin_url('post.php')); ?>&nocache=' + Date.now();
                            }
                        });
                    });
                });
            });
        </script>
<?php
    }
    private function is_refund_order($order)
    {
        if (!is_a($order, 'WC_Order')) {
            return false;
        }
        return $this->get_remaining_balance($order) == 0;
    }

    private function rediret_refund_order($order_id)
    {
        $redirect_url = add_query_arg(
            array(
                'post' => $order_id,
                'action' => 'edit',
            ),
            admin_url('post.php')
        );

        // Redirige a la misma página de edición del pedido después de procesar el mismo
        wp_safe_redirect($redirect_url);
        exit;
    }

    function is_blackstone_payment_method($order)
    {
        return $order->get_payment_method() === 'bmspay_blackstone_payment';
    }
}
add_action('wp_ajax_custom_refund_action', function () {
    check_ajax_referer('custom_refund_nonce', 'custom_refund_nonce');

    $order_id = isset($_POST['custom_refund_order_id']) ? intval($_POST['custom_refund_order_id']) : 0;
    $refund_amount = isset($_POST['refund_amount']) ? floatval($_POST['refund_amount']) : 0;

    $order = wc_get_order($order_id);

    if ($refund_amount <= 0 || $refund_amount > $order->get_total()) {
        wp_send_json_error(['message' => 'Invalid refund amount']);
    }

    $refund_request = new WC_Refund_Request();

    $api_response = $refund_request->process_refund_request($order, $refund_amount);

    if (!$api_response['success']) {
        wp_send_json_error(['message' => $api_response['message']]);
    } else {
        remove_action('woocommerce_order_refunded', 'wc_order_fully_refunded');
        wp_send_json_success(['message' => $api_response['message']]);
    }
});
